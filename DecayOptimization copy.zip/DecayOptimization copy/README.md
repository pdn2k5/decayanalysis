# 🥬 Decay Optimization Platform

**AI-driven decay analysis and shelf-life prediction for perishable goods**

![Platform Overview](https://img.shields.io/badge/Status-Production_Ready-green)
![Python](https://img.shields.io/badge/Python-3.9+-blue)
![React](https://img.shields.io/badge/React-18.2-61DAFB)
![License](https://img.shields.io/badge/License-MIT-yellow)

## 📋 Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Architecture](#architecture)
- [Quick Start](#quick-start)
- [Configuration](#configuration)
- [API Documentation](#api-documentation)
- [Voice Features](#voice-features)
- [LLM Integration](#llm-integration)

---

## 🎯 Overview

The Decay Optimization Platform is an AI-powered solution that addresses the challenges of perishable inventory management by:

- **Predicting decay dynamically** instead of relying on fixed expiry dates
- **Analyzing environmental factors** (temperature, humidity) that affect spoilage
- **Providing real-time alerts** for at-risk inventory
- **Optimizing pricing strategies** to reduce waste and maximize revenue
- **Enabling natural language queries** through an AI assistant

### Supported Product Categories

| Category | Optimal Temp | Shelf Life | Decay Rate |
|----------|-------------|------------|------------|
| 🥛 Dairy | 2-4°C | 14 days | Low |
| 🍎 Fruits | 4-8°C | 10 days | Medium |
| 🥬 Vegetables | 4-10°C | 7 days | Medium |
| 🥩 Meat | -1 to 2°C | 5 days | High |

---

## ✨ Features

### Core AI Features

- **Decay Prediction Model**: ML ensemble (XGBoost/Gradient Boosting) for decay scoring
- **Shelf-Life Estimation**: Weibull survival analysis with confidence intervals
- **Visual Dashboard**: Real-time monitoring of inventory health
- **Smart Alerts**: LLM-enhanced contextual alerts
- **Price Optimizer**: Dynamic markdown recommendations

### Voice Integration 🔊

- **Text-to-Speech alerts** for critical notifications
- **Voice summaries** of daily reports
- **Accessible audio playback** in the dashboard

### AI Assistant 🤖

- **Natural language queries** about inventory
- **Contextual explanations** of predictions
- **Root cause analysis** for spoilage issues
- **Report generation** on demand

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        FRONTEND (React)                          │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐           │
│  │Dashboard │ │Inventory │ │ Alerts   │ │Assistant │           │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘           │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      BACKEND (FastAPI)                           │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │                    REST API Layer                         │   │
│  │  /predictions  /inventory  /alerts  /analytics  /voice   │   │
│  └──────────────────────────────────────────────────────────┘   │
│                              │                                   │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │                    Services Layer                         │   │
│  │  DecayPredictor │ ShelfLifeEstimator │ PriceOptimizer    │   │
│  │  AlertEngine    │ VoiceService       │ LLMService        │   │
│  └──────────────────────────────────────────────────────────┘   │
│                              │                                   │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │                    Data Layer (SQLite)                    │   │
│  │  Products │ Batches │ Sensors │ Predictions │ Alerts     │   │
│  └──────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    LLM Service (Ollama / API)                    │
│  Local: qwen2.5:7b  │  External: Azure/OpenAI Compatible        │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🚀 Quick Start

### Prerequisites

- **macOS / Windows / Linux** (12+ CPU cores, 16GB RAM recommended)
- **Python 3.9+** ([Download](https://python.org) or `brew install python3`)
- **Node.js 18+** ([Download](https://nodejs.org) or `brew install node`)
- **Ollama** (Optional, for local LLM) ([Download](https://ollama.ai))

### Installation

1. **Clone or extract the project**:
   ```bash
   cd DecayOptimization
   ```

2. **Start the platform**:

   ---
   
   ### 🍎 macOS
   
   **Option A - One-click start**:
   ```bash
   ./start.sh
   ```
   
   **Option B - Start separately**:
   ```bash
   # Terminal 1 - Backend
   ./start_backend.sh
   
   # Terminal 2 - Frontend
   ./start_frontend.sh
   ```
   
   **Option C - Manual start**:
   ```bash
   # Terminal 1 - Backend
   cd backend
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   python3 main.py
   
   # Terminal 2 - Frontend
   cd frontend
   npm install
   npm run dev
   ```

   ---
   
   ### 🪟 Windows
   
   **Option A - One-click start**:
   ```
   Double-click start.bat
   ```
   
   **Option B - Manual start**:
   ```cmd
   REM Terminal 1 - Backend
   cd backend
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt
   python main.py
   
   REM Terminal 2 - Frontend
   cd frontend
   npm install
   npm run dev
   ```

   ---

3. **Open in browser**: http://localhost:3000

4. **Load sample data**: Click "Load Sample Data" button on the Dashboard

---

## ⚙️ Configuration

### Environment Variables

Copy `backend/env_template.txt` to `backend/.env` and configure:

```env
# Database
DATABASE_URL=sqlite:///./decay_optimization.db

# LLM Provider: "ollama" or "api"
LLM_PROVIDER=ollama

# Ollama Configuration (local)
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=qwen2.5:7b

# External API Configuration
LLM_API_BASE_URL=https://genailab.tcs.in
LLM_API_MODEL=azure/genailab-maas-gpt-4o-mini
LLM_API_KEY=your_api_key_here

# SSL (set to false for self-signed certs)
SSL_VERIFY=false

# Voice
VOICE_ENABLED=true
VOICE_ENGINE=pyttsx3
```

### Setting up Ollama (Local LLM)

1. Install Ollama from https://ollama.ai
2. Pull a model:
   ```bash
   ollama pull qwen2.5:7b
   ```
3. Ollama will automatically start on http://localhost:11434

### Using External LLM API

Set `LLM_PROVIDER=api` and configure the API credentials:

```python
# Example connection code (for reference)
from langchain_openai import ChatOpenAI
import httpx

client = httpx.Client(verify=False)
llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure/genailab-maas-gpt-4o-mini",
    api_key="YOUR_API_KEY",
    http_client=client
)
```

---

## 📚 API Documentation

Once the backend is running, access:
- **Swagger UI**: http://localhost:8000/api/docs
- **ReDoc**: http://localhost:8000/api/redoc

### Key Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/v1/predictions/decay` | POST | Generate decay prediction |
| `/api/v1/inventory/batches` | GET | List inventory batches |
| `/api/v1/alerts/` | GET | Get active alerts |
| `/api/v1/analytics/dashboard` | GET | Dashboard metrics |
| `/api/v1/assistant/query` | POST | Query AI assistant |
| `/api/v1/voice/speak/base64` | POST | Generate voice audio |
| `/api/v1/upload/sample-data` | POST | Load synthetic data |

---

## 🔊 Voice Features

The platform includes text-to-speech capabilities for:

### Supported Features

- **Alert Voice Notifications**: Critical alerts can be spoken aloud
- **Daily Summaries**: Voice summary of daily inventory status
- **Custom Text**: Convert any text to speech

### Voice Engines

1. **pyttsx3** (Default): Offline TTS
   - **Windows**: Uses SAPI5
   - **macOS**: Uses NSSpeechSynthesizer
   - **Linux**: Uses espeak
2. **gTTS**: Online, uses Google Text-to-Speech (requires internet)

### Usage

```javascript
// From frontend
const result = await textToSpeech("Your alert message here");
// Play the audio
playVoiceAlert(result.audio_base64);
```

---

## 🤖 LLM Integration

### Supported Providers

| Provider | Model | Use Case |
|----------|-------|----------|
| Ollama (Local) | qwen2.5:7b | Development, offline |
| Azure OpenAI | gpt-4o-mini | Production |
| Custom API | Any OpenAI-compatible | Flexible |

### AI Assistant Capabilities

- **Natural Language Queries**: "Which products should I markdown today?"
- **Explanations**: "Why is this batch at risk?"
- **Root Cause Analysis**: Analyze spoilage patterns
- **Report Generation**: Daily summaries and insights

### Example Queries

```
"What's the average decay score for dairy products?"
"Show me critical alerts in Store 101"
"Generate a root cause analysis for recent meat spoilage"
"What markdown should I apply to vegetables expiring tomorrow?"
```

---

## 📊 Dashboard Features

### Overview Page
- Real-time inventory health metrics
- Risk breakdown (Critical/High/Medium/Healthy)
- Decay trend charts
- Recent alerts

### Inventory Page
- Searchable batch table
- Filter by category, location, decay score
- One-click predictions
- AI explanations

### Alerts Page
- Severity-based alert display
- Voice playback for alerts
- Acknowledge/dismiss actions
- LLM-enhanced smart messages

### Analytics Page
- Decay trends over time
- Waste analysis by category
- Daily executive reports
- Prediction accuracy metrics

### Markdown Page
- AI-powered pricing recommendations
- Expected revenue calculations
- Urgency-based prioritization
- One-click markdown application

### Cold Chain Page
- Real-time temperature monitoring
- Location-based filtering
- Anomaly detection
- Temperature timeline charts

### AI Assistant Page
- Chat interface for natural queries
- Voice response playback
- Suggested questions
- Quick action buttons

---

## 🧪 Testing

### Load Sample Data

1. Go to Dashboard
2. Click "Load Sample Data" button
3. Data for all 4 categories will be generated

### Test Voice

1. Go to any page with voice controls
2. Click "Test Voice" button
3. Audio should play

### Test Predictions

1. Go to Inventory page
2. Select any batch
3. Click "Predict" button

---

## 📁 Project Structure

```
DecayOptimization/
├── backend/
│   ├── main.py              # FastAPI application
│   ├── config.py            # Configuration
│   ├── requirements.txt     # Python dependencies
│   ├── database/            # SQLAlchemy models
│   ├── services/            # Business logic
│   │   ├── llm_service.py   # LLM integration
│   │   ├── voice_service.py # TTS service
│   │   ├── decay_predictor.py
│   │   └── ...
│   ├── api/routes/          # API endpoints
│   └── data/                # Synthetic data generators
│
├── frontend/
│   ├── src/
│   │   ├── App.jsx          # Main component
│   │   ├── pages/           # Page components
│   │   ├── components/      # Reusable components
│   │   └── services/api.js  # API client
│   └── package.json
│
├── start.bat                # Full stack startup
├── start_backend.bat        # Backend only
├── start_frontend.bat       # Frontend only
└── README.md
```

---

## 🔧 Troubleshooting

### Backend won't start

**macOS:**
```bash
# Check Python
python3 --version

# If not installed
brew install python3

# Permission denied on script
chmod +x start_backend.sh
```

**Windows:**
```cmd
python --version
```
- Check if port 8000 is available
- Review error messages in terminal

### Frontend won't start

**macOS:**
```bash
# Check Node.js
node --version

# If not installed
brew install node

# Permission denied on script
chmod +x start_frontend.sh
```

**Windows:**
```cmd
node --version
```
- Run `npm install` in frontend directory
- Check if port 3000 is available

### LLM not responding
- For Ollama: Ensure it's running (`ollama list`)
- For API: Check API key and network connectivity
- Platform will use fallback responses if LLM unavailable

### Voice not working

**macOS:**
- Check system audio settings
- Ensure `VOICE_ENABLED=true` in .env
- pyttsx3 uses NSSpeechSynthesizer on Mac

**Windows:**
- Check system audio settings
- pyttsx3 uses SAPI5 voices

**Alternative:**
- Try `VOICE_ENGINE=gtts` (requires internet)

---

## 📄 License

MIT License - See LICENSE file for details.

---

## 🙏 Acknowledgments

Built with:
- FastAPI & SQLAlchemy
- React & Recharts
- LangChain
- Tailwind CSS
- Framer Motion

---

**Made with ❤️ for smarter perishable inventory management**

