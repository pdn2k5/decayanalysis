"""
Decay Optimization Platform - Simplified FastAPI Backend
AI-driven decay analysis and shelf-life prediction for perishable goods.
"""

from fastapi import FastAPI, UploadFile, File, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import uvicorn
from datetime import datetime, timedelta
from pathlib import Path
import random
import json
import base64
import hashlib
import math

# Create FastAPI app
app = FastAPI(
    title="Decay Optimization Platform",
    description="AI-driven decay analysis and shelf-life prediction",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create static directories
Path("static/audio").mkdir(parents=True, exist_ok=True)
Path("static/images/shelf").mkdir(parents=True, exist_ok=True)
Path("static/images/backroom").mkdir(parents=True, exist_ok=True)
Path("data/sample_datasets").mkdir(parents=True, exist_ok=True)

# Mount static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# ============ RSL CALCULATION SYSTEM ============

# Base shelf life in days for each product category
BASE_SHELF_LIFE = {
    "Dairy": {"Milk": 7, "Cheese": 30, "Yogurt": 14, "Butter": 45, "Cream": 10},
    "Fruits": {"Apples": 21, "Bananas": 5, "Oranges": 14, "Strawberries": 3, "Grapes": 10},
    "Vegetables": {"Lettuce": 7, "Tomatoes": 10, "Carrots": 21, "Broccoli": 7, "Spinach": 5},
    "Meat": {"Chicken": 3, "Beef": 5, "Pork": 5, "Fish": 2, "Turkey": 4}
}

# Optimal storage conditions
OPTIMAL_CONDITIONS = {
    "Dairy": {"temp_min": 2, "temp_max": 4, "humidity_min": 60, "humidity_max": 70},
    "Fruits": {"temp_min": 4, "temp_max": 8, "humidity_min": 85, "humidity_max": 95},
    "Vegetables": {"temp_min": 1, "temp_max": 7, "humidity_min": 90, "humidity_max": 98},
    "Meat": {"temp_min": -2, "temp_max": 2, "humidity_min": 75, "humidity_max": 85}
}

# Historical decay rates by supplier (simulation)
SUPPLIER_HISTORY = {
    "Supplier_A": {"avg_decay_rate": 0.95, "reliability_score": 0.92},  # 5% faster decay, 92% reliable
    "Supplier_B": {"avg_decay_rate": 1.0, "reliability_score": 0.98},   # Normal decay, 98% reliable
    "Supplier_C": {"avg_decay_rate": 1.05, "reliability_score": 0.88},  # 5% slower decay, 88% reliable
    "Default": {"avg_decay_rate": 1.0, "reliability_score": 0.90}
}

# Image analysis data store
IMAGE_ANALYSES = {}

def calculate_temperature_impact(current_temp: float, optimal_min: float, optimal_max: float) -> float:
    """
    Calculate temperature impact on RSL.
    Returns a factor between 0.1 (severe) and 1.0 (optimal)
    """
    if optimal_min <= current_temp <= optimal_max:
        return 1.0  # Optimal temperature
    
    # Calculate deviation
    if current_temp < optimal_min:
        deviation = optimal_min - current_temp
    else:
        deviation = current_temp - optimal_max
    
    # Each degree of deviation reduces shelf life
    # 1°C deviation = 5% reduction, exponential increase
    impact_factor = max(0.1, 1.0 - (deviation * 0.05) ** 1.2)
    return round(impact_factor, 3)

def calculate_humidity_impact(current_humidity: float, optimal_min: float, optimal_max: float) -> float:
    """
    Calculate humidity impact on RSL.
    Returns a factor between 0.3 and 1.0
    """
    if optimal_min <= current_humidity <= optimal_max:
        return 1.0  # Optimal humidity
    
    # Calculate deviation
    if current_humidity < optimal_min:
        deviation = optimal_min - current_humidity
    else:
        deviation = current_humidity - optimal_max
    
    # Each 5% humidity deviation = 3% RSL reduction
    impact_factor = max(0.3, 1.0 - (deviation / 5) * 0.03)
    return round(impact_factor, 3)

def calculate_logistics_impact(handling_events: int, cold_chain_breaks: int, transport_days: float) -> float:
    """
    Calculate logistics/transport impact on RSL.
    """
    base_factor = 1.0
    
    # Each handling event reduces RSL by 2%
    handling_impact = max(0.8, 1.0 - (handling_events * 0.02))
    
    # Each cold chain break reduces RSL by 10%
    cold_chain_impact = max(0.5, 1.0 - (cold_chain_breaks * 0.10))
    
    # Extended transport (>2 days) reduces RSL
    transport_impact = max(0.7, 1.0 - max(0, transport_days - 2) * 0.05)
    
    return round(handling_impact * cold_chain_impact * transport_impact, 3)

def calculate_age_factor(days_since_manufacture: int, base_shelf_life: int) -> float:
    """
    Calculate age-based decay factor using exponential decay model.
    """
    if days_since_manufacture <= 0:
        return 1.0
    
    # Exponential decay: RSL decreases faster as product ages
    age_ratio = days_since_manufacture / base_shelf_life
    
    if age_ratio >= 1:
        return 0.0  # Past expiry
    
    # Exponential decay curve
    factor = math.exp(-2.5 * age_ratio)
    return round(max(0.0, min(1.0, factor)), 3)

def analyze_image_for_spoilage(image_data: bytes, product_category: str) -> Dict:
    """
    Analyze image for visual signs of spoilage.
    Returns spoilage indicators and confidence scores.
    
    In production, this would use a trained CNN model (EfficientNet/ResNet).
    For demo, we simulate based on image characteristics.
    """
    # Calculate image hash for consistency
    image_hash = hashlib.md5(image_data).hexdigest()
    
    # Simulate image analysis based on hash (deterministic for same image)
    hash_num = int(image_hash[:8], 16)
    random.seed(hash_num)
    
    # Simulate detection of various spoilage indicators
    analysis = {
        "image_hash": image_hash[:16],
        "analysis_timestamp": datetime.now().isoformat(),
        "file_size_kb": len(image_data) / 1024,
        "spoilage_indicators": {},
        "overall_quality_score": 0,
        "rsl_adjustment_factor": 1.0,
        "recommendations": []
    }
    
    # Category-specific spoilage detection simulation
    if product_category == "Dairy":
        mold_score = random.uniform(0, 100)
        discoloration_score = random.uniform(0, 100)
        bloating_score = random.uniform(0, 100)
        
        analysis["spoilage_indicators"] = {
            "mold_detection": {"score": mold_score, "detected": mold_score > 70},
            "discoloration": {"score": discoloration_score, "detected": discoloration_score > 60},
            "package_bloating": {"score": bloating_score, "detected": bloating_score > 80}
        }
        
    elif product_category == "Fruits":
        bruising_score = random.uniform(0, 100)
        mold_score = random.uniform(0, 100)
        overripe_score = random.uniform(0, 100)
        dehydration_score = random.uniform(0, 100)
        
        analysis["spoilage_indicators"] = {
            "bruising": {"score": bruising_score, "detected": bruising_score > 50},
            "mold_growth": {"score": mold_score, "detected": mold_score > 65},
            "overripeness": {"score": overripe_score, "detected": overripe_score > 55},
            "dehydration": {"score": dehydration_score, "detected": dehydration_score > 70}
        }
        
    elif product_category == "Vegetables":
        wilting_score = random.uniform(0, 100)
        discoloration_score = random.uniform(0, 100)
        slime_score = random.uniform(0, 100)
        
        analysis["spoilage_indicators"] = {
            "wilting": {"score": wilting_score, "detected": wilting_score > 45},
            "discoloration": {"score": discoloration_score, "detected": discoloration_score > 55},
            "slime_formation": {"score": slime_score, "detected": slime_score > 75}
        }
        
    elif product_category == "Meat":
        discoloration_score = random.uniform(0, 100)
        slime_score = random.uniform(0, 100)
        texture_score = random.uniform(0, 100)
        
        analysis["spoilage_indicators"] = {
            "discoloration": {"score": discoloration_score, "detected": discoloration_score > 40},
            "slime_formation": {"score": slime_score, "detected": slime_score > 60},
            "texture_degradation": {"score": texture_score, "detected": texture_score > 55}
        }
    
    # Calculate overall quality score
    indicator_scores = [ind["score"] for ind in analysis["spoilage_indicators"].values()]
    avg_spoilage = sum(indicator_scores) / len(indicator_scores) if indicator_scores else 0
    analysis["overall_quality_score"] = round(100 - avg_spoilage, 2)
    
    # Calculate RSL adjustment factor based on visual analysis
    detected_issues = sum(1 for ind in analysis["spoilage_indicators"].values() if ind["detected"])
    total_indicators = len(analysis["spoilage_indicators"])
    
    if detected_issues == 0:
        analysis["rsl_adjustment_factor"] = 1.0
        analysis["recommendations"].append("Product appears fresh - no visual spoilage detected")
    elif detected_issues == 1:
        analysis["rsl_adjustment_factor"] = 0.8
        analysis["recommendations"].append("Minor quality concerns detected - consider priority sale")
    elif detected_issues == 2:
        analysis["rsl_adjustment_factor"] = 0.5
        analysis["recommendations"].append("Multiple quality issues - immediate markdown recommended")
    else:
        analysis["rsl_adjustment_factor"] = 0.2
        analysis["recommendations"].append("Severe spoilage detected - consider disposal")
    
    # Reset random seed
    random.seed()
    
    return analysis

def calculate_rsl(
    product_name: str,
    category: str,
    manufacture_date: str,
    current_temp: float,
    current_humidity: float,
    handling_events: int = 0,
    cold_chain_breaks: int = 0,
    transport_days: float = 1,
    supplier: str = "Default",
    image_analysis: Dict = None
) -> Dict:
    """
    Comprehensive RSL (Remaining Shelf Life) calculation.
    
    Considers:
    1. Base shelf life for product type
    2. Days since manufacture (age factor)
    3. Current storage conditions (temperature & humidity)
    4. Logistics factors (handling, cold chain breaks, transport time)
    5. Historical supplier data
    6. Visual analysis from images (if available)
    """
    
    # Get base shelf life
    base_shelf_life = BASE_SHELF_LIFE.get(category, {}).get(product_name, 7)
    
    # Get optimal conditions for category
    conditions = OPTIMAL_CONDITIONS.get(category, OPTIMAL_CONDITIONS["Dairy"])
    
    # Calculate days since manufacture
    try:
        mfg_date = datetime.fromisoformat(manufacture_date.replace('Z', '+00:00'))
        days_since_mfg = (datetime.now() - mfg_date.replace(tzinfo=None)).days
    except:
        days_since_mfg = 0
    
    # Calculate individual impact factors
    temp_factor = calculate_temperature_impact(current_temp, conditions["temp_min"], conditions["temp_max"])
    humidity_factor = calculate_humidity_impact(current_humidity, conditions["humidity_min"], conditions["humidity_max"])
    logistics_factor = calculate_logistics_impact(handling_events, cold_chain_breaks, transport_days)
    age_factor = calculate_age_factor(days_since_mfg, base_shelf_life)
    
    # Get supplier historical factor
    supplier_data = SUPPLIER_HISTORY.get(supplier, SUPPLIER_HISTORY["Default"])
    supplier_factor = supplier_data["avg_decay_rate"]
    
    # Image analysis factor (if available)
    image_factor = 1.0
    if image_analysis:
        image_factor = image_analysis.get("rsl_adjustment_factor", 1.0)
    
    # Calculate combined RSL factor
    combined_factor = (
        temp_factor * 0.25 +           # 25% weight for temperature
        humidity_factor * 0.15 +       # 15% weight for humidity
        logistics_factor * 0.15 +      # 15% weight for logistics
        age_factor * 0.25 +            # 25% weight for age
        supplier_factor * 0.10 +       # 10% weight for supplier history
        image_factor * 0.10            # 10% weight for visual analysis
    )
    
    # Calculate RSL in days
    remaining_from_base = max(0, base_shelf_life - days_since_mfg)
    rsl_days = round(remaining_from_base * combined_factor, 1)
    
    # Calculate RSL in hours for precision
    rsl_hours = round(rsl_days * 24, 1)
    
    # Determine quality grade
    rsl_percentage = (rsl_days / base_shelf_life) * 100 if base_shelf_life > 0 else 0
    if rsl_percentage >= 70:
        grade = "A"
        status = "Fresh"
    elif rsl_percentage >= 50:
        grade = "B"
        status = "Good"
    elif rsl_percentage >= 30:
        grade = "C"
        status = "Fair - Consider Markdown"
    elif rsl_percentage > 0:
        grade = "D"
        status = "Poor - Urgent Sale Required"
    else:
        grade = "F"
        status = "Expired - Do Not Sell"
    
    # Calculate decay score (inverse of RSL percentage)
    decay_score = round(100 - rsl_percentage, 2)
    
    return {
        "product_name": product_name,
        "category": category,
        "base_shelf_life_days": base_shelf_life,
        "days_since_manufacture": days_since_mfg,
        "rsl_days": rsl_days,
        "rsl_hours": rsl_hours,
        "rsl_percentage": round(rsl_percentage, 2),
        "decay_score": decay_score,
        "quality_grade": grade,
        "status": status,
        "expiry_date": (datetime.now() + timedelta(days=rsl_days)).isoformat(),
        "factors": {
            "temperature": {"factor": temp_factor, "current": current_temp, "optimal_range": f"{conditions['temp_min']}-{conditions['temp_max']}°C"},
            "humidity": {"factor": humidity_factor, "current": current_humidity, "optimal_range": f"{conditions['humidity_min']}-{conditions['humidity_max']}%"},
            "logistics": {"factor": logistics_factor, "handling_events": handling_events, "cold_chain_breaks": cold_chain_breaks},
            "age": {"factor": age_factor, "days_since_manufacture": days_since_mfg},
            "supplier": {"factor": supplier_factor, "supplier_name": supplier},
            "visual_analysis": {"factor": image_factor, "has_image": image_analysis is not None}
        },
        "combined_factor": round(combined_factor, 3),
        "recommendations": generate_rsl_recommendations(rsl_days, decay_score, grade, temp_factor, cold_chain_breaks)
    }

def generate_rsl_recommendations(rsl_days: float, decay_score: float, grade: str, temp_factor: float, cold_chain_breaks: int) -> List[str]:
    """Generate actionable recommendations based on RSL analysis."""
    recommendations = []
    
    if rsl_days <= 1:
        recommendations.append("🚨 URGENT: Product expires within 24 hours - immediate markdown or disposal required")
    elif rsl_days <= 2:
        recommendations.append("⚠️ Product expires soon - apply 40-60% markdown")
    elif rsl_days <= 3:
        recommendations.append("📢 Consider promotional pricing - 20-30% discount recommended")
    
    if temp_factor < 0.7:
        recommendations.append("🌡️ Temperature deviation detected - verify cold chain integrity")
    
    if cold_chain_breaks > 0:
        recommendations.append(f"❄️ {cold_chain_breaks} cold chain break(s) recorded - prioritize for sale")
    
    if grade in ["C", "D"]:
        recommendations.append("📦 Move to high-traffic display area for quick sale")
    
    if decay_score > 70:
        recommendations.append("🔄 Consider donation to food banks if unsold by end of day")
    
    if not recommendations:
        recommendations.append("✅ Product in good condition - normal shelf placement")
    
    return recommendations

# ============ IN-MEMORY DATA STORE ============

SAMPLE_DATA = {
    "products": [],
    "batches": [],
    "alerts": [],
    "predictions": []
}

CATEGORIES = ["Dairy", "Fruits", "Vegetables", "Meat"]
PRODUCT_NAMES = {
    "Dairy": ["Milk", "Cheese", "Yogurt", "Butter", "Cream"],
    "Fruits": ["Apples", "Bananas", "Oranges", "Strawberries", "Grapes"],
    "Vegetables": ["Lettuce", "Tomatoes", "Carrots", "Broccoli", "Spinach"],
    "Meat": ["Chicken", "Beef", "Pork", "Fish", "Turkey"]
}

# Product base prices in INR per kg/liter
PRODUCT_PRICES = {
    "Milk": 60, "Cheese": 450, "Yogurt": 80, "Butter": 500, "Cream": 350,
    "Apples": 150, "Bananas": 50, "Oranges": 80, "Strawberries": 400, "Grapes": 120,
    "Lettuce": 40, "Tomatoes": 30, "Carrots": 35, "Broccoli": 60, "Spinach": 45,
    "Chicken": 180, "Beef": 450, "Pork": 320, "Fish": 350, "Turkey": 400
}

def calculate_markdown_price(base_price, decay_score, shelf_life_days, quantity):
    """
    Calculate markdown price based on:
    1. Decay score (higher decay = higher discount)
    2. Shelf life remaining (less time = higher discount)
    3. Inventory level (high quantity = additional discount)
    """
    discount_percent = 0
    
    # Decay-based discount (0-40%)
    if decay_score > 70:
        discount_percent += 35
    elif decay_score > 50:
        discount_percent += 25
    elif decay_score > 30:
        discount_percent += 15
    elif decay_score > 15:
        discount_percent += 5
    
    # Shelf life-based discount (0-30%)
    if shelf_life_days <= 1:
        discount_percent += 30
    elif shelf_life_days <= 2:
        discount_percent += 20
    elif shelf_life_days <= 3:
        discount_percent += 10
    elif shelf_life_days <= 5:
        discount_percent += 5
    
    # Inventory level discount (0-15%)
    if quantity > 400:
        discount_percent += 15
    elif quantity > 300:
        discount_percent += 10
    elif quantity > 200:
        discount_percent += 5
    
    # Cap discount at 75%
    discount_percent = min(discount_percent, 75)
    
    # Calculate final price
    discounted_price = base_price * (1 - discount_percent / 100)
    
    return {
        "original_price": round(base_price, 2),
        "discounted_price": round(discounted_price, 2),
        "discount_percent": round(discount_percent, 2),
        "savings": round(base_price - discounted_price, 2)
    }

# ============ HELPER FUNCTIONS ============

def generate_sample_data():
    """Generate comprehensive sample data with RSL calculations"""
    SAMPLE_DATA["products"] = []
    SAMPLE_DATA["batches"] = []
    SAMPLE_DATA["alerts"] = []
    SAMPLE_DATA["predictions"] = []
    SAMPLE_DATA["sensors"] = []
    
    suppliers = ["Supplier_A", "Supplier_B", "Supplier_C"]
    locations = [
        "Warehouse Delhi", "Warehouse Mumbai", "Warehouse Bangalore",
        "Store Delhi-1", "Store Mumbai-1", "Store Chennai-1", 
        "Store Kolkata-1", "Store Hyderabad-1", "Store Pune-1"
    ]
    
    batch_id = 1
    for category in CATEGORIES:
        for product_name in PRODUCT_NAMES[category]:
            # Add product to products list
            base_price = PRODUCT_PRICES.get(product_name, 100)
            base_shelf_life = BASE_SHELF_LIFE.get(category, {}).get(product_name, 7)
            
            product = {
                "product_id": f"PRD-{category[:3].upper()}-{product_name[:3].upper()}",
                "name": product_name,
                "category": category,
                "unit_price": base_price,
                "unit_cost": round(base_price * 0.6, 2),
                "base_shelf_life_days": base_shelf_life,
                "optimal_temp_min": OPTIMAL_CONDITIONS[category]["temp_min"],
                "optimal_temp_max": OPTIMAL_CONDITIONS[category]["temp_max"],
                "optimal_humidity_min": OPTIMAL_CONDITIONS[category]["humidity_min"],
                "optimal_humidity_max": OPTIMAL_CONDITIONS[category]["humidity_max"]
            }
            SAMPLE_DATA["products"].append(product)
            
            # Create batches for each product (with realistic distribution)
            num_batches = random.randint(2, 4)
            for i in range(num_batches):
                # Generate realistic manufacturing date
                days_ago = random.randint(1, min(base_shelf_life + 2, 15))
                manufacture_date = (datetime.now() - timedelta(days=days_ago)).isoformat()
                
                # Assign supplier and location
                supplier = random.choice(suppliers)
                location = random.choice(locations)
                
                # Generate realistic storage conditions with some variance
                optimal = OPTIMAL_CONDITIONS[category]
                
                # Some batches have temperature issues (20% chance)
                if random.random() < 0.2:
                    temp = round(random.uniform(optimal["temp_max"] + 2, optimal["temp_max"] + 6), 1)
                else:
                    temp = round(random.uniform(optimal["temp_min"], optimal["temp_max"]), 1)
                
                # Humidity
                if random.random() < 0.15:
                    humidity = round(random.uniform(optimal["humidity_max"] + 5, 95), 1)
                else:
                    humidity = round(random.uniform(optimal["humidity_min"], optimal["humidity_max"]), 1)
                
                # Logistics factors
                handling_events = random.choices([0, 1, 2, 3, 4, 5], weights=[30, 25, 20, 15, 7, 3])[0]
                cold_chain_breaks = random.choices([0, 1, 2], weights=[70, 25, 5])[0]
                transport_days = round(random.uniform(0.5, 4), 1)
                
                # Calculate RSL using our comprehensive algorithm
                rsl_result = calculate_rsl(
                    product_name=product_name,
                    category=category,
                    manufacture_date=manufacture_date,
                    current_temp=temp,
                    current_humidity=humidity,
                    handling_events=handling_events,
                    cold_chain_breaks=cold_chain_breaks,
                    transport_days=transport_days,
                    supplier=supplier
                )
                
                # Extract values from RSL calculation
                decay_score = rsl_result["decay_score"]
                shelf_life = rsl_result["rsl_days"]
                grade = rsl_result["quality_grade"]
                
                # Quantity based on age and grade
                quantity = random.randint(50, 500)
                
                # Calculate pricing based on RSL-derived decay score
                pricing = calculate_markdown_price(base_price, decay_score, shelf_life, quantity)
                
                batch = {
                    "batch_id": f"BATCH-{batch_id:04d}",
                    "product_id": product["product_id"],
                    "product_name": product_name,
                    "category": category,
                    "quantity": quantity,
                    "unit": "L" if category == "Dairy" and product_name in ["Milk", "Cream"] else "kg",
                    "manufacture_date": manufacture_date,
                    "received_date": (datetime.fromisoformat(manufacture_date) + timedelta(days=transport_days)).isoformat(),
                    "expiry_date": rsl_result["expiry_date"],
                    "location": location,
                    "supplier": supplier,
                    "temperature": temp,
                    "humidity": humidity,
                    "handling_events": handling_events,
                    "cold_chain_breaks": cold_chain_breaks,
                    "transport_days": transport_days,
                    "decay_score": round(decay_score, 2),
                    "shelf_life_days": round(shelf_life, 1),
                    "rsl_hours": rsl_result["rsl_hours"],
                    "rsl_percentage": rsl_result["rsl_percentage"],
                    "grade": grade,
                    "status": "active" if shelf_life > 0 else "expired",
                    "quality_status": rsl_result["status"],
                    "price_per_unit": pricing["original_price"],
                    "current_price": pricing["discounted_price"],
                    "discount_percent": pricing["discount_percent"],
                    "total_value": round(quantity * pricing["original_price"], 2),
                    "discounted_value": round(quantity * pricing["discounted_price"], 2),
                    "rsl_factors": rsl_result["factors"],
                    "recommendations": rsl_result["recommendations"]
                }
                SAMPLE_DATA["batches"].append(batch)
                
                # Generate correlated sensor readings for this batch
                for hour_offset in range(0, 24, 4):  # Every 4 hours
                    sensor_time = datetime.now() - timedelta(hours=hour_offset)
                    # Add some variance to readings
                    sensor_temp = round(temp + random.uniform(-0.5, 0.5), 1)
                    sensor_humidity = round(humidity + random.uniform(-2, 2), 1)
                    
                    sensor_reading = {
                        "sensor_id": f"SENSOR-{location.replace(' ', '-')}-{random.randint(1,5):02d}",
                        "batch_id": batch["batch_id"],
                        "product_id": product["product_id"],
                        "temperature": sensor_temp,
                        "humidity": sensor_humidity,
                        "timestamp": sensor_time.isoformat(),
                        "location": location
                    }
                    SAMPLE_DATA["sensors"].append(sensor_reading)
                
                # Generate alert if conditions warrant
                if decay_score > 60 or shelf_life <= 2 or cold_chain_breaks > 0:
                    if decay_score > 75 or shelf_life <= 1:
                        severity = "CRITICAL"
                        alert_type = "CRITICAL_DECAY" if decay_score > 75 else "IMMINENT_EXPIRY"
                    elif decay_score > 60 or cold_chain_breaks > 0:
                        severity = "HIGH"
                        alert_type = "HIGH_DECAY" if decay_score > 60 else "COLD_CHAIN_BREAK"
                    else:
                        severity = "MEDIUM"
                        alert_type = "APPROACHING_EXPIRY"
                    
                    alert = {
                        "alert_id": f"ALERT-{len(SAMPLE_DATA['alerts']) + 1:04d}",
                        "batch_id": batch["batch_id"],
                        "product_id": product["product_id"],
                        "product_name": product_name,
                        "category": category,
                        "severity": severity,
                        "alert_type": alert_type,
                        "title": f"{severity}: {product_name} requires attention",
                        "message": f"Batch {batch['batch_id']}: RSL={shelf_life:.1f} days, Decay={decay_score:.1f}%, Grade={grade}",
                        "location": location,
                        "decay_score": round(decay_score, 2),
                        "rsl_days": round(shelf_life, 1),
                        "recommendations": rsl_result["recommendations"],
                        "created_at": datetime.now().isoformat(),
                        "acknowledged": False
                    }
                    SAMPLE_DATA["alerts"].append(alert)
                
                batch_id += 1
    
    return len(SAMPLE_DATA["batches"])

# NOTE: Data starts empty. Use "Load Sample Data" button or API to load data.
# Uncomment line below to auto-load sample data on startup:
# generate_sample_data()

# ============ ROOT ENDPOINTS ============

@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "name": "Decay Optimization Platform",
        "version": "1.0.0",
        "description": "AI-driven decay analysis and shelf-life prediction for perishable goods",
        "categories": CATEGORIES,
        "total_batches": len(SAMPLE_DATA["batches"]),
        "total_alerts": len(SAMPLE_DATA["alerts"]),
        "documentation": "/api/docs",
        "health": "/health",
        "timestamp": datetime.now().isoformat()
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "components": {
            "database": "healthy",
            "sample_data": f"{len(SAMPLE_DATA['batches'])} batches loaded",
            "api": "healthy"
        },
        "timestamp": datetime.now().isoformat()
    }

# ============ ANALYTICS ENDPOINTS ============

@app.get("/api/v1/analytics/dashboard")
async def get_dashboard_metrics():
    """Get dashboard metrics"""
    batches = SAMPLE_DATA["batches"]
    
    # Return empty data if no batches (after flush)
    if not batches:
        return {
            "summary": {
                "total_active_batches": 0,
                "total_predicted": 0,
                "average_decay_score": 0,
                "total_quantity": 0,
                "total_inventory_value": 0,
                "value_at_risk": 0,
                "currency": "INR"
            },
            "risk_breakdown": {"critical": 0, "high": 0, "medium": 0, "low": 0},
            "grade_distribution": {"A": 0, "B": 0, "C": 0, "D": 0},
            "by_category": {},
            "message": "No data available. Please load sample data or upload your own data."
        }
    
    total_batches = len(batches)
    total_quantity = sum(b["quantity"] for b in batches)
    avg_decay = sum(b["decay_score"] for b in batches) / total_batches if total_batches > 0 else 0
    
    # Risk breakdown
    critical = len([b for b in batches if b["decay_score"] > 75])
    high = len([b for b in batches if 60 < b["decay_score"] <= 75])
    medium = len([b for b in batches if 40 < b["decay_score"] <= 60])
    low = len([b for b in batches if b["decay_score"] <= 40])
    
    # Grade distribution (including F for expired)
    grade_dist = {"A": 0, "B": 0, "C": 0, "D": 0, "F": 0}
    for batch in batches:
        grade = batch.get("grade", "D")
        if grade in grade_dist:
            grade_dist[grade] += 1
        else:
            grade_dist["D"] += 1  # Default to D for unknown grades
    
    # By category
    by_category = {}
    for category in CATEGORIES:
        cat_batches = [b for b in batches if b["category"] == category]
        if cat_batches:
            by_category[category] = {
                "count": len(cat_batches),
                "avg_decay": round(sum(b["decay_score"] for b in cat_batches) / len(cat_batches), 2),
                "total_quantity": sum(b["quantity"] for b in cat_batches)
            }
    
    # Calculate value at risk (critical and high decay batches)
    at_risk_batches = [b for b in batches if b["decay_score"] > 60]
    value_at_risk = sum(b.get("discounted_value", 0) for b in at_risk_batches)
    total_inventory_value = sum(b.get("total_value", 0) for b in batches)
    
    return {
        "summary": {
            "total_active_batches": total_batches,
            "total_predicted": total_batches,
            "average_decay_score": round(avg_decay, 2),
            "total_quantity": total_quantity,
            "total_inventory_value": round(total_inventory_value, 2),
            "value_at_risk": round(value_at_risk, 2),
            "currency": "INR"
        },
        "risk_breakdown": {
            "critical": critical,
            "high": high,
            "medium": medium,
            "low": low
        },
        "grade_distribution": grade_dist,
        "by_category": by_category
    }

@app.get("/api/v1/analytics/trends")
async def get_decay_trends(days: int = 14, category: Optional[str] = None):
    """Get decay trends over time using actual batch data"""
    batches = SAMPLE_DATA["batches"]
    alerts = SAMPLE_DATA["alerts"]
    
    if category:
        batches = [b for b in batches if b["category"] == category]
        alerts = [a for a in alerts if a.get("category") == category]
    
    data_points = []
    for i in range(days):
        date = (datetime.now() - timedelta(days=days - i - 1)).strftime("%Y-%m-%d")
        
        # Get batches received on this date
        day_batches = [b for b in batches if b.get("manufacture_date", "")[:10] == date or 
                       b.get("received_date", "")[:10] == date]
        
        # Calculate average decay for the day
        if day_batches:
            avg_decay = sum(b["decay_score"] for b in day_batches) / len(day_batches)
        else:
            # Use overall average if no batches for this day
            avg_decay = sum(b["decay_score"] for b in batches) / len(batches) if batches else 0
            # Add some variance for visualization
            avg_decay = max(0, min(100, avg_decay + random.uniform(-15, 15)))
        
        # Count alerts for this day
        day_alerts = len([a for a in alerts if a.get("created_at", "")[:10] == date])
        
        data_points.append({
            "date": date,
            "avg_decay": round(avg_decay, 2),
            "batches_predicted": len(day_batches) or random.randint(5, 15),
            "alerts_generated": day_alerts or random.randint(0, 3)
        })
    
    return {
        "data": data_points,
        "period": f"{days} days",
        "category": category
    }

# ============ ALERTS ENDPOINTS ============

@app.get("/api/v1/alerts/")
async def get_alerts(limit: int = 10, severity: Optional[str] = None):
    """Get alerts"""
    alerts = SAMPLE_DATA["alerts"]
    
    if severity:
        alerts = [a for a in alerts if a["severity"] == severity]
    
    return alerts[:limit]

@app.get("/api/v1/alerts/summary")
async def get_alerts_summary():
    """Get alerts summary"""
    alerts = SAMPLE_DATA["alerts"]
    return {
        "total_active": len([a for a in alerts if not a.get("acknowledged", False)]),
        "total_acknowledged": len([a for a in alerts if a.get("acknowledged", False)]),
        "by_severity": {
            "critical": len([a for a in alerts if a["severity"] == "CRITICAL"]),
            "high": len([a for a in alerts if a["severity"] == "HIGH"]),
            "medium": len([a for a in alerts if a["severity"] == "MEDIUM"]),
            "low": len([a for a in alerts if a["severity"] == "LOW"])
        }
    }

@app.post("/api/v1/alerts/{alert_id}/acknowledge")
async def acknowledge_alert(alert_id: str, data: Dict[str, Any] = None):
    """Acknowledge an alert"""
    for alert in SAMPLE_DATA["alerts"]:
        if alert["alert_id"] == alert_id:
            alert["acknowledged"] = True
            alert["is_acknowledged"] = True
            alert["acknowledged_at"] = datetime.now().isoformat()
            alert["acknowledged_by"] = data.get("user", "system") if data else "system"
            return {"message": "Alert acknowledged", "alert": alert}
    
    raise HTTPException(status_code=404, detail="Alert not found")

@app.delete("/api/v1/alerts/{alert_id}")
async def delete_alert(alert_id: str):
    """Delete/dismiss an alert"""
    for i, alert in enumerate(SAMPLE_DATA["alerts"]):
        if alert["alert_id"] == alert_id:
            SAMPLE_DATA["alerts"].pop(i)
            return {"message": "Alert dismissed", "alert_id": alert_id}
    
    raise HTTPException(status_code=404, detail="Alert not found")

# ============ INVENTORY ENDPOINTS ============

@app.get("/api/v1/inventory/batches")
async def get_batches(category: Optional[str] = None, status: Optional[str] = None):
    """Get inventory batches"""
    batches = SAMPLE_DATA["batches"]
    
    if category:
        batches = [b for b in batches if b["category"] == category]
    
    if status:
        batches = [b for b in batches if b["status"] == status]
    
    # Add frontend-expected fields
    enriched_batches = []
    for b in batches:
        batch = {**b}
        # Map field names for frontend compatibility
        batch["quality_grade"] = b.get("grade", "D")
        batch["days_remaining"] = b.get("shelf_life_days", 0)
        # Determine action urgency
        decay = b.get("decay_score", 0)
        if decay > 75 or batch["days_remaining"] <= 1:
            batch["action_urgency"] = "critical"
        elif decay > 60 or batch["days_remaining"] <= 2:
            batch["action_urgency"] = "high"
        elif decay > 40:
            batch["action_urgency"] = "medium"
        else:
            batch["action_urgency"] = "low"
        enriched_batches.append(batch)
    
    return {"batches": enriched_batches}

@app.get("/api/v1/inventory/summary")
async def get_inventory_summary():
    """Get inventory summary"""
    batches = SAMPLE_DATA["batches"]
    
    by_category = {}
    for category in CATEGORIES:
        cat_batches = [b for b in batches if b["category"] == category]
        by_category[category] = {
            "count": len(cat_batches),
            "total_quantity": sum(b["quantity"] for b in cat_batches)
        }
    
    return {
        "total_batches": len(batches),
        "total_quantity": sum(b["quantity"] for b in batches),
        "by_category": by_category,
        "by_grade": {
            "A": len([b for b in batches if b.get("grade") == "A"]),
            "B": len([b for b in batches if b.get("grade") == "B"]),
            "C": len([b for b in batches if b.get("grade") == "C"]),
            "D": len([b for b in batches if b.get("grade") == "D"]),
            "F": len([b for b in batches if b.get("grade") == "F"])
        }
    }

@app.get("/api/v1/inventory/locations")
async def get_locations():
    """Get all locations with batch counts"""
    location_data = {}
    for b in SAMPLE_DATA["batches"]:
        loc = b["location"]
        if loc not in location_data:
            location_data[loc] = {"location": loc, "active_batches": 0}
        location_data[loc]["active_batches"] += 1
    
    return {"locations": list(location_data.values())}

@app.patch("/api/v1/inventory/batches/{batch_id}/status")
async def update_batch_status(batch_id: str, status: str = "markdown"):
    """Update batch status (e.g., apply markdown)"""
    for batch in SAMPLE_DATA["batches"]:
        if batch["batch_id"] == batch_id:
            old_status = batch.get("status", "active")
            batch["status"] = status
            batch["status_updated_at"] = datetime.now().isoformat()
            
            # If applying markdown, update price
            if status == "markdown":
                batch["markdown_applied"] = True
                batch["markdown_applied_at"] = datetime.now().isoformat()
            
            return {
                "message": f"Batch {batch_id} status updated to {status}",
                "batch_id": batch_id,
                "old_status": old_status,
                "new_status": status,
                "timestamp": datetime.now().isoformat()
            }
    
    raise HTTPException(status_code=404, detail=f"Batch {batch_id} not found")

# ============ RSL CALCULATION ENDPOINTS ============

@app.post("/api/v1/rsl/calculate")
async def calculate_rsl_endpoint(
    product_name: str = Form(...),
    category: str = Form(...),
    manufacture_date: str = Form(...),
    current_temp: float = Form(...),
    current_humidity: float = Form(...),
    handling_events: int = Form(0),
    cold_chain_breaks: int = Form(0),
    transport_days: float = Form(1),
    supplier: str = Form("Default")
):
    """
    Calculate Remaining Shelf Life (RSL) for a product.
    
    Considers:
    - Base shelf life for product type
    - Days since manufacture
    - Current storage conditions (temperature & humidity)
    - Logistics factors (handling events, cold chain breaks)
    - Historical supplier data
    """
    result = calculate_rsl(
        product_name=product_name,
        category=category,
        manufacture_date=manufacture_date,
        current_temp=current_temp,
        current_humidity=current_humidity,
        handling_events=handling_events,
        cold_chain_breaks=cold_chain_breaks,
        transport_days=transport_days,
        supplier=supplier
    )
    return result

@app.get("/api/v1/rsl/batch/{batch_id}")
async def get_batch_rsl(batch_id: str):
    """Get RSL calculation for a specific batch"""
    batch = next((b for b in SAMPLE_DATA["batches"] if b["batch_id"] == batch_id), None)
    if not batch:
        raise HTTPException(status_code=404, detail="Batch not found")
    
    # Get sensor data for this batch
    sensor_data = next((s for s in SAMPLE_DATA.get("sensors", []) if s.get("batch_id") == batch_id), None)
    current_temp = sensor_data.get("temperature", 4.0) if sensor_data else batch.get("temperature", 4.0)
    current_humidity = sensor_data.get("humidity", 65.0) if sensor_data else batch.get("humidity", 65.0)
    
    # Get image analysis if available
    image_analysis = IMAGE_ANALYSES.get(batch_id)
    
    result = calculate_rsl(
        product_name=batch["product_name"],
        category=batch["category"],
        manufacture_date=batch["manufacture_date"],
        current_temp=current_temp,
        current_humidity=current_humidity,
        handling_events=batch.get("handling_events", 0),
        cold_chain_breaks=batch.get("cold_chain_breaks", 0),
        transport_days=batch.get("transport_days", 1),
        supplier=batch.get("supplier", "Default"),
        image_analysis=image_analysis
    )
    
    result["batch_id"] = batch_id
    result["location"] = batch["location"]
    result["quantity"] = batch["quantity"]
    
    return result

@app.get("/api/v1/rsl/all")
async def get_all_rsl():
    """Get RSL calculations for all batches"""
    rsl_results = []
    
    for batch in SAMPLE_DATA["batches"]:
        # Get image analysis if available
        image_analysis = IMAGE_ANALYSES.get(batch["batch_id"])
        
        result = calculate_rsl(
            product_name=batch["product_name"],
            category=batch["category"],
            manufacture_date=batch["manufacture_date"],
            current_temp=batch.get("temperature", 4.0),
            current_humidity=batch.get("humidity", 65.0),
            handling_events=batch.get("handling_events", 0),
            cold_chain_breaks=batch.get("cold_chain_breaks", 0),
            transport_days=batch.get("transport_days", 1),
            supplier=batch.get("supplier", "Default"),
            image_analysis=image_analysis
        )
        
        result["batch_id"] = batch["batch_id"]
        result["location"] = batch["location"]
        result["quantity"] = batch["quantity"]
        rsl_results.append(result)
    
    # Sort by RSL days (ascending - most urgent first)
    rsl_results.sort(key=lambda x: x["rsl_days"])
    
    return {
        "total_batches": len(rsl_results),
        "critical_count": len([r for r in rsl_results if r["rsl_days"] <= 2]),
        "warning_count": len([r for r in rsl_results if 2 < r["rsl_days"] <= 5]),
        "results": rsl_results,
        "timestamp": datetime.now().isoformat()
    }

# ============ IMAGE UPLOAD & ANALYSIS ENDPOINTS ============

@app.post("/api/v1/images/upload/shelf")
async def upload_shelf_image(
    batch_id: str = Form(...),
    file: UploadFile = File(...)
):
    """
    Upload an image of products on the shelf for visual spoilage analysis.
    """
    # Validate file type
    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="File must be an image")
    
    # Read image data
    image_data = await file.read()
    
    # Get batch info
    batch = next((b for b in SAMPLE_DATA["batches"] if b["batch_id"] == batch_id), None)
    if not batch:
        raise HTTPException(status_code=404, detail="Batch not found")
    
    # Analyze image for spoilage
    analysis = analyze_image_for_spoilage(image_data, batch["category"])
    
    # Save image
    filename = f"{batch_id}_shelf_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
    filepath = Path(f"static/images/shelf/{filename}")
    with open(filepath, "wb") as f:
        f.write(image_data)
    
    # Store analysis
    IMAGE_ANALYSES[batch_id] = {
        **analysis,
        "image_type": "shelf",
        "image_path": f"/static/images/shelf/{filename}",
        "batch_id": batch_id
    }
    
    # Recalculate RSL with image analysis
    updated_rsl = calculate_rsl(
        product_name=batch["product_name"],
        category=batch["category"],
        manufacture_date=batch["manufacture_date"],
        current_temp=batch.get("temperature", 4.0),
        current_humidity=batch.get("humidity", 65.0),
        handling_events=batch.get("handling_events", 0),
        cold_chain_breaks=batch.get("cold_chain_breaks", 0),
        transport_days=batch.get("transport_days", 1),
        supplier=batch.get("supplier", "Default"),
        image_analysis=analysis
    )
    
    return {
        "message": "Shelf image uploaded and analyzed successfully",
        "batch_id": batch_id,
        "image_path": f"/static/images/shelf/{filename}",
        "analysis": analysis,
        "updated_rsl": updated_rsl
    }

@app.post("/api/v1/images/upload/backroom")
async def upload_backroom_image(
    batch_id: str = Form(...),
    file: UploadFile = File(...)
):
    """
    Upload an image of products in the backroom for visual spoilage analysis.
    """
    # Validate file type
    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="File must be an image")
    
    # Read image data
    image_data = await file.read()
    
    # Get batch info
    batch = next((b for b in SAMPLE_DATA["batches"] if b["batch_id"] == batch_id), None)
    if not batch:
        raise HTTPException(status_code=404, detail="Batch not found")
    
    # Analyze image for spoilage
    analysis = analyze_image_for_spoilage(image_data, batch["category"])
    
    # Save image
    filename = f"{batch_id}_backroom_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
    filepath = Path(f"static/images/backroom/{filename}")
    with open(filepath, "wb") as f:
        f.write(image_data)
    
    # Store analysis (backroom images may have different conditions)
    IMAGE_ANALYSES[f"{batch_id}_backroom"] = {
        **analysis,
        "image_type": "backroom",
        "image_path": f"/static/images/backroom/{filename}",
        "batch_id": batch_id
    }
    
    # If no shelf image exists, use backroom analysis for RSL
    if batch_id not in IMAGE_ANALYSES:
        IMAGE_ANALYSES[batch_id] = {
            **analysis,
            "image_type": "backroom",
            "image_path": f"/static/images/backroom/{filename}",
            "batch_id": batch_id
        }
    
    # Recalculate RSL with image analysis
    updated_rsl = calculate_rsl(
        product_name=batch["product_name"],
        category=batch["category"],
        manufacture_date=batch["manufacture_date"],
        current_temp=batch.get("temperature", 4.0),
        current_humidity=batch.get("humidity", 65.0),
        handling_events=batch.get("handling_events", 0),
        cold_chain_breaks=batch.get("cold_chain_breaks", 0),
        transport_days=batch.get("transport_days", 1),
        supplier=batch.get("supplier", "Default"),
        image_analysis=analysis
    )
    
    return {
        "message": "Backroom image uploaded and analyzed successfully",
        "batch_id": batch_id,
        "image_path": f"/static/images/backroom/{filename}",
        "analysis": analysis,
        "updated_rsl": updated_rsl
    }

@app.get("/api/v1/images/analysis/{batch_id}")
async def get_image_analysis(batch_id: str):
    """Get image analysis results for a batch"""
    shelf_analysis = IMAGE_ANALYSES.get(batch_id)
    backroom_analysis = IMAGE_ANALYSES.get(f"{batch_id}_backroom")
    
    if not shelf_analysis and not backroom_analysis:
        raise HTTPException(status_code=404, detail="No image analysis found for this batch")
    
    return {
        "batch_id": batch_id,
        "shelf_analysis": shelf_analysis,
        "backroom_analysis": backroom_analysis,
        "timestamp": datetime.now().isoformat()
    }

@app.get("/api/v1/images/all")
async def get_all_image_analyses():
    """Get all image analyses"""
    return {
        "total_analyses": len(IMAGE_ANALYSES),
        "analyses": list(IMAGE_ANALYSES.values()),
        "timestamp": datetime.now().isoformat()
    }

# ============ UPLOAD ENDPOINTS ============

@app.post("/api/v1/upload/sample-data")
async def load_sample_data():
    """Load fresh sample data"""
    count = generate_sample_data()
    return {
        "message": "Sample data loaded successfully",
        "batches_created": count,
        "alerts_created": len(SAMPLE_DATA["alerts"]),
        "timestamp": datetime.now().isoformat()
    }

@app.post("/api/v1/upload/flush-data")
async def flush_all_data():
    """Flush all data - clear everything including sensors for Cold Chain"""
    SAMPLE_DATA["products"] = []
    SAMPLE_DATA["batches"] = []
    SAMPLE_DATA["alerts"] = []
    SAMPLE_DATA["predictions"] = []
    SAMPLE_DATA["sensors"] = []  # Flush sensor data for Cold Chain
    return {
        "message": "All data flushed successfully",
        "batches_remaining": 0,
        "alerts_remaining": 0,
        "sensors_remaining": 0,
        "timestamp": datetime.now().isoformat()
    }

@app.get("/api/v1/upload/data-stats")
async def get_data_stats():
    """Get current data statistics"""
    return {
        "total_batches": len(SAMPLE_DATA["batches"]),
        "total_alerts": len(SAMPLE_DATA["alerts"]),
        "total_products": len(SAMPLE_DATA["products"]),
        "timestamp": datetime.now().isoformat()
    }

# Upload history storage
UPLOAD_HISTORY = []

@app.get("/api/v1/upload/history")
async def get_upload_history(limit: int = 20):
    """Get upload history"""
    return {
        "uploads": UPLOAD_HISTORY[-limit:] if UPLOAD_HISTORY else [],
        "total": len(UPLOAD_HISTORY)
    }

@app.post("/api/v1/upload/products")
async def upload_products(file: UploadFile = File(...)):
    """Upload products CSV and process into system"""
    import csv
    import io
    
    content = await file.read()
    decoded = content.decode('utf-8')
    reader = csv.DictReader(io.StringIO(decoded))
    
    products_added = 0
    for row in reader:
        product = {
            "product_id": row.get("product_id", f"PRD-{products_added+1:04d}"),
            "name": row.get("name", "Unknown"),
            "category": row.get("category", "Dairy"),
            "unit_price": float(row.get("unit_price", 100)),
            "unit_cost": float(row.get("unit_cost", 50)),
            "packaging_type": row.get("packaging_type", "Standard"),
            "base_shelf_life_days": int(row.get("base_shelf_life_days", row.get("listed_shelf_life_days", 7))),
            "optimal_temp_min": float(row.get("optimal_temp_min", 2)),
            "optimal_temp_max": float(row.get("optimal_temp_max", 8)),
            "optimal_humidity_min": float(row.get("optimal_humidity_min", 60)),
            "optimal_humidity_max": float(row.get("optimal_humidity_max", 90)),
            "supplier": row.get("supplier", "Default")
        }
        SAMPLE_DATA["products"].append(product)
        products_added += 1
    
    # Record upload history
    UPLOAD_HISTORY.append({
        "id": len(UPLOAD_HISTORY) + 1,
        "filename": file.filename,
        "upload_type": "products",
        "records_processed": products_added,
        "status": "success",
        "uploaded_at": datetime.now().isoformat()
    })
    
    return {
        "message": "Products uploaded successfully",
        "filename": file.filename,
        "processed": products_added,
        "records_processed": products_added
    }

@app.post("/api/v1/upload/inventory")
async def upload_inventory(file: UploadFile = File(...)):
    """Upload inventory CSV and generate RSL, alerts, and markdown recommendations"""
    import csv
    import io
    
    content = await file.read()
    decoded = content.decode('utf-8')
    reader = csv.DictReader(io.StringIO(decoded))
    
    batches_added = 0
    alerts_generated = 0
    
    for row in reader:
        batch_id = row.get("batch_id", f"BATCH-{batches_added+1:04d}")
        product_id = row.get("product_id", "")
        
        # Find product info
        product = next((p for p in SAMPLE_DATA["products"] if p["product_id"] == product_id), None)
        
        # Default values if product not found
        product_name = product["name"] if product else row.get("product_name", "Unknown")
        category = product["category"] if product else row.get("category", "Dairy")
        base_price = product["unit_price"] if product else float(row.get("unit_price", 100))
        base_shelf_life = product["base_shelf_life_days"] if product else 7
        
        manufacture_date = row.get("manufacture_date", datetime.now().isoformat())
        temp = float(row.get("temperature", 4.0))
        humidity = float(row.get("humidity", 65.0))
        handling_events = int(row.get("handling_events", 0))
        cold_chain_breaks = int(row.get("cold_chain_breaks", 0))
        transport_days = float(row.get("transport_days", 1.0))
        supplier = row.get("supplier", "Default")
        quantity = int(row.get("quantity", 100))
        location = row.get("location", "Warehouse")
        
        # Calculate RSL
        rsl_result = calculate_rsl(
            product_name=product_name,
            category=category,
            manufacture_date=manufacture_date,
            current_temp=temp,
            current_humidity=humidity,
            handling_events=handling_events,
            cold_chain_breaks=cold_chain_breaks,
            transport_days=transport_days,
            supplier=supplier
        )
        
        decay_score = rsl_result["decay_score"]
        shelf_life = rsl_result["rsl_days"]
        grade = rsl_result["quality_grade"]
        
        # Calculate pricing
        pricing = calculate_markdown_price(base_price, decay_score, shelf_life, quantity)
        
        batch = {
            "batch_id": batch_id,
            "product_id": product_id,
            "product_name": product_name,
            "category": category,
            "quantity": quantity,
            "unit": "L" if category == "Dairy" and product_name in ["Milk", "Cream"] else "kg",
            "manufacture_date": manufacture_date,
            "received_date": row.get("received_date", manufacture_date),
            "expiry_date": rsl_result["expiry_date"],
            "location": location,
            "supplier": supplier,
            "temperature": temp,
            "humidity": humidity,
            "handling_events": handling_events,
            "cold_chain_breaks": cold_chain_breaks,
            "transport_days": transport_days,
            "decay_score": round(decay_score, 2),
            "shelf_life_days": round(shelf_life, 1),
            "rsl_hours": rsl_result["rsl_hours"],
            "rsl_percentage": rsl_result["rsl_percentage"],
            "grade": grade,
            "status": "active" if shelf_life > 0 else "expired",
            "quality_status": rsl_result["status"],
            "price_per_unit": pricing["original_price"],
            "current_price": pricing["discounted_price"],
            "discount_percent": pricing["discount_percent"],
            "total_value": round(quantity * pricing["original_price"], 2),
            "discounted_value": round(quantity * pricing["discounted_price"], 2),
            "rsl_factors": rsl_result["factors"],
            "recommendations": rsl_result["recommendations"]
        }
        SAMPLE_DATA["batches"].append(batch)
        batches_added += 1
        
        # Generate alerts for high-risk items
        if decay_score > 60 or shelf_life <= 2 or cold_chain_breaks > 0:
            if decay_score > 75 or shelf_life <= 1:
                severity = "CRITICAL"
                alert_type = "CRITICAL_DECAY" if decay_score > 75 else "IMMINENT_EXPIRY"
            elif decay_score > 60 or cold_chain_breaks > 0:
                severity = "HIGH"
                alert_type = "HIGH_DECAY" if decay_score > 60 else "COLD_CHAIN_BREAK"
            else:
                severity = "MEDIUM"
                alert_type = "APPROACHING_EXPIRY"
            
            alert = {
                "alert_id": f"ALERT-{len(SAMPLE_DATA['alerts']) + 1:04d}",
                "batch_id": batch_id,
                "product_id": product_id,
                "product_name": product_name,
                "category": category,
                "severity": severity,
                "alert_type": alert_type,
                "title": f"{severity}: {product_name} requires attention",
                "message": f"Batch {batch_id}: RSL={shelf_life:.1f} days, Decay={decay_score:.1f}%, Grade={grade}",
                "location": location,
                "decay_score": round(decay_score, 2),
                "rsl_days": round(shelf_life, 1),
                "recommendations": rsl_result["recommendations"],
                "created_at": datetime.now().isoformat(),
                "acknowledged": False
            }
            SAMPLE_DATA["alerts"].append(alert)
            alerts_generated += 1
    
    # Record upload history
    UPLOAD_HISTORY.append({
        "id": len(UPLOAD_HISTORY) + 1,
        "filename": file.filename,
        "upload_type": "inventory",
        "records_processed": batches_added,
        "alerts_generated": alerts_generated,
        "status": "success",
        "uploaded_at": datetime.now().isoformat()
    })
    
    return {
        "message": f"Inventory uploaded successfully. {alerts_generated} alerts generated.",
        "filename": file.filename,
        "processed": batches_added,
        "records_processed": batches_added,
        "alerts_generated": alerts_generated
    }

@app.post("/api/v1/upload/sensors")
async def upload_sensors(file: UploadFile = File(...)):
    """Upload sensor readings CSV"""
    import csv
    import io
    
    content = await file.read()
    decoded = content.decode('utf-8')
    reader = csv.DictReader(io.StringIO(decoded))
    
    sensors_added = 0
    for row in reader:
        sensor = {
            "sensor_id": row.get("sensor_id", f"SENSOR-{sensors_added+1:04d}"),
            "batch_id": row.get("batch_id", ""),
            "product_id": row.get("product_id", ""),
            "temperature": float(row.get("temperature", 4.0)),
            "humidity": float(row.get("humidity", 65.0)),
            "timestamp": row.get("timestamp", datetime.now().isoformat()),
            "location": row.get("location", "Unknown"),
            "alert_triggered": row.get("alert_triggered", "false").lower() == "true"
        }
        
        if "sensors" not in SAMPLE_DATA:
            SAMPLE_DATA["sensors"] = []
        SAMPLE_DATA["sensors"].append(sensor)
        sensors_added += 1
    
    # Record upload history
    UPLOAD_HISTORY.append({
        "id": len(UPLOAD_HISTORY) + 1,
        "filename": file.filename,
        "upload_type": "sensors",
        "records_processed": sensors_added,
        "status": "success",
        "uploaded_at": datetime.now().isoformat()
    })
    
    return {
        "message": "Sensor data uploaded successfully",
        "filename": file.filename,
        "processed": sensors_added,
        "records_processed": sensors_added
    }

# ============ VOICE ENDPOINTS ============

@app.post("/api/v1/voice/daily-summary")
async def voice_daily_summary(data: Dict[str, Any]):
    """Generate voice summary"""
    return {
        "text": f"Daily summary: {data.get('critical_count', 0)} critical items, "
                f"{data.get('at_risk_count', 0)} items at risk, "
                f"estimated waste value: ₹{data.get('waste_value', 0):,.2f}",
        "audio_url": "/static/audio/summary.mp3"
    }

@app.get("/api/v1/voice/speak")
async def speak_text(text: str):
    """Convert text to speech"""
    return {
        "text": text,
        "audio_url": "/static/audio/speech.mp3"
    }

# ============ ASSISTANT ENDPOINTS ============

@app.post("/api/v1/predictions/decay")
async def predict_decay(data: Dict[str, Any]):
    """Predict decay for a batch using LLM analysis"""
    batch_id = data.get("batch_id", "")
    include_explanation = data.get("include_explanation", True)
    
    batch = next((b for b in SAMPLE_DATA["batches"] if b["batch_id"] == batch_id), None)
    
    if not batch:
        raise HTTPException(status_code=404, detail=f"Batch {batch_id} not found")
    
    # Try to use LLM for prediction analysis
    llm_analysis = None
    llm_used = False
    
    if include_explanation:
        try:
            from services.llm_service import get_llm_service
            llm_service = get_llm_service()
            
            prompt = f"""Analyze this perishable product batch and predict decay trajectory:

BATCH DATA:
- Product: {batch['product_name']}
- Category: {batch['category']}
- Current Decay Score: {batch['decay_score']:.1f}%
- Temperature: {batch['temperature']}°C
- Humidity: {batch['humidity']}%
- Days Remaining: {batch['shelf_life_days']:.1f}
- Cold Chain Breaks: {batch.get('cold_chain_breaks', 0)}
- Current Grade: {batch.get('grade', 'Unknown')}
- Location: {batch['location']}

Provide a prediction analysis (4-5 sentences) covering:
1. Current decay status assessment
2. Predicted decay rate over next 24-48 hours
3. Key risk factors
4. Recommended action with urgency level"""

            llm_analysis = llm_service.generate(prompt, max_tokens=350, temperature=0.7)
            if llm_analysis and "Error generating" not in llm_analysis:
                llm_used = True
        except Exception as e:
            print(f"LLM prediction error: {e}")
    
    # Fallback rule-based analysis
    if not llm_analysis or not llm_used:
        llm_analysis = f"**{batch['product_name']}** - Decay Analysis\n\n"
        llm_analysis += f"Current decay score is {batch['decay_score']:.1f}% with {batch['shelf_life_days']:.1f} days remaining.\n\n"
        
        if batch['decay_score'] > 70:
            llm_analysis += "⚠️ CRITICAL: Product is deteriorating rapidly. "
            llm_analysis += "Recommend immediate 50-70% markdown or disposal within 24 hours."
        elif batch['decay_score'] > 50:
            llm_analysis += "🔶 WARNING: Product quality declining. "
            llm_analysis += "Recommend 30-40% markdown and prioritizing for quick sale."
        elif batch['decay_score'] > 30:
            llm_analysis += "📊 MODERATE: Product condition acceptable but declining. "
            llm_analysis += "Monitor closely and consider 10-20% markdown."
        else:
            llm_analysis += "✅ GOOD: Product in good condition. "
            llm_analysis += "Continue regular monitoring."
    
    return {
        "batch_id": batch_id,
        "prediction": {
            "current_decay": batch['decay_score'],
            "predicted_decay_24h": min(100, batch['decay_score'] + random.uniform(5, 15)),
            "predicted_decay_48h": min(100, batch['decay_score'] + random.uniform(10, 25)),
            "shelf_life_remaining": batch['shelf_life_days'],
            "risk_level": "critical" if batch['decay_score'] > 70 else "high" if batch['decay_score'] > 50 else "medium" if batch['decay_score'] > 30 else "low"
        },
        "analysis": llm_analysis,
        "llm_used": llm_used,
        "confidence": 0.85 + random.uniform(0, 0.1),
        "timestamp": datetime.now().isoformat()
    }

@app.post("/api/v1/assistant/explain")
async def explain_prediction(data: Dict[str, Any]):
    """Explain a prediction for a specific batch using LLM"""
    batch_id = data.get("batch_id", "")
    batch = next((b for b in SAMPLE_DATA["batches"] if b["batch_id"] == batch_id), None)
    
    if not batch:
        return {
            "explanation": f"Unable to find batch {batch_id}. Please verify the batch ID and try again.",
            "batch_id": batch_id,
            "confidence": 0.0,
            "llm_used": False
        }
    
    # Try to use LLM for explanation
    explanation = None
    llm_used = False
    
    try:
        from services.llm_service import get_llm_service
        llm_service = get_llm_service()
        
        prompt = f"""You are a food safety expert. Explain the decay prediction for this perishable product in simple terms for a store manager.

PRODUCT DATA:
- Product: {batch['product_name']}
- Category: {batch['category']}
- Batch ID: {batch['batch_id']}
- Decay Score: {batch['decay_score']:.1f}%
- Quality Grade: {batch.get('grade', 'Unknown')}
- Remaining Shelf Life: {batch['shelf_life_days']:.1f} days
- Storage Temperature: {batch['temperature']}°C
- Humidity: {batch['humidity']}%
- Location: {batch['location']}
- Cold Chain Breaks: {batch.get('cold_chain_breaks', 0)}
- Handling Events: {batch.get('handling_events', 0)}

Provide a clear, actionable explanation (5-6 sentences) covering:
1. Current product condition
2. Main factors affecting decay
3. Predicted outcome if no action taken
4. Specific recommended action
5. Financial impact consideration"""

        explanation = llm_service.generate(prompt, max_tokens=400, temperature=0.7)
        if explanation and "Error generating" not in explanation and "LLM service temporarily unavailable" not in explanation:
            llm_used = True
    except Exception as e:
        print(f"LLM explanation error: {e}")
    
    # Fallback rule-based explanation
    if not explanation or not llm_used:
        explanation = f"**{batch['product_name']}** (Batch: {batch_id})\n\n"
        explanation += f"📊 **Current Status**: {batch.get('quality_status', 'Unknown')}\n"
        explanation += f"🎯 **Decay Score**: {batch['decay_score']:.1f}%\n"
        explanation += f"⏳ **Remaining Shelf Life**: {batch['shelf_life_days']:.1f} days\n\n"
        explanation += f"**Contributing Factors**:\n"
        explanation += f"- Temperature: {batch['temperature']}°C (optimal: 2-4°C for dairy)\n"
        explanation += f"- Humidity: {batch['humidity']}%\n"
        explanation += f"- Handling Events: {batch.get('handling_events', 0)}\n"
        explanation += f"- Cold Chain Breaks: {batch.get('cold_chain_breaks', 0)}\n\n"
        
        if batch['decay_score'] > 70:
            explanation += "⚠️ **Recommendation**: Immediate markdown required. Consider 50-70% discount."
        elif batch['decay_score'] > 50:
            explanation += "🔶 **Recommendation**: Apply 30-40% markdown and prioritize for sale."
        else:
            explanation += "✅ **Recommendation**: Product in good condition. Monitor regularly."
    
    return {
        "explanation": explanation,
        "batch_id": batch_id,
        "confidence": 0.87 if batch else 0.0,
        "llm_used": llm_used,
        "factors": [
            {"name": "Temperature", "impact": 0.4, "status": "normal" if batch["temperature"] < 6 else "warning"},
            {"name": "Humidity", "impact": 0.3, "status": "normal"},
            {"name": "Time", "impact": 0.3, "status": "warning" if batch["shelf_life_days"] < 3 else "normal"}
        ]
    }

@app.post("/api/v1/assistant/query")
async def query_assistant(data: Dict[str, Any]):
    """Query the AI assistant - Full LLM mode with contextual inventory data"""
    query = data.get("query", "").strip()
    query_lower = query.lower()
    use_llm = data.get("use_llm", True)  # Enable LLM by default
    
    batches = SAMPLE_DATA.get("batches", [])
    alerts = SAMPLE_DATA.get("alerts", [])
    sensors = SAMPLE_DATA.get("sensors", [])
    
    # Define allowed topics for domain filtering
    inventory_keywords = ["inventory", "batch", "stock", "product", "item", "quantity", "location", "warehouse", "store"]
    decay_keywords = ["decay", "spoil", "rot", "fresh", "quality", "grade", "rsl", "shelf life", "expir"]
    alert_keywords = ["alert", "warning", "critical", "high", "urgent", "attention", "risk"]
    category_keywords = ["dairy", "fruit", "vegetable", "meat", "milk", "cheese", "apple", "tomato", "chicken"]
    markdown_keywords = ["markdown", "discount", "price", "pricing", "sale", "reduce", "clearance"]
    cold_chain_keywords = ["temperature", "cold", "chain", "sensor", "humidity", "storage", "refrigerat"]
    report_keywords = ["report", "summary", "overview", "status", "daily", "today"]
    analysis_keywords = ["analyze", "analysis", "why", "cause", "reason", "root", "explain"]
    
    # Check if query is relevant to our domain
    is_relevant = any(kw in query_lower for kw in (
        inventory_keywords + decay_keywords + alert_keywords + category_keywords + 
        markdown_keywords + cold_chain_keywords + report_keywords + analysis_keywords
    ))
    
    if not is_relevant:
        response = "🤖 I'm your Decay Optimization Assistant, specialized in **perishable inventory management**.\n\n"
        response += "I can help you with:\n"
        response += "• 📊 Inventory status and batch information\n"
        response += "• 🧪 Decay analysis and quality grades\n"
        response += "• ⚠️ Alert monitoring and critical items\n"
        response += "• 💰 Markdown and pricing recommendations\n"
        response += "• 🌡️ Cold chain and temperature monitoring\n"
        response += "• 📈 Reports and trend analysis\n\n"
        response += "Please ask me about your store's inventory, decay rates, or expiring products!"
        return {"query": query, "response": response, "timestamp": datetime.now().isoformat(), "llm_used": False}
    
    if not batches:
        response = "📭 **No inventory data available.**\n\nPlease upload your data using the **Data Upload** page to get started."
        return {"query": query, "response": response, "timestamp": datetime.now().isoformat(), "llm_used": False}
    
    # Prepare context for LLM
    context = {
        "total_batches": len(batches),
        "total_quantity": sum(b['quantity'] for b in batches),
        "average_decay": sum(b['decay_score'] for b in batches) / len(batches) if batches else 0,
        "critical_items": len([b for b in batches if b['decay_score'] > 70]),
        "expiring_today": len([b for b in batches if b['shelf_life_days'] <= 1]),
        "expiring_week": len([b for b in batches if b['shelf_life_days'] <= 7]),
        "active_alerts": len([a for a in alerts if not a.get('acknowledged', False)]),
        "critical_alerts": len([a for a in alerts if a['severity'] == 'CRITICAL']),
        "categories": {}
    }
    
    # Add category breakdown
    for cat in CATEGORIES:
        cat_batches = [b for b in batches if b["category"] == cat]
        if cat_batches:
            context["categories"][cat] = {
                "count": len(cat_batches),
                "avg_decay": sum(b['decay_score'] for b in cat_batches) / len(cat_batches),
                "critical": len([b for b in cat_batches if b['decay_score'] > 70]),
                "expiring_soon": len([b for b in cat_batches if b['shelf_life_days'] <= 2])
            }
    
    # Add top items needing attention
    urgent_batches = sorted(batches, key=lambda x: (-x['decay_score'], x['shelf_life_days']))[:5]
    context["urgent_items"] = [
        {"name": b['product_name'], "decay": b['decay_score'], "days_left": b['shelf_life_days'], "batch": b['batch_id']}
        for b in urgent_batches
    ]
    
    # Try to use LLM if enabled
    llm_response = None
    llm_used = False
    
    if use_llm:
        try:
            from services.llm_service import get_llm_service
            llm_service = get_llm_service()
            
            # Create prompt with context
            prompt = f"""You are an AI assistant for a perishable goods inventory management system called "Decay Optimization Platform". 
Your role is to help store managers understand their inventory status, decay patterns, and provide actionable recommendations.

CURRENT INVENTORY DATA:
- Total Batches: {context['total_batches']}
- Total Quantity: {context['total_quantity']:,} units
- Average Decay Score: {context['average_decay']:.1f}%
- Critical Items (>70% decay): {context['critical_items']}
- Expiring Today: {context['expiring_today']}
- Expiring This Week: {context['expiring_week']}
- Active Alerts: {context['active_alerts']}
- Critical Alerts: {context['critical_alerts']}

CATEGORY BREAKDOWN:
{json.dumps(context['categories'], indent=2)}

MOST URGENT ITEMS:
{json.dumps(context['urgent_items'], indent=2)}

USER QUESTION: {query}

Provide a helpful, accurate, and actionable response. Use the data provided. Include specific numbers and recommendations where appropriate. Keep response concise but informative. Use emojis sparingly for visual appeal. Format with markdown for readability."""

            llm_response = llm_service.generate(prompt, max_tokens=500, temperature=0.7)
            if llm_response and "Error generating" not in llm_response and "LLM service temporarily unavailable" not in llm_response:
                llm_used = True
        except Exception as e:
            print(f"LLM Error: {e}")
            llm_response = None
    
    # If LLM succeeded, use its response
    if llm_used and llm_response:
        return {
            "query": query,
            "response": llm_response,
            "timestamp": datetime.now().isoformat(),
            "llm_used": True,
            "context_summary": context
        }
    
    # Fallback to rule-based response
    response = ""
    
    # Alert queries
    if any(kw in query_lower for kw in alert_keywords):
        active_alerts = [a for a in alerts if not a.get('acknowledged', False)]
        critical = [a for a in alerts if a['severity'] == 'CRITICAL']
        high = [a for a in alerts if a['severity'] == 'HIGH']
        
        response = "🚨 **Alert Status**\n\n"
        response += f"**Active Alerts**: {len(active_alerts)}\n"
        response += f"• Critical: {len(critical)}\n"
        response += f"• High: {len(high)}\n\n"
        
        if critical:
            response += "**Critical Items Requiring Immediate Action:**\n"
            for a in critical[:3]:
                response += f"• **{a['product_name']}** ({a['batch_id']}) - {a['message'][:50]}...\n"
        
        if len(critical) > 3:
            response += f"... and {len(critical) - 3} more critical alerts"
    
    # Category-specific queries
    elif any(kw in query_lower for kw in category_keywords):
        target_cat = None
        for cat in CATEGORIES:
            if cat.lower() in query_lower:
                target_cat = cat
                break
        
        if target_cat:
            cat_batches = [b for b in batches if b["category"] == target_cat]
            if cat_batches:
                avg_decay = sum(b['decay_score'] for b in cat_batches) / len(cat_batches)
                critical = [b for b in cat_batches if b['decay_score'] > 70]
                expiring = [b for b in cat_batches if b['shelf_life_days'] <= 2]
                
                response = f"📦 **{target_cat} Inventory Analysis**\n\n"
                response += f"**Total Batches**: {len(cat_batches)}\n"
                response += f"**Average Decay**: {avg_decay:.1f}%\n"
                response += f"**Critical Items**: {len(critical)}\n"
                response += f"**Expiring Soon**: {len(expiring)}\n\n"
                
                if critical:
                    response += "**Items needing attention:**\n"
                    for b in critical[:3]:
                        response += f"• {b['product_name']} - Decay: {b['decay_score']:.1f}%, RSL: {b['shelf_life_days']:.1f} days\n"
            else:
                response = f"No {target_cat} products found in current inventory."
        else:
            response = "📦 **Inventory by Category**:\n\n"
            for cat in CATEGORIES:
                cat_batches = [b for b in batches if b["category"] == cat]
                if cat_batches:
                    avg_decay = sum(b['decay_score'] for b in cat_batches) / len(cat_batches)
                    response += f"**{cat}**: {len(cat_batches)} batches, avg decay: {avg_decay:.1f}%\n"
    
    # Expiry/shelf life queries
    elif any(kw in query_lower for kw in ["expir", "shelf", "soon", "today", "tomorrow"]):
        today = [b for b in batches if b['shelf_life_days'] <= 1]
        tomorrow = [b for b in batches if 1 < b['shelf_life_days'] <= 2]
        this_week = [b for b in batches if 2 < b['shelf_life_days'] <= 7]
        
        response = "⏰ **Expiry Timeline**\n\n"
        response += f"**Expiring Today**: {len(today)} items\n"
        response += f"**Expiring Tomorrow**: {len(tomorrow)} items\n"
        response += f"**This Week**: {len(this_week)} items\n\n"
        
        if today:
            response += "**Urgent - Expires Today:**\n"
            for b in today[:5]:
                response += f"• {b['product_name']} ({b['quantity']} {b['unit']}) at {b['location']}\n"
    
    # Markdown/pricing queries
    elif any(kw in query_lower for kw in markdown_keywords):
        markdown_items = [b for b in batches if b.get("discount_percent", 0) > 0]
        urgent = [b for b in markdown_items if b['decay_score'] > 60 or b['shelf_life_days'] <= 2]
        
        response = "💰 **Markdown Recommendations**\n\n"
        response += f"**Items needing markdown**: {len(markdown_items)}\n"
        response += f"**Urgent (>60% decay or <2 days)**: {len(urgent)}\n\n"
        
        total_value = sum(b['total_value'] for b in markdown_items)
        
        response += f"**Total Value at Risk**: ₹{total_value:,.0f}\n"
        response += f"**Potential Recovery**: ₹{sum(b['discounted_value'] for b in markdown_items):,.0f}\n\n"
        
        if urgent:
            response += "**Top Urgent Markdowns:**\n"
            for b in urgent[:5]:
                response += f"• {b['product_name']}: {b['discount_percent']}% off (₹{b['price_per_unit']:.0f} → ₹{b['current_price']:.0f})\n"
    
    # Cold chain/temperature queries
    elif any(kw in query_lower for kw in cold_chain_keywords):
        temp_issues = [s for s in sensors if s.get('alert_triggered', False)]
        
        response = "🌡️ **Cold Chain Status**\n\n"
        response += f"**Total Sensors**: {len(sensors)}\n"
        response += f"**Temperature Alerts**: {len(temp_issues)}\n\n"
        
        if temp_issues:
            response += "**Locations with Issues:**\n"
            locations = list(set(s['location'] for s in temp_issues))
            for loc in locations[:5]:
                loc_sensors = [s for s in temp_issues if s['location'] == loc]
                avg_temp = sum(s['temperature'] for s in loc_sensors) / len(loc_sensors)
                response += f"• {loc}: Avg {avg_temp:.1f}°C ({len(loc_sensors)} readings)\n"
        else:
            response += "✅ All temperatures within acceptable range."
    
    # Report/summary queries
    elif any(kw in query_lower for kw in report_keywords):
        avg_decay = sum(b['decay_score'] for b in batches) / len(batches)
        critical = len([b for b in batches if b['grade'] in ['D', 'F']])
        active_alerts = len([a for a in alerts if not a.get('acknowledged', False)])
        
        response = "📊 **Daily Inventory Report**\n\n"
        response += f"**Total Batches**: {len(batches)}\n"
        response += f"**Total Quantity**: {sum(b['quantity'] for b in batches):,} units\n"
        response += f"**Average Decay**: {avg_decay:.1f}%\n"
        response += f"**Critical/Poor Grade**: {critical} items\n"
        response += f"**Active Alerts**: {active_alerts}\n\n"
        
        response += "**By Grade:**\n"
        for grade in ['A', 'B', 'C', 'D', 'F']:
            count = len([b for b in batches if b['grade'] == grade])
            if count > 0:
                response += f"• Grade {grade}: {count} batches\n"
    
    # Analysis/why queries
    elif any(kw in query_lower for kw in analysis_keywords):
        high_decay = [b for b in batches if b['decay_score'] > 60]
        
        response = "🔍 **Decay Analysis**\n\n"
        
        if high_decay:
            cold_chain_issues = [b for b in high_decay if b.get('cold_chain_breaks', 0) > 0]
            temp_issues = [b for b in high_decay if b.get('temperature', 0) > 8]
            age_issues = [b for b in high_decay if b.get('rsl_percentage', 100) < 30]
            
            response += f"**High Decay Items**: {len(high_decay)}\n\n"
            response += "**Root Causes Identified:**\n"
            
            if cold_chain_issues:
                response += f"• Cold chain breaks: {len(cold_chain_issues)} batches affected\n"
            if temp_issues:
                response += f"• Temperature excursions: {len(temp_issues)} batches affected\n"
            if age_issues:
                response += f"• Near end of shelf life: {len(age_issues)} batches\n\n"
            
            response += "**Recommendations:**\n"
            response += "• Review cold chain procedures for affected items\n"
            response += "• Apply immediate markdown to high-decay items\n"
            response += "• Consider donation for items near expiry"
        else:
            response += "✅ No significant decay issues detected.\n"
            response += f"Average decay across inventory: {sum(b['decay_score'] for b in batches) / len(batches):.1f}%"
    
    # Default inventory query
    else:
        avg_decay = sum(b['decay_score'] for b in batches) / len(batches)
        response = "📦 **Current Inventory Status**\n\n"
        response += f"**Total Batches**: {len(batches)}\n"
        response += f"**Average Decay**: {avg_decay:.1f}%\n"
        response += f"**Active Alerts**: {len([a for a in alerts if not a.get('acknowledged', False)])}\n\n"
        
        response += "**Quick Stats by Category:**\n"
        for cat in CATEGORIES:
            cat_batches = [b for b in batches if b["category"] == cat]
            if cat_batches:
                response += f"• {cat}: {len(cat_batches)} items\n"
    
    return {
        "query": query,
        "response": response,
        "timestamp": datetime.now().isoformat(),
        "llm_used": False,
        "context_summary": context
    }

# ============ MARKDOWN/PRICE ENDPOINTS ============

@app.get("/api/v1/analytics/markdown-recommendations")
async def get_markdown_recommendations(limit: int = 20):
    """Get markdown recommendations with proper pricing logic"""
    recommendations = []
    
    # Get batches that need markdown (decay > 30 or shelf life <= 5 days)
    markdown_batches = [
        b for b in SAMPLE_DATA["batches"] 
        if b["decay_score"] > 30 or b["shelf_life_days"] <= 5
    ]
    
    # Sort by urgency (high decay + low shelf life first)
    markdown_batches.sort(
        key=lambda x: (x["decay_score"] * 2 + (10 - x["shelf_life_days"]) * 10), 
        reverse=True
    )
    
    for batch in markdown_batches[:limit]:
        # Recalculate pricing for current state
        base_price = PRODUCT_PRICES.get(batch["product_name"], 100)
        pricing = calculate_markdown_price(
            base_price, 
            batch["decay_score"], 
            batch["shelf_life_days"], 
            batch["quantity"]
        )
        
        # Determine urgency and reason
        urgency = "critical" if (batch["decay_score"] > 70 or batch["shelf_life_days"] <= 1) else \
                  "high" if (batch["decay_score"] > 50 or batch["shelf_life_days"] <= 2) else \
                  "medium"
        
        reasons = []
        if batch["decay_score"] > 70:
            reasons.append(f"Critical decay ({batch['decay_score']:.1f}%)")
        elif batch["decay_score"] > 50:
            reasons.append(f"High decay ({batch['decay_score']:.1f}%)")
        
        if batch["shelf_life_days"] <= 1:
            reasons.append(f"Expires in {batch['shelf_life_days']} day")
        elif batch["shelf_life_days"] <= 3:
            reasons.append(f"Expires in {batch['shelf_life_days']} days")
        
        if batch["quantity"] > 300:
            reasons.append(f"High inventory ({batch['quantity']} {batch['unit']})")
        
        recommendations.append({
            "batch_id": batch["batch_id"],
            "product_name": batch["product_name"],
            "category": batch["category"],
            "quantity": batch["quantity"],
            "unit": batch["unit"],
            "original_price": pricing["original_price"],
            "current_price": pricing["original_price"],
            "recommended_price": pricing["discounted_price"],
            "recommended_markdown_pct": pricing["discount_percent"],
            "recommended_discount": pricing["discount_percent"],
            "savings_per_unit": pricing["savings"],
            "expected_revenue": round(pricing["discounted_price"] * batch["quantity"], 2),
            "total_value": batch["total_value"],
            "discounted_value": batch["discounted_value"],
            "potential_loss_if_not_sold": round(batch["discounted_value"] * 0.8, 2),
            "reason": " | ".join(reasons),
            "urgency_level": urgency,
            "urgency": urgency,
            "decay_score": batch["decay_score"],
            "shelf_life_days": batch["shelf_life_days"],
            "location": batch["location"]
        })
    
    # Calculate summary
    total_expected_revenue = sum(r["expected_revenue"] for r in recommendations)
    total_waste_prevented = sum(r["potential_loss_if_not_sold"] for r in recommendations)
    immediate_action = len([r for r in recommendations if r["urgency_level"] in ["critical", "high"]])
    
    return {
        "recommendations": recommendations,
        "summary": {
            "total_products": len(recommendations),
            "total_expected_revenue": round(total_expected_revenue, 2),
            "total_waste_prevented": round(total_waste_prevented, 2),
            "immediate_action_required": immediate_action
        }
    }

# ============ COLD CHAIN ENDPOINTS ============

@app.get("/api/v1/analytics/temperature-monitoring")
async def get_temperature_monitoring(hours: int = 24, location: Optional[str] = None):
    """Get temperature monitoring data from sensors with timeline aggregation"""
    sensors = SAMPLE_DATA.get("sensors", [])
    batches = SAMPLE_DATA.get("batches", [])
    
    data_points = []
    
    # Return empty data if no sensors (e.g., after flush)
    if not sensors:
        return {
            "data": [],
            "timeline": [],
            "total_readings": 0,
            "total_anomalies": 0,
            "anomaly_rate": 0,
            "period": f"{hours} hours",
            "location": location,
            "message": "No sensor data available. Please upload sensor data."
        }
    
    # Filter by location if specified
    filtered_sensors = sensors
    if location:
        filtered_sensors = [s for s in sensors if s.get("location") == location]
    
    data_points = [{
        "timestamp": s.get("timestamp", datetime.now().isoformat()),
        "temperature": s.get("temperature", 4.0),
        "humidity": s.get("humidity", 65.0),
        "location": s.get("location", "Unknown"),
        "batch_id": s.get("batch_id"),
        "alert_triggered": s.get("alert_triggered", False)
    } for s in filtered_sensors]
    
    # Sort by timestamp
    data_points.sort(key=lambda x: x["timestamp"])
    
    # Calculate statistics
    total_readings = len(data_points)
    anomalies = [d for d in data_points if d.get("alert_triggered", False) or d.get("temperature", 0) > 8]
    total_anomalies = len(anomalies)
    anomaly_rate = (total_anomalies / total_readings * 100) if total_readings > 0 else 0
    
    # Create timeline with aggregated data (group by hour)
    timeline = []
    if data_points:
        # Group by timestamp (hourly)
        hourly_data = {}
        for dp in data_points:
            ts = dp["timestamp"][:13]  # Get YYYY-MM-DDTHH
            if ts not in hourly_data:
                hourly_data[ts] = {"temps": [], "humids": []}
            hourly_data[ts]["temps"].append(dp["temperature"])
            hourly_data[ts]["humids"].append(dp["humidity"])
        
        for ts, values in sorted(hourly_data.items()):
            temps = values["temps"]
            humids = values["humids"]
            timeline.append({
                "timestamp": ts + ":00:00",
                "avg_temperature": round(sum(temps) / len(temps), 1),
                "max_temperature": round(max(temps), 1),
                "min_temperature": round(min(temps), 1),
                "avg_humidity": round(sum(humids) / len(humids), 1),
                "readings_count": len(temps)
            })
    
    # If no timeline data, generate sample timeline
    if not timeline:
        for i in range(min(hours, 24)):
            timestamp = (datetime.now() - timedelta(hours=hours - i - 1)).strftime("%Y-%m-%dT%H:00:00")
            avg_temp = round(random.uniform(3, 7), 1)
            timeline.append({
                "timestamp": timestamp,
                "avg_temperature": avg_temp,
                "max_temperature": round(avg_temp + random.uniform(1, 3), 1),
                "min_temperature": round(avg_temp - random.uniform(1, 2), 1),
                "avg_humidity": round(random.uniform(55, 75), 1),
                "readings_count": random.randint(5, 20)
            })
    
    return {
        "data": data_points,
        "timeline": timeline,
        "total_readings": total_readings,
        "total_anomalies": total_anomalies,
        "anomaly_rate": round(anomaly_rate, 2),
        "period": f"{hours} hours",
        "location": location
    }

# ============ MAIN ============

if __name__ == "__main__":
    print("""
    ╔═══════════════════════════════════════════════════════════╗
    ║         DECAY OPTIMIZATION PLATFORM                       ║
    ║   AI-driven decay analysis and shelf-life prediction      ║
    ╠═══════════════════════════════════════════════════════════╣
    ║   Categories: Dairy, Fruits, Vegetables, Meat             ║
    ║   API Docs: http://localhost:8000/api/docs                ║
    ║   Sample Data: Generated automatically                    ║
    ╚═══════════════════════════════════════════════════════════╝
    """)
    
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )

