# Test Data Sets for Decay Optimization Platform

Two complete sets of **correlated** CSV files for testing the application with RSL calculations and image analysis.

## 📁 Directory Structure

```
test_data/
├── set1/                    # North & West India focus
│   ├── products.csv         # 20 products with optimal conditions
│   ├── inventory.csv        # 21 inventory batches (correlated to products)
│   └── sensors.csv          # 31 sensor readings (correlated to batches)
│
├── set2/                    # South & East India focus
│   ├── products.csv         # 20 different products
│   ├── inventory.csv        # 21 inventory batches (correlated to products)
│   └── sensors.csv          # 32 sensor readings (correlated to batches)
│
└── README.md               # This file
```

## 🔗 Data Correlation Structure

```
products.csv (product_id) ──┐
                            ├──> inventory.csv (product_id, batch_id) ──┐
                            │                                           │
                            └──> sensors.csv (product_id) ─────────────┼──> sensors.csv (batch_id)
```

### Correlation Rules:
1. **products.csv** defines base products with `product_id` as primary key
2. **inventory.csv** references `product_id` from products.csv
3. **sensors.csv** references both `batch_id` from inventory.csv AND `product_id` from products.csv
4. All location names are consistent across all three files

## 📊 CSV Formats

### products.csv
```csv
product_id,name,category,unit_price,unit_cost,packaging_type,base_shelf_life_days,optimal_temp_min,optimal_temp_max,optimal_humidity_min,optimal_humidity_max,supplier
```

| Field | Description |
|-------|-------------|
| product_id | Unique identifier (format: PRD-CAT-NNN) |
| name | Product display name |
| category | Dairy/Fruits/Vegetables/Meat |
| unit_price | Selling price in ₹ |
| unit_cost | Cost price in ₹ |
| packaging_type | Package description |
| base_shelf_life_days | Expected shelf life under optimal conditions |
| optimal_temp_min/max | Ideal storage temperature range (°C) |
| optimal_humidity_min/max | Ideal humidity range (%) |
| supplier | Supplier identifier |

### inventory.csv
```csv
batch_id,product_id,quantity,manufacture_date,received_date,location,supplier,handling_events,cold_chain_breaks,transport_days,temperature,humidity
```

| Field | Description |
|-------|-------------|
| batch_id | Unique batch identifier (format: BATCH-NNNN) |
| product_id | Links to products.csv |
| quantity | Number of units |
| manufacture_date | Production date (ISO 8601) |
| received_date | Date received at location |
| location | Storage location |
| supplier | Supplier (should match product supplier) |
| handling_events | Number of handling incidents |
| cold_chain_breaks | Number of cold chain interruptions |
| transport_days | Days in transit |
| temperature | Current storage temperature (°C) |
| humidity | Current humidity (%) |

### sensors.csv
```csv
sensor_id,batch_id,product_id,temperature,humidity,timestamp,location,alert_triggered
```

| Field | Description |
|-------|-------------|
| sensor_id | Unique sensor identifier |
| batch_id | Links to inventory.csv |
| product_id | Links to products.csv |
| temperature | Measured temperature (°C) |
| humidity | Measured humidity (%) |
| timestamp | Reading timestamp (ISO 8601) |
| location | Sensor location (matches inventory location) |
| alert_triggered | Whether reading triggered alert |

## 📈 RSL Calculation Factors

The RSL (Remaining Shelf Life) is calculated using:

1. **Base Shelf Life** - From product definition
2. **Age Factor** - Days since manufacture vs base shelf life
3. **Temperature Impact** - Deviation from optimal range
4. **Humidity Impact** - Deviation from optimal range
5. **Logistics Impact** - Handling events, cold chain breaks, transport time
6. **Supplier History** - Historical reliability scores
7. **Image Analysis** - Visual spoilage detection (when uploaded)

### RSL Formula
```
RSL = Base_RSL × (Temp_Factor × 0.25 + Humidity_Factor × 0.15 + 
      Logistics_Factor × 0.15 + Age_Factor × 0.25 + 
      Supplier_Factor × 0.10 + Image_Factor × 0.10)
```

## ⚠️ Test Scenarios Included

### Set 1 - High Risk Items
| Batch | Product | Issue | Expected Alert |
|-------|---------|-------|----------------|
| BATCH-1004 | Mother Dairy Curd | Temp 7.5-8.2°C, 1 cold chain break | ✅ HIGH |
| BATCH-1008 | Cavendish Banana | Temp 9.0-9.5°C, 1 cold chain break | ✅ CRITICAL |
| BATCH-1010 | Mahabaleshwar Strawberry | Temp 11-12°C, 2 cold chain breaks | ✅ CRITICAL |
| BATCH-1015 | Broccoli Crown | Temp 8.5°C, 1 cold chain break | ✅ HIGH |
| BATCH-1019 | Pork Loin | Temp 4-4.5°C, 1 cold chain break | ✅ HIGH |

### Set 2 - High Risk Items
| Batch | Product | Issue | Expected Alert |
|-------|---------|-------|----------------|
| BATCH-2006 | Milky Mist Lassi | Temp 8.5-9°C, 1 cold chain break | ✅ HIGH |
| BATCH-2010 | Blueberry | Temp 11.5-12°C, 1 cold chain break | ✅ CRITICAL |
| BATCH-2013 | Button Mushroom | Temp 9.2-9.8°C, 1 cold chain break | ✅ HIGH |
| BATCH-2019 | Chicken Drumsticks | Temp 3.5-4°C, 1 cold chain break | ✅ HIGH |
| BATCH-2021 | Duck Breast | Temp 4.2-4.5°C, 1 cold chain break | ✅ HIGH |

## 🖼️ Image Upload Testing

To test image-based RSL adjustment:

1. Upload product images via API:
```bash
# Shelf image
curl -X POST -F "batch_id=BATCH-1001" -F "file=@product_shelf.jpg" \
  http://localhost:8000/api/v1/images/upload/shelf

# Backroom image
curl -X POST -F "batch_id=BATCH-1001" -F "file=@product_backroom.jpg" \
  http://localhost:8000/api/v1/images/upload/backroom
```

2. Check updated RSL:
```bash
curl http://localhost:8000/api/v1/rsl/batch/BATCH-1001
```

## 🚀 How to Use

### Option 1: Load Sample Data (Recommended for Testing)

```bash
# Flush existing data
curl -X POST http://localhost:8000/api/v1/upload/flush-data

# Load auto-generated sample data
curl -X POST http://localhost:8000/api/v1/upload/sample-data
```

### Option 2: Upload CSV Files

```bash
# Upload Set 1
curl -X POST -F "file=@test_data/set1/products.csv" http://localhost:8000/api/v1/upload/products
curl -X POST -F "file=@test_data/set1/inventory.csv" http://localhost:8000/api/v1/upload/inventory
curl -X POST -F "file=@test_data/set1/sensors.csv" http://localhost:8000/api/v1/upload/sensors
```

### Option 3: Use UI

1. Navigate to http://localhost:3000
2. Go to **Data Upload** page
3. Click **Flush Data** to clear existing data
4. Upload files in order: Products → Inventory → Sensors

## 📊 API Endpoints for RSL

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/v1/rsl/all` | GET | Get RSL for all batches |
| `/api/v1/rsl/batch/{batch_id}` | GET | Get RSL for specific batch |
| `/api/v1/rsl/calculate` | POST | Calculate RSL with custom parameters |
| `/api/v1/images/upload/shelf` | POST | Upload shelf image for analysis |
| `/api/v1/images/upload/backroom` | POST | Upload backroom image for analysis |
| `/api/v1/images/analysis/{batch_id}` | GET | Get image analysis results |

## 💡 Notes

- All prices are in **INR (₹)**
- Temperatures are in **Celsius (°C)**
- Humidity is in **percentage (%)**
- Timestamps are in **ISO 8601 format**
- Product IDs follow pattern: `PRD-{CATEGORY}-{NUMBER}`
- Batch IDs follow pattern: `BATCH-{NUMBER}`
- Sensor IDs follow pattern: `SENSOR-{LOCATION}-{NUMBER}`

## 🔬 Optimal Storage Conditions Reference

| Category | Temperature (°C) | Humidity (%) |
|----------|------------------|--------------|
| Dairy | 2 - 4 | 60 - 70 |
| Fruits | 4 - 8 | 85 - 95 |
| Vegetables | 1 - 7 | 90 - 98 |
| Meat | -2 - 2 | 75 - 85 |
