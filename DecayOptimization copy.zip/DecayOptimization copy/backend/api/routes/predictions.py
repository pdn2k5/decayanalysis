"""
Prediction API routes for decay analysis and shelf-life estimation.
"""

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
from pydantic import BaseModel, Field

from database import get_db, Prediction, InventoryBatch, Product, SensorReading
from services.decay_predictor import get_decay_predictor
from services.shelf_life_estimator import get_shelf_life_estimator
from services.llm_service import get_llm_service
from services.alert_engine import get_alert_engine

router = APIRouter(prefix="/predictions", tags=["Predictions"])


# ============ PYDANTIC MODELS ============

class PredictionRequest(BaseModel):
    batch_id: str
    include_explanation: bool = True


class BatchPredictionRequest(BaseModel):
    batch_ids: List[str]
    include_explanations: bool = False


class ManualPredictionRequest(BaseModel):
    category: str = Field(..., description="Product category: Dairy, Fruits, Vegetables, Meat")
    days_since_manufacture: float = Field(..., ge=0)
    avg_temperature: float
    avg_humidity: float = 85.0
    handling_events: int = 0
    cold_chain_breaks: int = 0
    initial_quality: float = 100.0
    product_name: Optional[str] = None


class PredictionResponse(BaseModel):
    batch_id: Optional[str]
    product_id: Optional[str]
    product_name: Optional[str]
    category: Optional[str]
    decay_score: float
    quality_grade: str
    days_remaining: float
    confidence_lower: float
    confidence_upper: float
    recommended_action: str
    action_urgency: str
    explanation: Optional[str]
    timestamp: datetime

    class Config:
        from_attributes = True


# ============ ENDPOINTS ============

@router.post("/decay", response_model=PredictionResponse)
async def predict_decay(
    request: PredictionRequest,
    db: Session = Depends(get_db)
):
    """
    Generate decay prediction for a specific batch.
    Uses sensor data and product metadata to predict decay score and shelf life.
    """
    
    # Get batch info
    batch = db.query(InventoryBatch).filter(
        InventoryBatch.batch_id == request.batch_id
    ).first()
    
    if not batch:
        raise HTTPException(status_code=404, detail="Batch not found")
    
    # Get product info
    product = db.query(Product).filter(
        Product.product_id == batch.product_id
    ).first()
    
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    # Get recent sensor readings
    recent_readings = db.query(SensorReading).filter(
        SensorReading.batch_id == request.batch_id
    ).order_by(SensorReading.timestamp.desc()).limit(100).all()
    
    # Calculate averages from sensor data
    if recent_readings:
        avg_temp = sum(r.temperature for r in recent_readings) / len(recent_readings)
        avg_humidity = sum(r.humidity for r in recent_readings if r.humidity) / max(1, len([r for r in recent_readings if r.humidity]))
    else:
        # Use optimal values if no sensor data
        avg_temp = (product.optimal_temp_min + product.optimal_temp_max) / 2
        avg_humidity = (product.optimal_humidity_min + product.optimal_humidity_max) / 2
    
    # Calculate days since manufacture
    days_elapsed = (datetime.now() - batch.manufacture_date).total_seconds() / 86400
    
    # Get prediction
    predictor = get_decay_predictor()
    prediction = predictor.predict(
        category=product.category,
        days_since_manufacture=days_elapsed,
        avg_temperature=avg_temp,
        avg_humidity=avg_humidity,
        handling_events=batch.handling_events,
        cold_chain_breaks=batch.cold_chain_breaks,
        initial_quality=batch.initial_quality_score
    )
    
    # Generate LLM explanation if requested
    explanation = None
    if request.include_explanation:
        try:
            llm = get_llm_service()
            explanation = llm.generate_decay_explanation({
                'product_name': product.name,
                'category': product.category,
                'decay_score': prediction['decay_score'],
                'quality_grade': prediction['quality_grade'],
                'days_remaining': prediction['days_remaining'],
                'avg_temperature': avg_temp,
                'recommended_action': prediction['recommended_action']
            })
        except Exception as e:
            explanation = f"Analysis: Decay score {prediction['decay_score']:.1f}% with {prediction['days_remaining']:.1f} days remaining."
    
    # Process through alert engine
    alert_engine = get_alert_engine()
    alerts = alert_engine.process({
        'batch_id': batch.batch_id,
        'product_id': product.product_id,
        'product_name': product.name,
        'category': product.category,
        'location': batch.location,
        'decay_score': prediction['decay_score'],
        'days_remaining': prediction['days_remaining'],
        'recommended_action': prediction['recommended_action'],
        'quantity': batch.quantity,
        'unit_price': product.unit_price
    })
    
    # Save prediction to database
    db_prediction = Prediction(
        batch_id=batch.batch_id,
        decay_score=prediction['decay_score'],
        quality_grade=prediction['quality_grade'],
        days_remaining=prediction['days_remaining'],
        confidence_lower=prediction['confidence_lower'],
        confidence_upper=prediction['confidence_upper'],
        model_version="1.0",
        prediction_type="decay",
        recommended_action=prediction['recommended_action'],
        action_urgency=prediction['action_urgency'],
        explanation=explanation,
        input_features=prediction.get('input_features')
    )
    db.add(db_prediction)
    
    # Update batch quality grade
    batch.current_quality_grade = prediction['quality_grade']
    
    db.commit()
    
    return PredictionResponse(
        batch_id=batch.batch_id,
        product_id=product.product_id,
        product_name=product.name,
        category=product.category,
        decay_score=prediction['decay_score'],
        quality_grade=prediction['quality_grade'],
        days_remaining=prediction['days_remaining'],
        confidence_lower=prediction['confidence_lower'],
        confidence_upper=prediction['confidence_upper'],
        recommended_action=prediction['recommended_action'],
        action_urgency=prediction['action_urgency'],
        explanation=explanation,
        timestamp=datetime.now()
    )


@router.post("/decay/manual", response_model=PredictionResponse)
async def predict_decay_manual(request: ManualPredictionRequest):
    """
    Generate decay prediction from manual input (no database lookup).
    Useful for what-if scenarios and testing.
    """
    
    predictor = get_decay_predictor()
    prediction = predictor.predict(
        category=request.category,
        days_since_manufacture=request.days_since_manufacture,
        avg_temperature=request.avg_temperature,
        avg_humidity=request.avg_humidity,
        handling_events=request.handling_events,
        cold_chain_breaks=request.cold_chain_breaks,
        initial_quality=request.initial_quality
    )
    
    return PredictionResponse(
        batch_id=None,
        product_id=None,
        product_name=request.product_name,
        category=request.category,
        decay_score=prediction['decay_score'],
        quality_grade=prediction['quality_grade'],
        days_remaining=prediction['days_remaining'],
        confidence_lower=prediction['confidence_lower'],
        confidence_upper=prediction['confidence_upper'],
        recommended_action=prediction['recommended_action'],
        action_urgency=prediction['action_urgency'],
        explanation=None,
        timestamp=datetime.now()
    )


@router.post("/batch")
async def predict_batch(
    request: BatchPredictionRequest,
    db: Session = Depends(get_db)
):
    """
    Generate predictions for multiple batches at once.
    """
    
    results = []
    
    for batch_id in request.batch_ids:
        try:
            pred_request = PredictionRequest(
                batch_id=batch_id,
                include_explanation=request.include_explanations
            )
            result = await predict_decay(pred_request, db)
            results.append(result.dict())
        except HTTPException as e:
            results.append({
                "batch_id": batch_id,
                "error": e.detail
            })
    
    return {
        "total_processed": len(results),
        "successful": len([r for r in results if 'error' not in r]),
        "predictions": results
    }


@router.get("/shelf-life/{batch_id}")
async def estimate_shelf_life(
    batch_id: str,
    db: Session = Depends(get_db)
):
    """
    Get detailed shelf-life estimation with survival analysis.
    """
    
    # Get batch and product
    batch = db.query(InventoryBatch).filter(
        InventoryBatch.batch_id == batch_id
    ).first()
    
    if not batch:
        raise HTTPException(status_code=404, detail="Batch not found")
    
    product = db.query(Product).filter(
        Product.product_id == batch.product_id
    ).first()
    
    # Get latest prediction
    latest_prediction = db.query(Prediction).filter(
        Prediction.batch_id == batch_id
    ).order_by(Prediction.timestamp.desc()).first()
    
    decay_score = latest_prediction.decay_score if latest_prediction else 30.0
    
    # Calculate days elapsed
    days_elapsed = (datetime.now() - batch.manufacture_date).total_seconds() / 86400
    
    # Get sensor data for temperature deviation
    recent_readings = db.query(SensorReading).filter(
        SensorReading.batch_id == batch_id
    ).order_by(SensorReading.timestamp.desc()).limit(50).all()
    
    if recent_readings:
        avg_temp = sum(r.temperature for r in recent_readings) / len(recent_readings)
        optimal_temp = (product.optimal_temp_min + product.optimal_temp_max) / 2
        temp_deviation = abs(avg_temp - optimal_temp)
    else:
        temp_deviation = 0
    
    # Get shelf life estimate
    estimator = get_shelf_life_estimator()
    estimate = estimator.estimate(
        category=product.category,
        days_elapsed=days_elapsed,
        current_decay_score=decay_score,
        temperature_deviation=temp_deviation,
        handling_stress=batch.handling_events,
        cold_chain_breaks=batch.cold_chain_breaks
    )
    
    # Add product context
    estimate['batch_id'] = batch_id
    estimate['product_id'] = product.product_id
    estimate['product_name'] = product.name
    estimate['category'] = product.category
    estimate['manufacture_date'] = batch.manufacture_date.isoformat()
    estimate['expiry_date'] = batch.expiry_date.isoformat() if batch.expiry_date else None
    estimate['days_elapsed'] = round(days_elapsed, 1)
    
    return estimate


@router.get("/history/{batch_id}")
async def get_prediction_history(
    batch_id: str,
    limit: int = Query(default=20, le=100),
    db: Session = Depends(get_db)
):
    """
    Get prediction history for a batch.
    """
    
    predictions = db.query(Prediction).filter(
        Prediction.batch_id == batch_id
    ).order_by(Prediction.timestamp.desc()).limit(limit).all()
    
    return {
        "batch_id": batch_id,
        "count": len(predictions),
        "predictions": [
            {
                "id": p.id,
                "decay_score": p.decay_score,
                "quality_grade": p.quality_grade,
                "days_remaining": p.days_remaining,
                "recommended_action": p.recommended_action,
                "timestamp": p.timestamp.isoformat()
            }
            for p in predictions
        ]
    }


@router.get("/summary")
async def get_predictions_summary(db: Session = Depends(get_db)):
    """
    Get summary of all current predictions across inventory.
    """
    
    from sqlalchemy import func
    
    # Get latest prediction for each batch
    subquery = db.query(
        Prediction.batch_id,
        func.max(Prediction.timestamp).label('max_timestamp')
    ).group_by(Prediction.batch_id).subquery()
    
    latest_predictions = db.query(Prediction).join(
        subquery,
        (Prediction.batch_id == subquery.c.batch_id) &
        (Prediction.timestamp == subquery.c.max_timestamp)
    ).all()
    
    # Categorize by urgency
    critical = [p for p in latest_predictions if p.action_urgency == 'critical']
    high = [p for p in latest_predictions if p.action_urgency == 'high']
    medium = [p for p in latest_predictions if p.action_urgency == 'medium']
    low = [p for p in latest_predictions if p.action_urgency == 'low']
    
    # Calculate averages
    avg_decay = sum(p.decay_score for p in latest_predictions) / max(1, len(latest_predictions))
    avg_days = sum(p.days_remaining for p in latest_predictions) / max(1, len(latest_predictions))
    
    # Grade distribution
    grades = {'A': 0, 'B': 0, 'C': 0, 'D': 0}
    for p in latest_predictions:
        if p.quality_grade in grades:
            grades[p.quality_grade] += 1
    
    return {
        "total_batches_predicted": len(latest_predictions),
        "average_decay_score": round(avg_decay, 2),
        "average_days_remaining": round(avg_days, 1),
        "urgency_breakdown": {
            "critical": len(critical),
            "high": len(high),
            "medium": len(medium),
            "low": len(low)
        },
        "grade_distribution": grades,
        "items_requiring_action": len(critical) + len(high)
    }

