"""
Analytics and reporting API routes.
"""

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import func, and_
from typing import Optional
from datetime import datetime, timedelta

from database import get_db, Product, InventoryBatch, Prediction, Alert, SensorReading, PriceRecommendation
from services.price_optimizer import get_price_optimizer, PricingContext

router = APIRouter(prefix="/analytics", tags=["Analytics"])


@router.get("/dashboard")
async def dashboard_metrics(db: Session = Depends(get_db)):
    """
    Get key metrics for dashboard display.
    """
    
    # Total active batches
    total_batches = db.query(InventoryBatch).filter(
        InventoryBatch.status == "active"
    ).count()
    
    # Get latest predictions for active batches
    subquery = db.query(
        Prediction.batch_id,
        func.max(Prediction.timestamp).label('max_ts')
    ).group_by(Prediction.batch_id).subquery()
    
    latest_preds = db.query(Prediction).join(
        subquery,
        and_(
            Prediction.batch_id == subquery.c.batch_id,
            Prediction.timestamp == subquery.c.max_ts
        )
    ).all()
    
    # Calculate metrics
    if latest_preds:
        avg_decay = sum(p.decay_score for p in latest_preds) / len(latest_preds)
        avg_days_remaining = sum(p.days_remaining or 0 for p in latest_preds) / len(latest_preds)
    else:
        avg_decay = 0
        avg_days_remaining = 0
    
    # Risk breakdown
    critical = len([p for p in latest_preds if p.action_urgency == 'critical'])
    high = len([p for p in latest_preds if p.action_urgency == 'high'])
    medium = len([p for p in latest_preds if p.action_urgency == 'medium'])
    healthy = len(latest_preds) - critical - high - medium
    
    # Grade distribution
    grades = {'A': 0, 'B': 0, 'C': 0, 'D': 0}
    for p in latest_preds:
        if p.quality_grade in grades:
            grades[p.quality_grade] += 1
    
    # Value at risk
    value_at_risk = 0
    for p in latest_preds:
        if p.action_urgency in ['critical', 'high']:
            batch = db.query(InventoryBatch).filter(
                InventoryBatch.batch_id == p.batch_id
            ).first()
            if batch and batch.product:
                value_at_risk += batch.quantity * batch.product.unit_price
    
    # By category
    category_metrics = {}
    for p in latest_preds:
        batch = db.query(InventoryBatch).filter(
            InventoryBatch.batch_id == p.batch_id
        ).first()
        if batch:
            cat = batch.product.category
            if cat not in category_metrics:
                category_metrics[cat] = {
                    "count": 0,
                    "avg_decay": 0,
                    "critical": 0
                }
            category_metrics[cat]["count"] += 1
            category_metrics[cat]["avg_decay"] += p.decay_score
            if p.action_urgency == "critical":
                category_metrics[cat]["critical"] += 1
    
    for cat in category_metrics:
        if category_metrics[cat]["count"] > 0:
            category_metrics[cat]["avg_decay"] /= category_metrics[cat]["count"]
            category_metrics[cat]["avg_decay"] = round(category_metrics[cat]["avg_decay"], 1)
    
    return {
        "summary": {
            "total_active_batches": total_batches,
            "total_predicted": len(latest_preds),
            "average_decay_score": round(avg_decay, 1),
            "average_days_remaining": round(avg_days_remaining, 1),
            "value_at_risk": round(value_at_risk, 2)
        },
        "risk_breakdown": {
            "critical": critical,
            "high": high,
            "medium": medium,
            "healthy": healthy
        },
        "grade_distribution": grades,
        "by_category": category_metrics,
        "timestamp": datetime.now().isoformat()
    }


@router.get("/trends")
async def decay_trends(
    days: int = Query(default=30, le=90),
    category: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """
    Get decay score trends over time.
    """
    
    start_date = datetime.now() - timedelta(days=days)
    
    query = db.query(
        func.date(Prediction.timestamp).label('date'),
        func.avg(Prediction.decay_score).label('avg_decay'),
        func.avg(Prediction.days_remaining).label('avg_days_remaining'),
        func.count(Prediction.id).label('prediction_count')
    ).filter(Prediction.timestamp >= start_date)
    
    if category:
        query = query.join(InventoryBatch).join(Product).filter(
            Product.category == category
        )
    
    results = query.group_by(func.date(Prediction.timestamp)).order_by(
        func.date(Prediction.timestamp)
    ).all()
    
    return {
        "period_days": days,
        "category": category,
        "data": [
            {
                "date": str(r.date),
                "avg_decay_score": round(r.avg_decay, 2),
                "avg_days_remaining": round(r.avg_days_remaining or 0, 1),
                "predictions_made": r.prediction_count
            }
            for r in results
        ]
    }


@router.get("/waste-analysis")
async def waste_analysis(
    days: int = Query(default=30, le=90),
    db: Session = Depends(get_db)
):
    """
    Analyze waste patterns and causes.
    """
    
    # Get disposed/wasted batches
    wasted = db.query(InventoryBatch).filter(
        InventoryBatch.status == "disposed"
    ).all()
    
    # Waste by category
    waste_by_category = {}
    total_waste_value = 0
    total_waste_quantity = 0
    
    for batch in wasted:
        cat = batch.product.category
        value = batch.quantity * batch.product.unit_cost
        
        if cat not in waste_by_category:
            waste_by_category[cat] = {"quantity": 0, "value": 0, "batches": 0}
        
        waste_by_category[cat]["quantity"] += batch.quantity
        waste_by_category[cat]["value"] += value
        waste_by_category[cat]["batches"] += 1
        
        total_waste_value += value
        total_waste_quantity += batch.quantity
    
    # Root cause analysis (based on predictions)
    root_causes = {
        "temperature_issues": 0,
        "handling_damage": 0,
        "cold_chain_breaks": 0,
        "overstocking": 0,
        "unknown": 0
    }
    
    for batch in wasted:
        if batch.cold_chain_breaks > 0:
            root_causes["cold_chain_breaks"] += 1
        elif batch.handling_events > 2:
            root_causes["handling_damage"] += 1
        else:
            root_causes["unknown"] += 1
    
    return {
        "period_days": days,
        "total_waste": {
            "batches": len(wasted),
            "quantity": total_waste_quantity,
            "value": round(total_waste_value, 2)
        },
        "by_category": waste_by_category,
        "root_causes": root_causes,
        "prevention_opportunity": round(total_waste_value * 0.6, 2)  # Estimated preventable
    }


@router.get("/markdown-recommendations")
async def markdown_recommendations(
    limit: int = Query(default=20, le=100),
    db: Session = Depends(get_db)
):
    """
    Get markdown recommendations for at-risk inventory.
    """
    
    # Get active batches with high decay
    subquery = db.query(
        Prediction.batch_id,
        func.max(Prediction.timestamp).label('max_ts')
    ).group_by(Prediction.batch_id).subquery()
    
    at_risk = db.query(Prediction).join(
        subquery,
        and_(
            Prediction.batch_id == subquery.c.batch_id,
            Prediction.timestamp == subquery.c.max_ts
        )
    ).filter(
        Prediction.decay_score > 40
    ).order_by(Prediction.decay_score.desc()).limit(limit).all()
    
    optimizer = get_price_optimizer()
    recommendations = []
    
    for pred in at_risk:
        batch = db.query(InventoryBatch).filter(
            InventoryBatch.batch_id == pred.batch_id,
            InventoryBatch.status == "active"
        ).first()
        
        if not batch:
            continue
        
        product = batch.product
        
        context = PricingContext(
            product_id=product.product_id,
            batch_id=batch.batch_id,
            product_name=product.name,
            category=product.category,
            current_price=product.unit_price,
            cost=product.unit_cost,
            decay_score=pred.decay_score,
            days_remaining=pred.days_remaining or 1,
            current_inventory=batch.quantity,
            avg_daily_demand=5.0  # Default
        )
        
        rec = optimizer.optimize(context)
        recommendations.append(rec)
    
    # Summary
    total_revenue = sum(r["expected_revenue"] for r in recommendations)
    total_waste_prevented = sum(r["waste_prevented_value"] for r in recommendations)
    immediate_action = len([r for r in recommendations if r["urgency_level"] == "critical"])
    
    return {
        "summary": {
            "total_products": len(recommendations),
            "total_expected_revenue": round(total_revenue, 2),
            "total_waste_prevented": round(total_waste_prevented, 2),
            "immediate_action_required": immediate_action
        },
        "recommendations": recommendations
    }


@router.get("/temperature-monitoring")
async def temperature_monitoring(
    hours: int = Query(default=24, le=168),
    location: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """
    Get temperature monitoring data and excursions.
    """
    
    start_time = datetime.now() - timedelta(hours=hours)
    
    query = db.query(SensorReading).filter(
        SensorReading.timestamp >= start_time
    )
    
    if location:
        query = query.filter(SensorReading.location == location)
    
    readings = query.order_by(SensorReading.timestamp.desc()).limit(1000).all()
    
    # Aggregate by hour
    hourly_data = {}
    for r in readings:
        hour_key = r.timestamp.strftime("%Y-%m-%d %H:00")
        if hour_key not in hourly_data:
            hourly_data[hour_key] = {"temps": [], "humidity": [], "anomalies": 0}
        hourly_data[hour_key]["temps"].append(r.temperature)
        if r.humidity:
            hourly_data[hour_key]["humidity"].append(r.humidity)
        if r.is_anomaly:
            hourly_data[hour_key]["anomalies"] += 1
    
    timeline = []
    for hour, data in sorted(hourly_data.items()):
        timeline.append({
            "timestamp": hour,
            "avg_temperature": round(sum(data["temps"]) / len(data["temps"]), 2),
            "min_temperature": round(min(data["temps"]), 2),
            "max_temperature": round(max(data["temps"]), 2),
            "avg_humidity": round(sum(data["humidity"]) / len(data["humidity"]), 2) if data["humidity"] else None,
            "anomalies": data["anomalies"]
        })
    
    # Excursion summary
    total_anomalies = len([r for r in readings if r.is_anomaly])
    
    return {
        "period_hours": hours,
        "location": location,
        "total_readings": len(readings),
        "total_anomalies": total_anomalies,
        "anomaly_rate": round(total_anomalies / max(1, len(readings)) * 100, 2),
        "timeline": timeline[-48:]  # Last 48 data points
    }


@router.get("/prediction-accuracy")
async def prediction_accuracy(db: Session = Depends(get_db)):
    """
    Get model prediction accuracy metrics.
    """
    
    # This would compare predictions with actual outcomes
    # For demo, returning simulated metrics
    
    return {
        "decay_model": {
            "mae": 4.2,
            "rmse": 5.8,
            "r2_score": 0.89,
            "samples_evaluated": 1500,
            "last_retrained": "2024-01-15"
        },
        "shelf_life_model": {
            "mae_days": 0.8,
            "accuracy_within_1_day": 0.85,
            "accuracy_within_2_days": 0.94,
            "samples_evaluated": 1200
        },
        "overall_accuracy": 0.91,
        "improvement_vs_baseline": 0.23
    }


@router.get("/report/daily")
async def daily_report(
    date: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """
    Generate daily summary report.
    """
    
    from services.llm_service import get_llm_service
    
    # Get dashboard metrics
    metrics = await dashboard_metrics(db)
    
    # Get recommendations
    recs = await markdown_recommendations(limit=10, db=db)
    
    # Generate LLM summary
    try:
        llm = get_llm_service()
        summary_text = llm.generate_daily_report({
            "date": date or datetime.now().strftime("%Y-%m-%d"),
            "total_batches": metrics["summary"]["total_active_batches"],
            "critical_items": metrics["risk_breakdown"]["critical"],
            "high_risk_items": metrics["risk_breakdown"]["high"],
            "average_decay": metrics["summary"]["average_decay_score"],
            "value_at_risk": metrics["summary"]["value_at_risk"],
            "markdown_recommendations": recs["summary"]["total_products"],
            "potential_savings": recs["summary"]["total_waste_prevented"]
        })
    except Exception as e:
        summary_text = f"Daily report for {date or datetime.now().strftime('%Y-%m-%d')}. Review dashboard for details."
    
    return {
        "date": date or datetime.now().strftime("%Y-%m-%d"),
        "executive_summary": summary_text,
        "metrics": metrics,
        "top_recommendations": recs["recommendations"][:5],
        "generated_at": datetime.now().isoformat()
    }

