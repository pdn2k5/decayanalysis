"""
Voice synthesis API routes.
Provides text-to-speech capabilities for alerts and notifications.
"""

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import FileResponse
from typing import Optional
from pydantic import BaseModel

from services.voice_service import get_voice_service

router = APIRouter(prefix="/voice", tags=["Voice"])


class TextToSpeechRequest(BaseModel):
    text: str
    filename: Optional[str] = None


class VoiceSummaryRequest(BaseModel):
    critical_count: int = 0
    at_risk_count: int = 0
    waste_value: float = 0
    avg_decay: float = 0


# ============ ENDPOINTS ============

@router.get("/status")
async def voice_status():
    """Check voice service status and configuration."""
    
    voice = get_voice_service()
    
    return {
        "enabled": voice.enabled,
        "engine": voice.engine,
        "available_voices": voice.get_available_voices()
    }


@router.post("/speak")
async def text_to_speech(request: TextToSpeechRequest):
    """
    Convert text to speech and return audio file path.
    """
    
    voice = get_voice_service()
    
    if not voice.enabled:
        raise HTTPException(status_code=503, detail="Voice service is disabled")
    
    audio_path = voice.generate_audio_file(request.text, request.filename)
    
    if not audio_path:
        raise HTTPException(status_code=500, detail="Failed to generate audio")
    
    return {
        "message": "Audio generated",
        "audio_path": audio_path,
        "text": request.text[:100] + "..." if len(request.text) > 100 else request.text
    }


@router.post("/speak/base64")
async def text_to_speech_base64(request: TextToSpeechRequest):
    """
    Convert text to speech and return as base64 encoded audio.
    Useful for direct web playback without file serving.
    """
    
    voice = get_voice_service()
    
    if not voice.enabled:
        raise HTTPException(status_code=503, detail="Voice service is disabled")
    
    audio_base64 = voice.generate_audio_base64(request.text)
    
    if not audio_base64:
        raise HTTPException(status_code=500, detail="Failed to generate audio")
    
    return {
        "audio_base64": audio_base64,
        "audio_type": "audio/mp3",
        "text": request.text[:100] + "..." if len(request.text) > 100 else request.text
    }


@router.post("/daily-summary")
async def voice_daily_summary(request: VoiceSummaryRequest):
    """
    Generate voice summary of daily metrics.
    """
    
    voice = get_voice_service()
    
    if not voice.enabled:
        raise HTTPException(status_code=503, detail="Voice service is disabled")
    
    audio_path = voice.speak_daily_summary({
        "critical_count": request.critical_count,
        "at_risk_count": request.at_risk_count,
        "waste_value": request.waste_value,
        "avg_decay": request.avg_decay
    })
    
    if not audio_path:
        raise HTTPException(status_code=500, detail="Failed to generate summary audio")
    
    return {
        "message": "Daily summary audio generated",
        "audio_path": audio_path
    }


@router.post("/daily-summary/base64")
async def voice_daily_summary_base64(request: VoiceSummaryRequest):
    """
    Generate voice daily summary and return as base64.
    """
    
    voice = get_voice_service()
    
    if not voice.enabled:
        raise HTTPException(status_code=503, detail="Voice service is disabled")
    
    # Build summary text
    text = f"Good morning. Here's your daily inventory summary. "
    
    if request.critical_count > 0:
        text += f"You have {request.critical_count} critical items requiring immediate attention. "
    
    if request.at_risk_count > 0:
        text += f"{request.at_risk_count} items are at risk and should be reviewed today. "
    
    if request.waste_value > 0:
        text += f"Estimated waste prevention opportunity: ${request.waste_value:.0f}. "
    
    text += "Please check the dashboard for details."
    
    audio_base64 = voice.generate_audio_base64(text)
    
    if not audio_base64:
        raise HTTPException(status_code=500, detail="Failed to generate audio")
    
    return {
        "audio_base64": audio_base64,
        "audio_type": "audio/mp3",
        "text": text
    }


@router.get("/audio/{filename}")
async def get_audio_file(filename: str):
    """
    Serve generated audio file.
    """
    
    import os
    
    voice = get_voice_service()
    file_path = voice.audio_dir / filename
    
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Audio file not found")
    
    return FileResponse(
        path=str(file_path),
        media_type="audio/mpeg",
        filename=filename
    )


@router.post("/settings")
async def update_voice_settings(
    rate: Optional[int] = Query(default=None, ge=100, le=300),
    voice_id: Optional[str] = None
):
    """
    Update voice settings (rate, voice selection).
    """
    
    voice = get_voice_service()
    
    if not voice.enabled:
        raise HTTPException(status_code=503, detail="Voice service is disabled")
    
    if rate:
        voice.set_rate(rate)
    
    if voice_id:
        voice.set_voice(voice_id)
    
    return {
        "message": "Voice settings updated",
        "rate": rate,
        "voice_id": voice_id
    }


@router.get("/test")
async def test_voice():
    """
    Test voice synthesis with a sample message.
    """
    
    voice = get_voice_service()
    
    if not voice.enabled:
        return {
            "enabled": False,
            "message": "Voice service is disabled. Enable in configuration."
        }
    
    test_text = "Voice service is working correctly. This is a test message from the Decay Optimization Platform."
    
    audio_base64 = voice.generate_audio_base64(test_text)
    
    return {
        "enabled": True,
        "engine": voice.engine,
        "test_successful": audio_base64 is not None,
        "audio_base64": audio_base64 if audio_base64 else None,
        "audio_type": "audio/mp3" if audio_base64 else None
    }

