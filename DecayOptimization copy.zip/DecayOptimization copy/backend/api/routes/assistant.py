"""
AI Assistant API routes for natural language queries and insights.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func, and_
from typing import Optional
from datetime import datetime
from pydantic import BaseModel

from database import get_db, Product, InventoryBatch, Prediction, Alert
from services.llm_service import get_llm_service

router = APIRouter(prefix="/assistant", tags=["AI Assistant"])


class QueryRequest(BaseModel):
    query: str
    include_voice: bool = False


class ExplanationRequest(BaseModel):
    batch_id: str


class RootCauseRequest(BaseModel):
    batch_id: str


# ============ ENDPOINTS ============

@router.get("/status")
async def assistant_status():
    """Check LLM assistant status."""
    
    llm = get_llm_service()
    
    return {
        "provider": llm.provider,
        "model": llm.model if llm.provider == "ollama" else llm.settings.llm_api_model,
        "available": llm.is_available()
    }


@router.post("/query")
async def query_assistant(
    request: QueryRequest,
    db: Session = Depends(get_db)
):
    """
    Ask natural language questions about inventory and decay.
    
    Example queries:
    - "Which products should I markdown today?"
    - "Why is the milk at risk?"
    - "What's the status of dairy products?"
    - "Show me critical alerts"
    """
    
    llm = get_llm_service()
    
    # Build context from database
    # Get summary metrics
    total_batches = db.query(InventoryBatch).filter(
        InventoryBatch.status == "active"
    ).count()
    
    # Get latest predictions
    subquery = db.query(
        Prediction.batch_id,
        func.max(Prediction.timestamp).label('max_ts')
    ).group_by(Prediction.batch_id).subquery()
    
    latest_preds = db.query(Prediction).join(
        subquery,
        and_(
            Prediction.batch_id == subquery.c.batch_id,
            Prediction.timestamp == subquery.c.max_ts
        )
    ).limit(50).all()
    
    # Build context
    context = {
        "total_active_batches": total_batches,
        "predictions_available": len(latest_preds),
        "critical_items": [],
        "high_risk_items": [],
        "by_category": {}
    }
    
    for pred in latest_preds:
        batch = db.query(InventoryBatch).filter(
            InventoryBatch.batch_id == pred.batch_id
        ).first()
        
        if not batch:
            continue
        
        item_info = {
            "batch_id": pred.batch_id,
            "product_name": batch.product.name,
            "category": batch.product.category,
            "decay_score": pred.decay_score,
            "days_remaining": pred.days_remaining,
            "location": batch.location,
            "quantity": batch.quantity,
            "recommended_action": pred.recommended_action
        }
        
        if pred.action_urgency == "critical":
            context["critical_items"].append(item_info)
        elif pred.action_urgency == "high":
            context["high_risk_items"].append(item_info)
        
        cat = batch.product.category
        if cat not in context["by_category"]:
            context["by_category"][cat] = {"count": 0, "at_risk": 0}
        context["by_category"][cat]["count"] += 1
        if pred.action_urgency in ["critical", "high"]:
            context["by_category"][cat]["at_risk"] += 1
    
    # Query LLM
    response = llm.answer_query(request.query, context)
    
    # Generate voice if requested
    voice_audio = None
    if request.include_voice:
        from services.voice_service import get_voice_service
        voice = get_voice_service()
        if voice.enabled:
            voice_audio = voice.generate_audio_base64(response[:500])  # Limit length
    
    return {
        "query": request.query,
        "response": response,
        "context_summary": {
            "batches_analyzed": len(latest_preds),
            "critical_count": len(context["critical_items"]),
            "high_risk_count": len(context["high_risk_items"])
        },
        "voice_audio": voice_audio,
        "timestamp": datetime.now().isoformat()
    }


@router.post("/explain")
async def explain_prediction(
    request: ExplanationRequest,
    db: Session = Depends(get_db)
):
    """
    Get AI-generated explanation for a batch's decay prediction.
    """
    
    # Get batch and prediction
    batch = db.query(InventoryBatch).filter(
        InventoryBatch.batch_id == request.batch_id
    ).first()
    
    if not batch:
        raise HTTPException(status_code=404, detail="Batch not found")
    
    prediction = db.query(Prediction).filter(
        Prediction.batch_id == request.batch_id
    ).order_by(Prediction.timestamp.desc()).first()
    
    if not prediction:
        raise HTTPException(status_code=404, detail="No prediction found for batch")
    
    # Generate explanation
    llm = get_llm_service()
    explanation = llm.generate_decay_explanation({
        "product_name": batch.product.name,
        "category": batch.product.category,
        "decay_score": prediction.decay_score,
        "quality_grade": prediction.quality_grade,
        "days_remaining": prediction.days_remaining,
        "avg_temperature": prediction.input_features.get("avg_temperature") if prediction.input_features else None,
        "recommended_action": prediction.recommended_action,
        "handling_events": batch.handling_events,
        "cold_chain_breaks": batch.cold_chain_breaks
    })
    
    return {
        "batch_id": request.batch_id,
        "product_name": batch.product.name,
        "decay_score": prediction.decay_score,
        "quality_grade": prediction.quality_grade,
        "days_remaining": prediction.days_remaining,
        "explanation": explanation,
        "timestamp": datetime.now().isoformat()
    }


@router.post("/root-cause")
async def analyze_root_cause(
    request: RootCauseRequest,
    db: Session = Depends(get_db)
):
    """
    Perform root cause analysis for a batch's decay issues.
    """
    
    # Get batch info
    batch = db.query(InventoryBatch).filter(
        InventoryBatch.batch_id == request.batch_id
    ).first()
    
    if not batch:
        raise HTTPException(status_code=404, detail="Batch not found")
    
    # Get prediction
    prediction = db.query(Prediction).filter(
        Prediction.batch_id == request.batch_id
    ).order_by(Prediction.timestamp.desc()).first()
    
    # Get sensor anomalies
    from database import SensorReading
    anomalies = db.query(SensorReading).filter(
        SensorReading.batch_id == request.batch_id,
        SensorReading.is_anomaly == True
    ).all()
    
    # Build incident data
    incident_data = {
        "batch_id": request.batch_id,
        "product_name": batch.product.name,
        "category": batch.product.category,
        "decay_score": prediction.decay_score if prediction else None,
        "location": batch.location,
        "handling_events": batch.handling_events,
        "cold_chain_breaks": batch.cold_chain_breaks,
        "sensor_anomalies": len(anomalies),
        "anomaly_details": [
            {
                "type": a.anomaly_type,
                "temperature": a.temperature,
                "timestamp": a.timestamp.isoformat()
            }
            for a in anomalies[:5]
        ]
    }
    
    # Get similar historical incidents
    similar_batches = db.query(InventoryBatch).join(Product).filter(
        Product.category == batch.product.category,
        InventoryBatch.status == "disposed"
    ).limit(5).all()
    
    history = []
    for b in similar_batches:
        pred = db.query(Prediction).filter(
            Prediction.batch_id == b.batch_id
        ).order_by(Prediction.timestamp.desc()).first()
        
        if pred:
            history.append({
                "batch_id": b.batch_id,
                "product_name": b.product.name,
                "decay_score": pred.decay_score,
                "handling_events": b.handling_events,
                "cold_chain_breaks": b.cold_chain_breaks
            })
    
    # Generate analysis
    llm = get_llm_service()
    analysis = llm.generate_root_cause_analysis(incident_data, history)
    
    return {
        "batch_id": request.batch_id,
        "incident_data": incident_data,
        "similar_incidents": len(history),
        "analysis": analysis,
        "timestamp": datetime.now().isoformat()
    }


@router.get("/insights")
async def get_insights(db: Session = Depends(get_db)):
    """
    Get AI-generated insights about current inventory status.
    """
    
    # Get metrics
    from sqlalchemy import func
    
    total_batches = db.query(InventoryBatch).filter(
        InventoryBatch.status == "active"
    ).count()
    
    # Get predictions
    subquery = db.query(
        Prediction.batch_id,
        func.max(Prediction.timestamp).label('max_ts')
    ).group_by(Prediction.batch_id).subquery()
    
    latest_preds = db.query(Prediction).join(
        subquery,
        and_(
            Prediction.batch_id == subquery.c.batch_id,
            Prediction.timestamp == subquery.c.max_ts
        )
    ).all()
    
    critical = len([p for p in latest_preds if p.action_urgency == 'critical'])
    high = len([p for p in latest_preds if p.action_urgency == 'high'])
    avg_decay = sum(p.decay_score for p in latest_preds) / max(1, len(latest_preds))
    
    # Generate insights
    llm = get_llm_service()
    
    insights_prompt = f"""Based on the following inventory metrics, provide 3-4 key insights and recommendations:

- Total active batches: {total_batches}
- Critical items: {critical}
- High-risk items: {high}
- Average decay score: {avg_decay:.1f}%

Provide actionable insights in bullet point format."""

    insights = llm.generate(insights_prompt, max_tokens=400)
    
    return {
        "metrics": {
            "total_batches": total_batches,
            "critical": critical,
            "high_risk": high,
            "average_decay": round(avg_decay, 1)
        },
        "insights": insights,
        "timestamp": datetime.now().isoformat()
    }


@router.post("/chat")
async def chat(
    message: str,
    session_id: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """
    Interactive chat endpoint for conversational queries.
    """
    
    # For simplicity, treating each message independently
    # In production, would maintain conversation history
    
    request = QueryRequest(query=message, include_voice=False)
    response = await query_assistant(request, db)
    
    return {
        "session_id": session_id or "default",
        "user_message": message,
        "assistant_response": response["response"],
        "timestamp": datetime.now().isoformat()
    }

