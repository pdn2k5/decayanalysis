"""
Alert management API routes.
"""

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
from pydantic import BaseModel

from database import get_db, Alert as AlertModel
from services.alert_engine import get_alert_engine, AlertSeverity, AlertType
from services.voice_service import get_voice_service

router = APIRouter(prefix="/alerts", tags=["Alerts"])


# ============ PYDANTIC MODELS ============

class AlertResponse(BaseModel):
    alert_id: str
    alert_type: str
    severity: str
    title: str
    message: str
    smart_message: Optional[str]
    batch_id: Optional[str]
    product_name: Optional[str]
    location: Optional[str]
    category: Optional[str]
    estimated_loss: Optional[float]
    is_acknowledged: bool
    acknowledged_by: Optional[str]
    created_at: datetime
    voice_played: bool

    class Config:
        from_attributes = True


class AcknowledgeRequest(BaseModel):
    user: str


# ============ ENDPOINTS ============

@router.get("/", response_model=List[AlertResponse])
async def list_alerts(
    severity: Optional[str] = None,
    alert_type: Optional[str] = None,
    location: Optional[str] = None,
    acknowledged: Optional[bool] = None,
    limit: int = Query(default=50, le=200),
    db: Session = Depends(get_db)
):
    """
    List alerts with optional filtering.
    """
    
    alert_engine = get_alert_engine()
    
    # Convert string to enum if provided
    severity_enum = None
    if severity:
        try:
            severity_enum = AlertSeverity[severity.upper()]
        except KeyError:
            raise HTTPException(status_code=400, detail=f"Invalid severity: {severity}")
    
    type_enum = None
    if alert_type:
        try:
            type_enum = AlertType(alert_type)
        except ValueError:
            raise HTTPException(status_code=400, detail=f"Invalid alert type: {alert_type}")
    
    alerts = alert_engine.get_active_alerts(
        severity=severity_enum,
        alert_type=type_enum,
        location=location,
        acknowledged=acknowledged,
        limit=limit
    )
    
    return [
        AlertResponse(
            alert_id=a.alert_id,
            alert_type=a.alert_type.value,
            severity=a.severity.name,
            title=a.title,
            message=a.message,
            smart_message=a.smart_message,
            batch_id=a.batch_id,
            product_name=a.product_name,
            location=a.location,
            category=a.category,
            estimated_loss=a.estimated_loss,
            is_acknowledged=a.is_acknowledged,
            acknowledged_by=a.acknowledged_by,
            created_at=a.timestamp,
            voice_played=a.voice_played
        )
        for a in alerts
    ]


@router.get("/summary")
async def alerts_summary():
    """Get alert summary statistics."""
    
    alert_engine = get_alert_engine()
    return alert_engine.get_summary()


@router.post("/{alert_id}/acknowledge")
async def acknowledge_alert(alert_id: str, request: AcknowledgeRequest):
    """Acknowledge an alert."""
    
    alert_engine = get_alert_engine()
    success = alert_engine.acknowledge(alert_id, request.user)
    
    if not success:
        raise HTTPException(status_code=404, detail="Alert not found")
    
    return {"message": "Alert acknowledged", "alert_id": alert_id, "user": request.user}


@router.delete("/{alert_id}")
async def dismiss_alert(alert_id: str):
    """Dismiss/remove an alert."""
    
    alert_engine = get_alert_engine()
    success = alert_engine.dismiss(alert_id)
    
    if not success:
        raise HTTPException(status_code=404, detail="Alert not found")
    
    return {"message": "Alert dismissed", "alert_id": alert_id}


@router.post("/{alert_id}/voice")
async def generate_voice_alert(alert_id: str):
    """
    Generate voice audio for an alert.
    Returns audio file path for playback.
    """
    
    alert_engine = get_alert_engine()
    
    # Find the alert
    alert = None
    for a in alert_engine.active_alerts:
        if a.alert_id == alert_id:
            alert = a
            break
    
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    
    # Generate voice
    voice_service = get_voice_service()
    audio_path = voice_service.speak_alert({
        'alert_id': alert.alert_id,
        'severity': alert.severity.name,
        'title': alert.title,
        'message': alert.smart_message or alert.message,
        'product_name': alert.product_name,
        'location': alert.location
    })
    
    if not audio_path:
        raise HTTPException(status_code=500, detail="Failed to generate voice alert")
    
    # Mark as played
    alert.voice_played = True
    
    return {
        "alert_id": alert_id,
        "audio_path": audio_path,
        "message": "Voice alert generated"
    }


@router.get("/{alert_id}/voice/base64")
async def get_voice_alert_base64(alert_id: str):
    """
    Generate voice alert and return as base64 audio.
    Useful for direct web playback.
    """
    
    alert_engine = get_alert_engine()
    
    # Find the alert
    alert = None
    for a in alert_engine.active_alerts:
        if a.alert_id == alert_id:
            alert = a
            break
    
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    
    # Generate voice message
    severity = alert.severity.name
    if severity == "CRITICAL":
        voice_text = f"Critical Alert! {alert.title}. {alert.product_name or 'Product'} at {alert.location or 'location'}. {alert.smart_message or alert.message}. Immediate action required."
    elif severity == "HIGH":
        voice_text = f"High Priority Alert. {alert.title}. {alert.smart_message or alert.message}"
    else:
        voice_text = f"Attention. {alert.title}. {alert.smart_message or alert.message}"
    
    voice_service = get_voice_service()
    audio_base64 = voice_service.generate_audio_base64(voice_text)
    
    if not audio_base64:
        raise HTTPException(status_code=500, detail="Failed to generate voice")
    
    alert.voice_played = True
    
    return {
        "alert_id": alert_id,
        "audio_base64": audio_base64,
        "audio_type": "audio/mp3"
    }


@router.post("/test")
async def create_test_alert(
    severity: str = "HIGH",
    message: str = "This is a test alert"
):
    """Create a test alert for demo purposes."""
    
    from services.alert_engine import Alert, AlertType, AlertSeverity
    import uuid
    
    try:
        sev = AlertSeverity[severity.upper()]
    except KeyError:
        sev = AlertSeverity.HIGH
    
    alert = Alert(
        alert_id=f"TEST-{uuid.uuid4().hex[:8].upper()}",
        alert_type=AlertType.DECAY_THRESHOLD,
        severity=sev,
        title="Test Alert",
        message=message,
        product_name="Test Product",
        location="Test Location",
        category="Dairy"
    )
    
    alert_engine = get_alert_engine()
    alert_engine.active_alerts.append(alert)
    
    return {
        "message": "Test alert created",
        "alert_id": alert.alert_id,
        "severity": sev.name
    }


@router.delete("/clear")
async def clear_old_alerts(hours: int = 24):
    """Clear alerts older than specified hours."""
    
    alert_engine = get_alert_engine()
    before_count = len(alert_engine.active_alerts)
    alert_engine.clear_old_alerts(hours)
    after_count = len(alert_engine.active_alerts)
    
    return {
        "message": f"Cleared {before_count - after_count} old alerts",
        "remaining": after_count
    }

