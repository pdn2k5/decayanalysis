"""API routes for Decay Optimization Platform."""

from . import predictions, inventory, alerts, upload, analytics, voice, assistant

