"""
Data upload API routes for CSV/JSON file uploads.
"""

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session
from typing import Optional
from datetime import datetime
import pandas as pd
import json
import io

from database import get_db, Product, InventoryBatch, SensorReading, UploadHistory
from config import PRODUCT_CONFIG

router = APIRouter(prefix="/upload", tags=["Data Upload"])


@router.post("/products")
async def upload_products(
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """
    Upload products from CSV file.
    
    Expected columns: product_id, name, category, unit_price, unit_cost, 
                      packaging_type (optional), unit_weight_kg (optional),
                      listed_shelf_life_days (optional)
    """
    
    if not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="Only CSV files are supported")
    
    try:
        content = await file.read()
        df = pd.read_csv(io.BytesIO(content))
        
        required_cols = ['product_id', 'name', 'category', 'unit_price', 'unit_cost']
        missing = [col for col in required_cols if col not in df.columns]
        if missing:
            raise HTTPException(
                status_code=400, 
                detail=f"Missing required columns: {missing}"
            )
        
        processed = 0
        failed = 0
        errors = []
        
        for _, row in df.iterrows():
            try:
                # Validate category
                category = row['category']
                if category not in PRODUCT_CONFIG:
                    errors.append(f"Invalid category '{category}' for {row['product_id']}")
                    failed += 1
                    continue
                
                config = PRODUCT_CONFIG[category]
                
                # Check if exists
                existing = db.query(Product).filter(
                    Product.product_id == row['product_id']
                ).first()
                
                if existing:
                    # Update existing
                    existing.name = row['name']
                    existing.category = category
                    existing.unit_price = row['unit_price']
                    existing.unit_cost = row['unit_cost']
                    if 'packaging_type' in row and pd.notna(row['packaging_type']):
                        existing.packaging_type = row['packaging_type']
                    if 'unit_weight_kg' in row and pd.notna(row['unit_weight_kg']):
                        existing.unit_weight_kg = row['unit_weight_kg']
                else:
                    # Create new
                    product = Product(
                        product_id=row['product_id'],
                        name=row['name'],
                        category=category,
                        unit_price=row['unit_price'],
                        unit_cost=row['unit_cost'],
                        packaging_type=row.get('packaging_type') if pd.notna(row.get('packaging_type')) else None,
                        unit_weight_kg=row.get('unit_weight_kg', 1.0) if pd.notna(row.get('unit_weight_kg')) else 1.0,
                        listed_shelf_life_days=row.get('listed_shelf_life_days') if pd.notna(row.get('listed_shelf_life_days')) else config['base_shelf_life_days'],
                        optimal_temp_min=config['optimal_temp'][0],
                        optimal_temp_max=config['optimal_temp'][1],
                        optimal_humidity_min=config['optimal_humidity'][0],
                        optimal_humidity_max=config['optimal_humidity'][1]
                    )
                    db.add(product)
                
                processed += 1
                
            except Exception as e:
                errors.append(f"Error processing row {row.get('product_id', 'unknown')}: {str(e)}")
                failed += 1
        
        db.commit()
        
        # Log upload
        upload_log = UploadHistory(
            filename=file.filename,
            upload_type="products",
            records_processed=processed,
            records_failed=failed,
            status="success" if failed == 0 else "partial",
            error_message="; ".join(errors[:5]) if errors else None
        )
        db.add(upload_log)
        db.commit()
        
        return {
            "message": "Products uploaded",
            "processed": processed,
            "failed": failed,
            "errors": errors[:10] if errors else []
        }
        
    except pd.errors.EmptyDataError:
        raise HTTPException(status_code=400, detail="Empty CSV file")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/inventory")
async def upload_inventory(
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """
    Upload inventory batches from CSV file.
    
    Expected columns: batch_id, product_id, quantity, manufacture_date, 
                      location, expiry_date (optional), storage_zone (optional),
                      supplier_id (optional), supplier_name (optional),
                      initial_quality_score (optional), handling_events (optional),
                      cold_chain_breaks (optional)
    """
    
    if not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="Only CSV files are supported")
    
    try:
        content = await file.read()
        df = pd.read_csv(io.BytesIO(content))
        
        required_cols = ['batch_id', 'product_id', 'quantity', 'manufacture_date', 'location']
        missing = [col for col in required_cols if col not in df.columns]
        if missing:
            raise HTTPException(
                status_code=400,
                detail=f"Missing required columns: {missing}"
            )
        
        processed = 0
        failed = 0
        errors = []
        
        for _, row in df.iterrows():
            try:
                # Check product exists
                product = db.query(Product).filter(
                    Product.product_id == row['product_id']
                ).first()
                
                if not product:
                    errors.append(f"Product {row['product_id']} not found for batch {row['batch_id']}")
                    failed += 1
                    continue
                
                # Check if batch exists
                existing = db.query(InventoryBatch).filter(
                    InventoryBatch.batch_id == row['batch_id']
                ).first()
                
                # Parse dates
                mfg_date = pd.to_datetime(row['manufacture_date'])
                exp_date = pd.to_datetime(row.get('expiry_date')) if pd.notna(row.get('expiry_date')) else None
                
                if not exp_date and product.listed_shelf_life_days:
                    from datetime import timedelta
                    exp_date = mfg_date + timedelta(days=product.listed_shelf_life_days)
                
                if existing:
                    # Update
                    existing.quantity = row['quantity']
                    existing.manufacture_date = mfg_date
                    existing.expiry_date = exp_date
                    existing.location = row['location']
                    if 'handling_events' in row and pd.notna(row['handling_events']):
                        existing.handling_events = int(row['handling_events'])
                    if 'cold_chain_breaks' in row and pd.notna(row['cold_chain_breaks']):
                        existing.cold_chain_breaks = int(row['cold_chain_breaks'])
                else:
                    # Create new
                    batch = InventoryBatch(
                        batch_id=row['batch_id'],
                        product_id=row['product_id'],
                        quantity=row['quantity'],
                        manufacture_date=mfg_date,
                        expiry_date=exp_date,
                        location=row['location'],
                        storage_zone=row.get('storage_zone') if pd.notna(row.get('storage_zone')) else None,
                        initial_quality_score=row.get('initial_quality_score', 100.0) if pd.notna(row.get('initial_quality_score')) else 100.0,
                        supplier_id=row.get('supplier_id') if pd.notna(row.get('supplier_id')) else None,
                        supplier_name=row.get('supplier_name') if pd.notna(row.get('supplier_name')) else None,
                        handling_events=int(row.get('handling_events', 0)) if pd.notna(row.get('handling_events')) else 0,
                        cold_chain_breaks=int(row.get('cold_chain_breaks', 0)) if pd.notna(row.get('cold_chain_breaks')) else 0,
                        status="active"
                    )
                    db.add(batch)
                
                processed += 1
                
            except Exception as e:
                errors.append(f"Error processing batch {row.get('batch_id', 'unknown')}: {str(e)}")
                failed += 1
        
        db.commit()
        
        # Log upload
        upload_log = UploadHistory(
            filename=file.filename,
            upload_type="inventory",
            records_processed=processed,
            records_failed=failed,
            status="success" if failed == 0 else "partial",
            error_message="; ".join(errors[:5]) if errors else None
        )
        db.add(upload_log)
        db.commit()
        
        return {
            "message": "Inventory batches uploaded",
            "processed": processed,
            "failed": failed,
            "errors": errors[:10] if errors else []
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/sensors")
async def upload_sensor_data(
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """
    Upload sensor readings from CSV file.
    
    Expected columns: batch_id, temperature, timestamp,
                      humidity (optional), sensor_id (optional),
                      location (optional), ethylene_level (optional),
                      co2_level (optional)
    """
    
    if not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="Only CSV files are supported")
    
    try:
        content = await file.read()
        df = pd.read_csv(io.BytesIO(content))
        
        required_cols = ['batch_id', 'temperature', 'timestamp']
        missing = [col for col in required_cols if col not in df.columns]
        if missing:
            raise HTTPException(
                status_code=400,
                detail=f"Missing required columns: {missing}"
            )
        
        processed = 0
        failed = 0
        
        for _, row in df.iterrows():
            try:
                # Get batch to determine optimal temp
                batch = db.query(InventoryBatch).filter(
                    InventoryBatch.batch_id == row['batch_id']
                ).first()
                
                if not batch:
                    failed += 1
                    continue
                
                # Check for anomaly
                product = batch.product
                optimal_temp = (product.optimal_temp_min + product.optimal_temp_max) / 2
                temp_deviation = abs(row['temperature'] - optimal_temp)
                is_anomaly = temp_deviation > 3
                
                reading = SensorReading(
                    batch_id=row['batch_id'],
                    sensor_id=row.get('sensor_id') if pd.notna(row.get('sensor_id')) else None,
                    temperature=row['temperature'],
                    humidity=row.get('humidity') if pd.notna(row.get('humidity')) else None,
                    ethylene_level=row.get('ethylene_level') if pd.notna(row.get('ethylene_level')) else None,
                    co2_level=row.get('co2_level') if pd.notna(row.get('co2_level')) else None,
                    location=row.get('location') if pd.notna(row.get('location')) else batch.location,
                    is_anomaly=is_anomaly,
                    anomaly_type="temperature_excursion" if is_anomaly else None,
                    timestamp=pd.to_datetime(row['timestamp'])
                )
                db.add(reading)
                processed += 1
                
            except Exception as e:
                failed += 1
        
        db.commit()
        
        # Log upload
        upload_log = UploadHistory(
            filename=file.filename,
            upload_type="sensors",
            records_processed=processed,
            records_failed=failed,
            status="success" if failed == 0 else "partial"
        )
        db.add(upload_log)
        db.commit()
        
        return {
            "message": "Sensor data uploaded",
            "processed": processed,
            "failed": failed
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/history")
async def upload_history(
    limit: int = 20,
    db: Session = Depends(get_db)
):
    """Get recent upload history."""
    
    uploads = db.query(UploadHistory).order_by(
        UploadHistory.uploaded_at.desc()
    ).limit(limit).all()
    
    return {
        "uploads": [
            {
                "id": u.id,
                "filename": u.filename,
                "upload_type": u.upload_type,
                "records_processed": u.records_processed,
                "records_failed": u.records_failed,
                "status": u.status,
                "error_message": u.error_message,
                "uploaded_at": u.uploaded_at.isoformat()
            }
            for u in uploads
        ]
    }


@router.post("/sample-data")
async def load_sample_data(db: Session = Depends(get_db)):
    """
    Load pre-generated sample data for demo purposes.
    Generates synthetic data for all 4 product categories.
    """
    
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
    
    from data.generate_synthetic_data import create_sample_datasets
    
    try:
        # Generate datasets
        datasets = create_sample_datasets("data/sample_datasets")
        
        # Load products
        products_df = datasets["products"]
        products_loaded = 0
        
        for _, row in products_df.iterrows():
            existing = db.query(Product).filter(
                Product.product_id == row['product_id']
            ).first()
            
            if not existing:
                product = Product(
                    product_id=row['product_id'],
                    name=row['name'],
                    category=row['category'],
                    packaging_type=row.get('packaging_type'),
                    unit_weight_kg=row.get('unit_weight_kg', 1.0),
                    unit_cost=row['unit_cost'],
                    unit_price=row['unit_price'],
                    listed_shelf_life_days=row.get('listed_shelf_life_days'),
                    optimal_temp_min=row.get('optimal_temp_min'),
                    optimal_temp_max=row.get('optimal_temp_max'),
                    optimal_humidity_min=row.get('optimal_humidity_min'),
                    optimal_humidity_max=row.get('optimal_humidity_max')
                )
                db.add(product)
                products_loaded += 1
        
        db.commit()
        
        # Load inventory
        inventory_df = datasets["inventory"]
        batches_loaded = 0
        
        for _, row in inventory_df.iterrows():
            existing = db.query(InventoryBatch).filter(
                InventoryBatch.batch_id == row['batch_id']
            ).first()
            
            if not existing:
                batch = InventoryBatch(
                    batch_id=row['batch_id'],
                    product_id=row['product_id'],
                    quantity=row['quantity'],
                    manufacture_date=pd.to_datetime(row['manufacture_date']),
                    expiry_date=pd.to_datetime(row['expiry_date']) if pd.notna(row.get('expiry_date')) else None,
                    received_date=pd.to_datetime(row['received_date']) if pd.notna(row.get('received_date')) else None,
                    location=row['location'],
                    storage_zone=row.get('storage_zone'),
                    initial_quality_score=row.get('initial_quality_score', 100.0),
                    supplier_id=row.get('supplier_id'),
                    supplier_name=row.get('supplier_name'),
                    handling_events=row.get('handling_events', 0),
                    cold_chain_breaks=row.get('cold_chain_breaks', 0),
                    status="active"
                )
                db.add(batch)
                batches_loaded += 1
        
        db.commit()
        
        # Load sensor readings (sample)
        sensors_df = datasets["sensors"].head(5000)  # Limit for performance
        sensors_loaded = 0
        
        for _, row in sensors_df.iterrows():
            reading = SensorReading(
                batch_id=row['batch_id'],
                sensor_id=row.get('sensor_id'),
                temperature=row['temperature'],
                humidity=row.get('humidity'),
                ethylene_level=row.get('ethylene_level'),
                co2_level=row.get('co2_level'),
                location=row.get('location'),
                is_anomaly=row.get('is_anomaly', False),
                anomaly_type=row.get('anomaly_type'),
                timestamp=pd.to_datetime(row['timestamp'])
            )
            db.add(reading)
            sensors_loaded += 1
            
            if sensors_loaded % 500 == 0:
                db.commit()
        
        db.commit()
        
        return {
            "message": "Sample data loaded successfully",
            "products_loaded": products_loaded,
            "batches_loaded": batches_loaded,
            "sensor_readings_loaded": sensors_loaded
        }
        
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

