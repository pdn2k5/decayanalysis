"""
Inventory management API routes.
"""

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List, Optional
from datetime import datetime
from pydantic import BaseModel

from database import get_db, Product, InventoryBatch, Prediction, SensorReading
from config import PRODUCT_CONFIG

router = APIRouter(prefix="/inventory", tags=["Inventory"])


# ============ PYDANTIC MODELS ============

class ProductCreate(BaseModel):
    product_id: str
    name: str
    category: str
    packaging_type: Optional[str] = None
    unit_weight_kg: float = 1.0
    unit_cost: float
    unit_price: float
    listed_shelf_life_days: Optional[int] = None


class BatchCreate(BaseModel):
    batch_id: str
    product_id: str
    quantity: int
    manufacture_date: datetime
    expiry_date: Optional[datetime] = None
    location: str
    storage_zone: Optional[str] = None
    supplier_id: Optional[str] = None
    supplier_name: Optional[str] = None
    initial_quality_score: float = 100.0


class InventoryItem(BaseModel):
    batch_id: str
    product_id: str
    product_name: str
    category: str
    quantity: int
    location: str
    manufacture_date: datetime
    days_since_manufacture: float
    decay_score: Optional[float]
    quality_grade: str
    days_remaining: Optional[float]
    recommended_action: Optional[str]
    status: str

    class Config:
        from_attributes = True


# ============ ENDPOINTS ============

@router.get("/products")
async def list_products(
    category: Optional[str] = None,
    is_active: bool = True,
    db: Session = Depends(get_db)
):
    """List all products with optional filtering."""
    
    query = db.query(Product)
    
    if category:
        query = query.filter(Product.category == category)
    if is_active is not None:
        query = query.filter(Product.is_active == is_active)
    
    products = query.all()
    
    return {
        "count": len(products),
        "products": [
            {
                "product_id": p.product_id,
                "name": p.name,
                "category": p.category,
                "unit_price": p.unit_price,
                "unit_cost": p.unit_cost,
                "shelf_life_days": p.listed_shelf_life_days,
                "optimal_temp": f"{p.optimal_temp_min}-{p.optimal_temp_max}°C"
            }
            for p in products
        ]
    }


@router.post("/products")
async def create_product(product: ProductCreate, db: Session = Depends(get_db)):
    """Create a new product."""
    
    # Check if product exists
    existing = db.query(Product).filter(Product.product_id == product.product_id).first()
    if existing:
        raise HTTPException(status_code=400, detail="Product ID already exists")
    
    # Get category config
    config = PRODUCT_CONFIG.get(product.category)
    if not config:
        raise HTTPException(status_code=400, detail=f"Invalid category. Must be one of: {list(PRODUCT_CONFIG.keys())}")
    
    # Create product
    db_product = Product(
        product_id=product.product_id,
        name=product.name,
        category=product.category,
        packaging_type=product.packaging_type,
        unit_weight_kg=product.unit_weight_kg,
        unit_cost=product.unit_cost,
        unit_price=product.unit_price,
        listed_shelf_life_days=product.listed_shelf_life_days or config["base_shelf_life_days"],
        optimal_temp_min=config["optimal_temp"][0],
        optimal_temp_max=config["optimal_temp"][1],
        optimal_humidity_min=config["optimal_humidity"][0],
        optimal_humidity_max=config["optimal_humidity"][1]
    )
    
    db.add(db_product)
    db.commit()
    db.refresh(db_product)
    
    return {"message": "Product created", "product_id": db_product.product_id}


@router.get("/batches")
async def list_batches(
    category: Optional[str] = None,
    location: Optional[str] = None,
    status: str = "active",
    min_decay_score: Optional[float] = None,
    max_days_remaining: Optional[float] = None,
    limit: int = Query(default=100, le=500),
    db: Session = Depends(get_db)
):
    """
    List inventory batches with filtering and prediction data.
    """
    
    # Base query with product join
    query = db.query(InventoryBatch).join(Product)
    
    # Apply filters
    if category:
        query = query.filter(Product.category == category)
    if location:
        query = query.filter(InventoryBatch.location == location)
    if status:
        query = query.filter(InventoryBatch.status == status)
    
    batches = query.limit(limit).all()
    
    # Get latest predictions
    result = []
    for batch in batches:
        # Get latest prediction
        latest_pred = db.query(Prediction).filter(
            Prediction.batch_id == batch.batch_id
        ).order_by(Prediction.timestamp.desc()).first()
        
        # Calculate days since manufacture
        days_elapsed = (datetime.now() - batch.manufacture_date).total_seconds() / 86400
        
        item = {
            "batch_id": batch.batch_id,
            "product_id": batch.product_id,
            "product_name": batch.product.name,
            "category": batch.product.category,
            "quantity": batch.quantity,
            "location": batch.location,
            "storage_zone": batch.storage_zone,
            "manufacture_date": batch.manufacture_date.isoformat(),
            "expiry_date": batch.expiry_date.isoformat() if batch.expiry_date else None,
            "days_since_manufacture": round(days_elapsed, 1),
            "initial_quality_score": batch.initial_quality_score,
            "handling_events": batch.handling_events,
            "cold_chain_breaks": batch.cold_chain_breaks,
            "status": batch.status,
            "decay_score": latest_pred.decay_score if latest_pred else None,
            "quality_grade": latest_pred.quality_grade if latest_pred else batch.current_quality_grade,
            "days_remaining": latest_pred.days_remaining if latest_pred else None,
            "recommended_action": latest_pred.recommended_action if latest_pred else None,
            "action_urgency": latest_pred.action_urgency if latest_pred else None,
            "last_prediction": latest_pred.timestamp.isoformat() if latest_pred else None
        }
        
        # Apply additional filters
        if min_decay_score and (not item["decay_score"] or item["decay_score"] < min_decay_score):
            continue
        if max_days_remaining and (not item["days_remaining"] or item["days_remaining"] > max_days_remaining):
            continue
        
        result.append(item)
    
    # Sort by decay score (highest first)
    result.sort(key=lambda x: x.get("decay_score") or 0, reverse=True)
    
    return {
        "count": len(result),
        "filters_applied": {
            "category": category,
            "location": location,
            "status": status,
            "min_decay_score": min_decay_score,
            "max_days_remaining": max_days_remaining
        },
        "batches": result
    }


@router.post("/batches")
async def create_batch(batch: BatchCreate, db: Session = Depends(get_db)):
    """Create a new inventory batch."""
    
    # Check product exists
    product = db.query(Product).filter(Product.product_id == batch.product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    
    # Check batch ID is unique
    existing = db.query(InventoryBatch).filter(InventoryBatch.batch_id == batch.batch_id).first()
    if existing:
        raise HTTPException(status_code=400, detail="Batch ID already exists")
    
    # Calculate expiry if not provided
    expiry_date = batch.expiry_date
    if not expiry_date and product.listed_shelf_life_days:
        from datetime import timedelta
        expiry_date = batch.manufacture_date + timedelta(days=product.listed_shelf_life_days)
    
    # Create batch
    db_batch = InventoryBatch(
        batch_id=batch.batch_id,
        product_id=batch.product_id,
        quantity=batch.quantity,
        manufacture_date=batch.manufacture_date,
        expiry_date=expiry_date,
        location=batch.location,
        storage_zone=batch.storage_zone,
        initial_quality_score=batch.initial_quality_score,
        supplier_id=batch.supplier_id,
        supplier_name=batch.supplier_name,
        status="active"
    )
    
    db.add(db_batch)
    db.commit()
    
    return {"message": "Batch created", "batch_id": db_batch.batch_id}


@router.get("/batches/{batch_id}")
async def get_batch_details(batch_id: str, db: Session = Depends(get_db)):
    """Get detailed information about a specific batch."""
    
    batch = db.query(InventoryBatch).filter(
        InventoryBatch.batch_id == batch_id
    ).first()
    
    if not batch:
        raise HTTPException(status_code=404, detail="Batch not found")
    
    product = batch.product
    
    # Get prediction history
    predictions = db.query(Prediction).filter(
        Prediction.batch_id == batch_id
    ).order_by(Prediction.timestamp.desc()).limit(10).all()
    
    # Get recent sensor readings
    sensors = db.query(SensorReading).filter(
        SensorReading.batch_id == batch_id
    ).order_by(SensorReading.timestamp.desc()).limit(50).all()
    
    # Calculate stats
    days_elapsed = (datetime.now() - batch.manufacture_date).total_seconds() / 86400
    
    return {
        "batch": {
            "batch_id": batch.batch_id,
            "product_id": batch.product_id,
            "product_name": product.name,
            "category": product.category,
            "quantity": batch.quantity,
            "location": batch.location,
            "storage_zone": batch.storage_zone,
            "manufacture_date": batch.manufacture_date.isoformat(),
            "expiry_date": batch.expiry_date.isoformat() if batch.expiry_date else None,
            "days_since_manufacture": round(days_elapsed, 1),
            "initial_quality_score": batch.initial_quality_score,
            "current_quality_grade": batch.current_quality_grade,
            "handling_events": batch.handling_events,
            "cold_chain_breaks": batch.cold_chain_breaks,
            "supplier_id": batch.supplier_id,
            "supplier_name": batch.supplier_name,
            "status": batch.status
        },
        "product": {
            "unit_price": product.unit_price,
            "unit_cost": product.unit_cost,
            "shelf_life_days": product.listed_shelf_life_days,
            "optimal_temp": f"{product.optimal_temp_min}-{product.optimal_temp_max}°C",
            "optimal_humidity": f"{product.optimal_humidity_min}-{product.optimal_humidity_max}%"
        },
        "latest_prediction": {
            "decay_score": predictions[0].decay_score if predictions else None,
            "quality_grade": predictions[0].quality_grade if predictions else None,
            "days_remaining": predictions[0].days_remaining if predictions else None,
            "recommended_action": predictions[0].recommended_action if predictions else None,
            "explanation": predictions[0].explanation if predictions else None,
            "timestamp": predictions[0].timestamp.isoformat() if predictions else None
        },
        "prediction_history": [
            {
                "decay_score": p.decay_score,
                "quality_grade": p.quality_grade,
                "timestamp": p.timestamp.isoformat()
            }
            for p in predictions
        ],
        "sensor_data": {
            "count": len(sensors),
            "latest_temperature": sensors[0].temperature if sensors else None,
            "latest_humidity": sensors[0].humidity if sensors else None,
            "anomalies_detected": len([s for s in sensors if s.is_anomaly])
        }
    }


@router.patch("/batches/{batch_id}/status")
async def update_batch_status(
    batch_id: str,
    status: str,
    db: Session = Depends(get_db)
):
    """Update batch status (active, markdown, donated, disposed)."""
    
    valid_statuses = ["active", "markdown", "donated", "disposed", "sold"]
    if status not in valid_statuses:
        raise HTTPException(
            status_code=400, 
            detail=f"Invalid status. Must be one of: {valid_statuses}"
        )
    
    batch = db.query(InventoryBatch).filter(
        InventoryBatch.batch_id == batch_id
    ).first()
    
    if not batch:
        raise HTTPException(status_code=404, detail="Batch not found")
    
    batch.status = status
    db.commit()
    
    return {"message": f"Batch status updated to {status}", "batch_id": batch_id}


@router.get("/locations")
async def list_locations(db: Session = Depends(get_db)):
    """Get list of all inventory locations."""
    
    locations = db.query(InventoryBatch.location).distinct().all()
    
    result = []
    for (loc,) in locations:
        count = db.query(InventoryBatch).filter(
            InventoryBatch.location == loc,
            InventoryBatch.status == "active"
        ).count()
        result.append({"location": loc, "active_batches": count})
    
    return {"locations": result}


@router.get("/summary")
async def inventory_summary(db: Session = Depends(get_db)):
    """Get inventory summary by category and status."""
    
    # Total counts by category
    category_counts = db.query(
        Product.category,
        func.count(InventoryBatch.id).label('batch_count'),
        func.sum(InventoryBatch.quantity).label('total_quantity')
    ).join(InventoryBatch).filter(
        InventoryBatch.status == "active"
    ).group_by(Product.category).all()
    
    # Get predictions for risk assessment
    from sqlalchemy import and_
    
    subquery = db.query(
        Prediction.batch_id,
        func.max(Prediction.timestamp).label('max_ts')
    ).group_by(Prediction.batch_id).subquery()
    
    latest_preds = db.query(Prediction).join(
        subquery,
        and_(
            Prediction.batch_id == subquery.c.batch_id,
            Prediction.timestamp == subquery.c.max_ts
        )
    ).all()
    
    # Risk breakdown
    critical = len([p for p in latest_preds if p.action_urgency == 'critical'])
    high_risk = len([p for p in latest_preds if p.action_urgency == 'high'])
    medium_risk = len([p for p in latest_preds if p.action_urgency == 'medium'])
    
    # Calculate total value at risk
    total_value = 0
    for pred in latest_preds:
        if pred.action_urgency in ['critical', 'high']:
            batch = db.query(InventoryBatch).filter(
                InventoryBatch.batch_id == pred.batch_id
            ).first()
            if batch and batch.product:
                total_value += batch.quantity * batch.product.unit_price
    
    return {
        "by_category": [
            {
                "category": cat,
                "batch_count": count,
                "total_quantity": qty or 0
            }
            for cat, count, qty in category_counts
        ],
        "risk_summary": {
            "critical": critical,
            "high": high_risk,
            "medium": medium_risk,
            "healthy": len(latest_preds) - critical - high_risk - medium_risk
        },
        "total_value_at_risk": round(total_value, 2),
        "total_active_batches": sum(c[1] for c in category_counts)
    }

