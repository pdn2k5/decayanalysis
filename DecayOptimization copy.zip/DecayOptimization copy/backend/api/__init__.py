"""API routes module for Decay Optimization Platform."""

from .routes import predictions, inventory, alerts, upload, analytics, voice, assistant

__all__ = [
    "predictions",
    "inventory", 
    "alerts",
    "upload",
    "analytics",
    "voice",
    "assistant"
]

