"""
Decay Optimization Platform - FastAPI Backend
AI-driven decay analysis and shelf-life prediction for perishable goods.
"""

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse
import uvicorn
import os
from pathlib import Path
from datetime import datetime

from config import get_settings
from database import init_db

# Create FastAPI app
app = FastAPI(
    title="Decay Optimization Platform",
    description="""
    AI-driven decay analysis and shelf-life prediction for perishable goods.
    
    ## Features
    - **Decay Prediction**: ML-based decay score prediction
    - **Shelf-Life Estimation**: Survival analysis for remaining shelf life
    - **Dynamic Pricing**: Optimal markdown recommendations
    - **Alert Engine**: Real-time alerts with LLM-enhanced messages
    - **Voice Synthesis**: Text-to-speech for alerts and summaries
    - **AI Assistant**: Natural language queries about inventory
    
    ## Product Categories
    - Dairy
    - Fruits
    - Vegetables
    - Meat
    """,
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc"
)

# CORS middleware for React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create static directories
Path("static/audio").mkdir(parents=True, exist_ok=True)
Path("data/sample_datasets").mkdir(parents=True, exist_ok=True)
Path("ml_models/saved").mkdir(parents=True, exist_ok=True)

# Mount static files
app.mount("/static", StaticFiles(directory="static"), name="static")


# ============ IMPORT AND REGISTER ROUTES ============

from api.routes import predictions, inventory, alerts, upload, analytics, voice, assistant

app.include_router(predictions.router, prefix="/api/v1")
app.include_router(inventory.router, prefix="/api/v1")
app.include_router(alerts.router, prefix="/api/v1")
app.include_router(upload.router, prefix="/api/v1")
app.include_router(analytics.router, prefix="/api/v1")
app.include_router(voice.router, prefix="/api/v1")
app.include_router(assistant.router, prefix="/api/v1")


# ============ STARTUP/SHUTDOWN EVENTS ============

@app.on_event("startup")
async def startup_event():
    """Initialize database and services on startup."""
    print("🚀 Starting Decay Optimization Platform...")
    
    # Initialize database
    init_db()
    print("✅ Database initialized")
    
    # Check LLM service
    from services.llm_service import get_llm_service
    try:
        llm = get_llm_service()
        if llm.is_available():
            print(f"✅ LLM service available ({llm.provider})")
        else:
            print(f"⚠️ LLM service not available, using fallback responses")
    except Exception as e:
        print(f"⚠️ LLM service error: {e}")
    
    # Check voice service
    from services.voice_service import get_voice_service
    try:
        voice = get_voice_service()
        if voice.enabled:
            print(f"✅ Voice service enabled ({voice.engine})")
        else:
            print("⚠️ Voice service disabled")
    except Exception as e:
        print(f"⚠️ Voice service error: {e}")
    
    print("✅ Platform ready!")


@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown."""
    print("👋 Shutting down Decay Optimization Platform...")


# ============ ROOT ENDPOINTS ============

@app.get("/")
async def root():
    """Root endpoint with API information."""
    return {
        "name": "Decay Optimization Platform",
        "version": "1.0.0",
        "description": "AI-driven decay analysis and shelf-life prediction for perishable goods",
        "categories": ["Dairy", "Fruits", "Vegetables", "Meat"],
        "documentation": "/api/docs",
        "health": "/health",
        "timestamp": datetime.now().isoformat()
    }


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    from database import engine
    from sqlalchemy import text
    
    # Check database
    db_status = "healthy"
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
    except Exception as e:
        db_status = f"unhealthy: {str(e)}"
    
    # Check LLM
    llm_status = "unknown"
    try:
        from services.llm_service import get_llm_service
        llm = get_llm_service()
        llm_status = "available" if llm.is_available() else "unavailable"
    except:
        llm_status = "error"
    
    return {
        "status": "healthy" if db_status == "healthy" else "degraded",
        "components": {
            "database": db_status,
            "llm_service": llm_status,
            "api": "healthy"
        },
        "timestamp": datetime.now().isoformat()
    }


@app.get("/api/v1")
async def api_root():
    """API v1 root with available endpoints."""
    return {
        "version": "1.0",
        "endpoints": {
            "predictions": "/api/v1/predictions",
            "inventory": "/api/v1/inventory",
            "alerts": "/api/v1/alerts",
            "upload": "/api/v1/upload",
            "analytics": "/api/v1/analytics",
            "voice": "/api/v1/voice",
            "assistant": "/api/v1/assistant"
        }
    }


# ============ ERROR HANDLERS ============

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Global exception handler."""
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal server error",
            "detail": str(exc),
            "path": str(request.url)
        }
    )


# ============ MAIN ============

if __name__ == "__main__":
    settings = get_settings()
    
    print("""
    ╔═══════════════════════════════════════════════════════════╗
    ║         DECAY OPTIMIZATION PLATFORM                       ║
    ║   AI-driven decay analysis and shelf-life prediction      ║
    ╠═══════════════════════════════════════════════════════════╣
    ║   Categories: Dairy, Fruits, Vegetables, Meat             ║
    ║   API Docs: http://localhost:8000/api/docs                ║
    ╚═══════════════════════════════════════════════════════════╝
    """)
    
    uvicorn.run(
        "main:app",
        host=settings.app_host,
        port=settings.app_port,
        reload=settings.debug
    )

