"""
SQLAlchemy ORM models for Decay Optimization Platform.
Supports SQLite database on Windows.
"""

from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Text, JSON
from sqlalchemy.orm import relationship, declarative_base
from sqlalchemy.sql import func
from datetime import datetime

Base = declarative_base()


class Product(Base):
    """Product master data."""
    __tablename__ = "products"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    product_id = Column(String(50), unique=True, nullable=False, index=True)
    name = Column(String(200), nullable=False)
    category = Column(String(50), nullable=False, index=True)  # Dairy, Fruits, Vegetables, Meat
    
    # Product attributes
    packaging_type = Column(String(100))
    unit_weight_kg = Column(Float, default=1.0)
    unit_cost = Column(Float)
    unit_price = Column(Float)
    
    # Shelf life info
    listed_shelf_life_days = Column(Integer)
    optimal_temp_min = Column(Float)
    optimal_temp_max = Column(Float)
    optimal_humidity_min = Column(Float)
    optimal_humidity_max = Column(Float)
    
    # Metadata
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    is_active = Column(Boolean, default=True)
    
    # Relationships
    inventory_batches = relationship("InventoryBatch", back_populates="product")
    
    def __repr__(self):
        return f"<Product {self.product_id}: {self.name}>"


class InventoryBatch(Base):
    """Inventory batch tracking."""
    __tablename__ = "inventory_batches"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    batch_id = Column(String(50), unique=True, nullable=False, index=True)
    product_id = Column(String(50), ForeignKey("products.product_id"), nullable=False)
    
    # Batch info
    quantity = Column(Integer, nullable=False)
    manufacture_date = Column(DateTime, nullable=False)
    expiry_date = Column(DateTime)
    received_date = Column(DateTime, default=func.now())
    
    # Location
    location = Column(String(200))
    storage_zone = Column(String(100))
    
    # Quality
    initial_quality_score = Column(Float, default=100.0)
    current_quality_grade = Column(String(1), default="A")
    
    # Supplier info
    supplier_id = Column(String(50))
    supplier_name = Column(String(200))
    
    # Tracking
    handling_events = Column(Integer, default=0)
    cold_chain_breaks = Column(Integer, default=0)
    
    # Status
    status = Column(String(50), default="active")  # active, markdown, donated, disposed
    
    # Metadata
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    
    # Relationships
    product = relationship("Product", back_populates="inventory_batches")
    sensor_readings = relationship("SensorReading", back_populates="batch")
    predictions = relationship("Prediction", back_populates="batch")
    alerts = relationship("Alert", back_populates="batch")
    price_recommendations = relationship("PriceRecommendation", back_populates="batch")
    
    def __repr__(self):
        return f"<InventoryBatch {self.batch_id}>"


class SensorReading(Base):
    """IoT sensor readings for environmental monitoring."""
    __tablename__ = "sensor_readings"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    batch_id = Column(String(50), ForeignKey("inventory_batches.batch_id"), nullable=False, index=True)
    sensor_id = Column(String(50), index=True)
    
    # Environmental data
    temperature = Column(Float, nullable=False)
    humidity = Column(Float)
    ethylene_level = Column(Float)  # For fruits
    co2_level = Column(Float)
    
    # Location
    location = Column(String(200))
    
    # Quality indicators
    is_anomaly = Column(Boolean, default=False)
    anomaly_type = Column(String(100))
    
    # Timestamp
    timestamp = Column(DateTime, default=func.now(), index=True)
    
    # Relationships
    batch = relationship("InventoryBatch", back_populates="sensor_readings")
    
    def __repr__(self):
        return f"<SensorReading {self.id} @ {self.timestamp}>"


class Prediction(Base):
    """AI model predictions."""
    __tablename__ = "predictions"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    batch_id = Column(String(50), ForeignKey("inventory_batches.batch_id"), nullable=False, index=True)
    
    # Prediction outputs
    decay_score = Column(Float, nullable=False)
    quality_grade = Column(String(1))
    days_remaining = Column(Float)
    confidence_lower = Column(Float)
    confidence_upper = Column(Float)
    
    # Model info
    model_version = Column(String(50))
    prediction_type = Column(String(50))  # decay, shelf_life, visual
    
    # Recommendation
    recommended_action = Column(String(100))
    action_urgency = Column(String(20))  # critical, high, medium, low
    
    # LLM explanation
    explanation = Column(Text)
    
    # Input features (for debugging/audit)
    input_features = Column(JSON)
    
    # Timestamp
    timestamp = Column(DateTime, default=func.now(), index=True)
    
    # Relationships
    batch = relationship("InventoryBatch", back_populates="predictions")
    
    def __repr__(self):
        return f"<Prediction {self.id}: Decay={self.decay_score}%>"


class Alert(Base):
    """System alerts and notifications."""
    __tablename__ = "alerts"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    alert_id = Column(String(50), unique=True, nullable=False, index=True)
    batch_id = Column(String(50), ForeignKey("inventory_batches.batch_id"), index=True)
    
    # Alert details
    alert_type = Column(String(50), nullable=False)  # decay_threshold, temperature_excursion, etc.
    severity = Column(String(20), nullable=False)  # critical, high, medium, low
    title = Column(String(200), nullable=False)
    message = Column(Text, nullable=False)
    
    # Smart alert (LLM generated)
    smart_message = Column(Text)
    
    # Location
    location = Column(String(200))
    
    # Financial impact
    estimated_loss = Column(Float)
    
    # Status
    is_acknowledged = Column(Boolean, default=False)
    acknowledged_by = Column(String(100))
    acknowledged_at = Column(DateTime)
    is_resolved = Column(Boolean, default=False)
    resolved_at = Column(DateTime)
    
    # Voice alert flag
    voice_alert_played = Column(Boolean, default=False)
    
    # Timestamp
    created_at = Column(DateTime, default=func.now(), index=True)
    
    # Relationships
    batch = relationship("InventoryBatch", back_populates="alerts")
    
    def __repr__(self):
        return f"<Alert {self.alert_id}: {self.severity}>"


class PriceRecommendation(Base):
    """Dynamic pricing recommendations."""
    __tablename__ = "price_recommendations"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    batch_id = Column(String(50), ForeignKey("inventory_batches.batch_id"), nullable=False, index=True)
    
    # Original pricing
    original_price = Column(Float, nullable=False)
    cost = Column(Float, nullable=False)
    
    # Recommendation
    recommended_markdown_pct = Column(Float)
    recommended_price = Column(Float)
    
    # Expected outcomes
    expected_revenue = Column(Float)
    expected_units_sold = Column(Float)
    waste_prevented_kg = Column(Float)
    
    # Urgency
    urgency_level = Column(String(20))  # immediate, today, scheduled
    action_timing = Column(String(50))
    
    # Reasoning
    markdown_reason = Column(Text)
    
    # Status
    is_applied = Column(Boolean, default=False)
    applied_at = Column(DateTime)
    actual_price = Column(Float)
    
    # Timestamp
    created_at = Column(DateTime, default=func.now())
    
    # Relationships
    batch = relationship("InventoryBatch", back_populates="price_recommendations")
    
    def __repr__(self):
        return f"<PriceRecommendation {self.id}: {self.recommended_markdown_pct}% off>"


class UploadHistory(Base):
    """Track data uploads."""
    __tablename__ = "upload_history"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    filename = Column(String(255), nullable=False)
    upload_type = Column(String(50))  # products, inventory, sensors
    records_processed = Column(Integer)
    records_failed = Column(Integer, default=0)
    status = Column(String(50))  # success, partial, failed
    error_message = Column(Text)
    uploaded_at = Column(DateTime, default=func.now())
    
    def __repr__(self):
        return f"<Upload {self.filename}: {self.status}>"


class AnalyticsSnapshot(Base):
    """Daily analytics snapshots."""
    __tablename__ = "analytics_snapshots"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    snapshot_date = Column(DateTime, nullable=False, index=True)
    
    # Inventory metrics
    total_batches = Column(Integer)
    critical_batches = Column(Integer)
    warning_batches = Column(Integer)
    healthy_batches = Column(Integer)
    
    # Waste metrics
    total_waste_kg = Column(Float, default=0)
    total_waste_value = Column(Float, default=0)
    waste_by_category = Column(JSON)
    
    # Financial metrics
    potential_loss_prevented = Column(Float, default=0)
    markdown_revenue = Column(Float, default=0)
    
    # Prediction accuracy
    prediction_accuracy = Column(Float)
    
    # By category breakdown
    metrics_by_category = Column(JSON)
    
    created_at = Column(DateTime, default=func.now())
    
    def __repr__(self):
        return f"<AnalyticsSnapshot {self.snapshot_date}>"

