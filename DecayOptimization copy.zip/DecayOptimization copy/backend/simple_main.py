"""
Decay Optimization Platform - Simplified FastAPI Backend
AI-driven decay analysis and shelf-life prediction for perishable goods.
"""

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import uvicorn
from datetime import datetime, timedelta
from pathlib import Path
import random
import json

# Create FastAPI app
app = FastAPI(
    title="Decay Optimization Platform",
    description="AI-driven decay analysis and shelf-life prediction",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create static directories
Path("static/audio").mkdir(parents=True, exist_ok=True)
Path("data/sample_datasets").mkdir(parents=True, exist_ok=True)

# Mount static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# ============ IN-MEMORY DATA STORE ============

SAMPLE_DATA = {
    "products": [],
    "batches": [],
    "alerts": [],
    "predictions": []
}

CATEGORIES = ["Dairy", "Fruits", "Vegetables", "Meat"]
PRODUCT_NAMES = {
    "Dairy": ["Milk", "Cheese", "Yogurt", "Butter", "Cream"],
    "Fruits": ["Apples", "Bananas", "Oranges", "Strawberries", "Grapes"],
    "Vegetables": ["Lettuce", "Tomatoes", "Carrots", "Broccoli", "Spinach"],
    "Meat": ["Chicken", "Beef", "Pork", "Fish", "Turkey"]
}

# ============ HELPER FUNCTIONS ============

def generate_sample_data():
    """Generate comprehensive sample data"""
    SAMPLE_DATA["products"] = []
    SAMPLE_DATA["batches"] = []
    SAMPLE_DATA["alerts"] = []
    SAMPLE_DATA["predictions"] = []
    
    batch_id = 1
    for category in CATEGORIES:
        for product_name in PRODUCT_NAMES[category]:
            # Create batches for each product
            for i in range(random.randint(2, 4)):
                decay_score = random.uniform(10, 85)
                shelf_life = random.randint(1, 14)
                quantity = random.randint(50, 500)
                
                batch = {
                    "batch_id": f"BATCH-{batch_id:04d}",
                    "product_name": product_name,
                    "category": category,
                    "quantity": quantity,
                    "received_date": (datetime.now() - timedelta(days=random.randint(1, 10))).isoformat(),
                    "expiry_date": (datetime.now() + timedelta(days=shelf_life)).isoformat(),
                    "location": random.choice(["Warehouse A", "Warehouse B", "Store 1", "Store 2"]),
                    "temperature": round(random.uniform(2, 8), 1),
                    "humidity": round(random.uniform(45, 75), 1),
                    "decay_score": round(decay_score, 2),
                    "shelf_life_days": shelf_life,
                    "grade": "A" if decay_score < 30 else "B" if decay_score < 50 else "C" if decay_score < 70 else "D",
                    "status": "active"
                }
                SAMPLE_DATA["batches"].append(batch)
                
                # Generate alert if decay is high
                if decay_score > 60:
                    alert = {
                        "alert_id": f"ALERT-{len(SAMPLE_DATA['alerts']) + 1:04d}",
                        "batch_id": batch["batch_id"],
                        "product_name": product_name,
                        "severity": "CRITICAL" if decay_score > 75 else "HIGH",
                        "alert_type": "HIGH_DECAY" if decay_score > 75 else "APPROACHING_EXPIRY",
                        "title": f"High decay detected in {product_name}",
                        "message": f"Batch {batch['batch_id']} showing {decay_score:.1f}% decay",
                        "location": batch["location"],
                        "created_at": datetime.now().isoformat(),
                        "acknowledged": False
                    }
                    SAMPLE_DATA["alerts"].append(alert)
                
                batch_id += 1
    
    return len(SAMPLE_DATA["batches"])

# Initialize with sample data
generate_sample_data()

# ============ ROOT ENDPOINTS ============

@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "name": "Decay Optimization Platform",
        "version": "1.0.0",
        "description": "AI-driven decay analysis and shelf-life prediction for perishable goods",
        "categories": CATEGORIES,
        "total_batches": len(SAMPLE_DATA["batches"]),
        "total_alerts": len(SAMPLE_DATA["alerts"]),
        "documentation": "/api/docs",
        "health": "/health",
        "timestamp": datetime.now().isoformat()
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "components": {
            "database": "healthy",
            "sample_data": f"{len(SAMPLE_DATA['batches'])} batches loaded",
            "api": "healthy"
        },
        "timestamp": datetime.now().isoformat()
    }

# ============ ANALYTICS ENDPOINTS ============

@app.get("/api/v1/analytics/dashboard")
async def get_dashboard_metrics():
    """Get dashboard metrics"""
    batches = SAMPLE_DATA["batches"]
    
    if not batches:
        generate_sample_data()
        batches = SAMPLE_DATA["batches"]
    
    total_batches = len(batches)
    total_quantity = sum(b["quantity"] for b in batches)
    avg_decay = sum(b["decay_score"] for b in batches) / total_batches if total_batches > 0 else 0
    
    # Risk breakdown
    critical = len([b for b in batches if b["decay_score"] > 75])
    high = len([b for b in batches if 60 < b["decay_score"] <= 75])
    medium = len([b for b in batches if 40 < b["decay_score"] <= 60])
    low = len([b for b in batches if b["decay_score"] <= 40])
    
    # Grade distribution
    grade_dist = {"A": 0, "B": 0, "C": 0, "D": 0}
    for batch in batches:
        grade_dist[batch["grade"]] += 1
    
    # By category
    by_category = {}
    for category in CATEGORIES:
        cat_batches = [b for b in batches if b["category"] == category]
        if cat_batches:
            by_category[category] = {
                "count": len(cat_batches),
                "avg_decay": round(sum(b["decay_score"] for b in cat_batches) / len(cat_batches), 2),
                "total_quantity": sum(b["quantity"] for b in cat_batches)
            }
    
    return {
        "summary": {
            "total_active_batches": total_batches,
            "total_predicted": total_batches,
            "average_decay_score": round(avg_decay, 2),
            "total_quantity": total_quantity,
            "value_at_risk": round(critical * 5000 + high * 2000, 2)
        },
        "risk_breakdown": {
            "critical": critical,
            "high": high,
            "medium": medium,
            "low": low
        },
        "grade_distribution": grade_dist,
        "by_category": by_category
    }

@app.get("/api/v1/analytics/trends")
async def get_decay_trends(days: int = 14, category: Optional[str] = None):
    """Get decay trends over time"""
    data_points = []
    for i in range(days):
        date = (datetime.now() - timedelta(days=days - i - 1)).strftime("%Y-%m-%d")
        data_points.append({
            "date": date,
            "avg_decay": round(random.uniform(30, 60), 2),
            "batches_predicted": random.randint(10, 30),
            "alerts_generated": random.randint(0, 5)
        })
    
    return {
        "data": data_points,
        "period": f"{days} days",
        "category": category
    }

# ============ ALERTS ENDPOINTS ============

@app.get("/api/v1/alerts/")
async def get_alerts(limit: int = 10, severity: Optional[str] = None):
    """Get alerts"""
    alerts = SAMPLE_DATA["alerts"]
    
    if severity:
        alerts = [a for a in alerts if a["severity"] == severity]
    
    return alerts[:limit]

@app.get("/api/v1/alerts/summary")
async def get_alerts_summary():
    """Get alerts summary"""
    alerts = SAMPLE_DATA["alerts"]
    return {
        "total_active": len([a for a in alerts if not a["acknowledged"]]),
        "total_acknowledged": len([a for a in alerts if a["acknowledged"]]),
        "by_severity": {
            "CRITICAL": len([a for a in alerts if a["severity"] == "CRITICAL"]),
            "HIGH": len([a for a in alerts if a["severity"] == "HIGH"]),
            "MEDIUM": len([a for a in alerts if a["severity"] == "MEDIUM"]),
            "LOW": len([a for a in alerts if a["severity"] == "LOW"])
        }
    }

@app.post("/api/v1/alerts/{alert_id}/acknowledge")
async def acknowledge_alert(alert_id: str, user: Dict[str, str] = None):
    """Acknowledge an alert"""
    for alert in SAMPLE_DATA["alerts"]:
        if alert["alert_id"] == alert_id:
            alert["acknowledged"] = True
            alert["acknowledged_at"] = datetime.now().isoformat()
            alert["acknowledged_by"] = user.get("name") if user else "system"
            return {"message": "Alert acknowledged", "alert": alert}
    
    raise HTTPException(status_code=404, detail="Alert not found")

# ============ INVENTORY ENDPOINTS ============

@app.get("/api/v1/inventory/batches")
async def get_batches(category: Optional[str] = None, status: Optional[str] = None):
    """Get inventory batches"""
    batches = SAMPLE_DATA["batches"]
    
    if category:
        batches = [b for b in batches if b["category"] == category]
    
    if status:
        batches = [b for b in batches if b["status"] == status]
    
    return batches

@app.get("/api/v1/inventory/summary")
async def get_inventory_summary():
    """Get inventory summary"""
    batches = SAMPLE_DATA["batches"]
    
    by_category = {}
    for category in CATEGORIES:
        cat_batches = [b for b in batches if b["category"] == category]
        by_category[category] = {
            "count": len(cat_batches),
            "total_quantity": sum(b["quantity"] for b in cat_batches)
        }
    
    return {
        "total_batches": len(batches),
        "total_quantity": sum(b["quantity"] for b in batches),
        "by_category": by_category,
        "by_grade": {
            "A": len([b for b in batches if b["grade"] == "A"]),
            "B": len([b for b in batches if b["grade"] == "B"]),
            "C": len([b for b in batches if b["grade"] == "C"]),
            "D": len([b for b in batches if b["grade"] == "D"])
        }
    }

@app.get("/api/v1/inventory/locations")
async def get_locations():
    """Get all locations"""
    locations = list(set(b["location"] for b in SAMPLE_DATA["batches"]))
    return locations

# ============ UPLOAD ENDPOINTS ============

@app.post("/api/v1/upload/sample-data")
async def load_sample_data():
    """Load fresh sample data"""
    count = generate_sample_data()
    return {
        "message": "Sample data loaded successfully",
        "batches_created": count,
        "alerts_created": len(SAMPLE_DATA["alerts"]),
        "timestamp": datetime.now().isoformat()
    }

@app.post("/api/v1/upload/products")
async def upload_products(file: UploadFile = File(...)):
    """Upload products CSV"""
    return {
        "message": "Products uploaded successfully",
        "filename": file.filename,
        "records_processed": random.randint(10, 50)
    }

@app.post("/api/v1/upload/inventory")
async def upload_inventory(file: UploadFile = File(...)):
    """Upload inventory CSV"""
    return {
        "message": "Inventory uploaded successfully",
        "filename": file.filename,
        "records_processed": random.randint(10, 50)
    }

# ============ VOICE ENDPOINTS ============

@app.post("/api/v1/voice/daily-summary")
async def voice_daily_summary(data: Dict[str, Any]):
    """Generate voice summary"""
    return {
        "text": f"Daily summary: {data.get('critical_count', 0)} critical items, "
                f"{data.get('at_risk_count', 0)} items at risk, "
                f"estimated waste value: ${data.get('waste_value', 0):.2f}",
        "audio_url": "/static/audio/summary.mp3"
    }

@app.get("/api/v1/voice/speak")
async def speak_text(text: str):
    """Convert text to speech"""
    return {
        "text": text,
        "audio_url": "/static/audio/speech.mp3"
    }

# ============ ASSISTANT ENDPOINTS ============

@app.post("/api/v1/assistant/explain")
async def explain_prediction(data: Dict[str, Any]):
    """Explain a prediction"""
    return {
        "explanation": f"The decay prediction for this batch is based on temperature ({data.get('temperature', 'N/A')}°C), "
                      f"humidity ({data.get('humidity', 'N/A')}%), and time since receipt.",
        "confidence": 0.87,
        "factors": [
            {"name": "Temperature", "impact": 0.4, "status": "normal"},
            {"name": "Humidity", "impact": 0.3, "status": "normal"},
            {"name": "Time", "impact": 0.3, "status": "warning"}
        ]
    }

@app.post("/api/v1/assistant/query")
async def query_assistant(data: Dict[str, Any]):
    """Query the AI assistant"""
    query = data.get("query", "")
    
    # Simple response based on keywords
    if "high" in query.lower() or "alert" in query.lower():
        response = f"Currently, you have {len([a for a in SAMPLE_DATA['alerts'] if not a['acknowledged']])} active alerts. "
        response += f"{len([a for a in SAMPLE_DATA['alerts'] if a['severity'] == 'CRITICAL'])} are critical priority."
    elif "category" in query.lower() or "dairy" in query.lower() or "fruit" in query.lower():
        response = "Your inventory includes Dairy, Fruits, Vegetables, and Meat categories. "
        response += f"Total of {len(SAMPLE_DATA['batches'])} active batches across all categories."
    else:
        response = f"I'm analyzing your inventory data. You have {len(SAMPLE_DATA['batches'])} active batches "
        response += f"with an average decay score of {sum(b['decay_score'] for b in SAMPLE_DATA['batches']) / len(SAMPLE_DATA['batches']):.1f}%."
    
    return {
        "query": query,
        "response": response,
        "timestamp": datetime.now().isoformat()
    }

# ============ MARKDOWN/PRICE ENDPOINTS ============

@app.get("/api/v1/analytics/markdown-recommendations")
async def get_markdown_recommendations(limit: int = 20):
    """Get markdown recommendations"""
    recommendations = []
    high_decay_batches = [b for b in SAMPLE_DATA["batches"] if b["decay_score"] > 50][:limit]
    
    for batch in high_decay_batches:
        discount = min(int((batch["decay_score"] - 50) * 1.5), 70)
        recommendations.append({
            "batch_id": batch["batch_id"],
            "product_name": batch["product_name"],
            "category": batch["category"],
            "current_price": round(random.uniform(5, 50), 2),
            "recommended_discount": discount,
            "recommended_price": round(random.uniform(3, 40), 2),
            "reason": f"High decay score ({batch['decay_score']:.1f}%)",
            "urgency": "high" if batch["decay_score"] > 70 else "medium"
        })
    
    return recommendations

# ============ COLD CHAIN ENDPOINTS ============

@app.get("/api/v1/analytics/temperature-monitoring")
async def get_temperature_monitoring(hours: int = 24, location: Optional[str] = None):
    """Get temperature monitoring data"""
    data_points = []
    for i in range(hours):
        timestamp = (datetime.now() - timedelta(hours=hours - i)).isoformat()
        data_points.append({
            "timestamp": timestamp,
            "temperature": round(random.uniform(2, 8), 1),
            "humidity": round(random.uniform(50, 70), 1),
            "location": location or random.choice(["Warehouse A", "Warehouse B", "Store 1"])
        })
    
    return {
        "data": data_points,
        "period": f"{hours} hours",
        "location": location
    }

# ============ MAIN ============

if __name__ == "__main__":
    print("""
    ╔═══════════════════════════════════════════════════════════╗
    ║         DECAY OPTIMIZATION PLATFORM                       ║
    ║   AI-driven decay analysis and shelf-life prediction      ║
    ╠═══════════════════════════════════════════════════════════╣
    ║   Categories: Dairy, Fruits, Vegetables, Meat             ║
    ║   API Docs: http://localhost:8000/api/docs                ║
    ║   Sample Data: Generated automatically                    ║
    ╚═══════════════════════════════════════════════════════════╝
    """)
    
    uvicorn.run(
        "simple_main:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )

