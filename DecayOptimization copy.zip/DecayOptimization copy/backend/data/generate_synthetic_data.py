"""
Synthetic Data Generator for Decay Optimization Platform.
Generates realistic data for: Dairy, Fruits, Vegetables, Meat
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import uuid
import json
import os

# Seed for reproducibility
np.random.seed(42)

# Product configurations
PRODUCT_CONFIGS = {
    "Dairy": {
        "optimal_temp": (2, 4),
        "optimal_humidity": (80, 90),
        "base_shelf_life": 14,
        "decay_rate": 0.8,
        "products": [
            {"name": "Whole Milk", "unit_price": 4.99, "unit_cost": 2.50, "weight": 1.0},
            {"name": "Greek Yogurt", "unit_price": 6.49, "unit_cost": 3.20, "weight": 0.5},
            {"name": "Cheddar Cheese", "unit_price": 8.99, "unit_cost": 5.00, "weight": 0.4},
            {"name": "Butter", "unit_price": 5.99, "unit_cost": 3.00, "weight": 0.25},
            {"name": "Heavy Cream", "unit_price": 4.49, "unit_cost": 2.20, "weight": 0.5},
            {"name": "Cottage Cheese", "unit_price": 4.99, "unit_cost": 2.40, "weight": 0.45},
        ]
    },
    "Fruits": {
        "optimal_temp": (4, 8),
        "optimal_humidity": (85, 95),
        "base_shelf_life": 10,
        "decay_rate": 1.0,
        "products": [
            {"name": "Strawberries", "unit_price": 5.99, "unit_cost": 2.80, "weight": 0.5},
            {"name": "Bananas", "unit_price": 1.49, "unit_cost": 0.60, "weight": 1.0},
            {"name": "Apples", "unit_price": 3.99, "unit_cost": 1.80, "weight": 1.0},
            {"name": "Oranges", "unit_price": 4.49, "unit_cost": 2.00, "weight": 1.2},
            {"name": "Grapes", "unit_price": 6.99, "unit_cost": 3.50, "weight": 0.8},
            {"name": "Blueberries", "unit_price": 7.99, "unit_cost": 4.00, "weight": 0.3},
        ]
    },
    "Vegetables": {
        "optimal_temp": (4, 10),
        "optimal_humidity": (90, 98),
        "base_shelf_life": 7,
        "decay_rate": 1.1,
        "products": [
            {"name": "Lettuce", "unit_price": 2.99, "unit_cost": 1.20, "weight": 0.4},
            {"name": "Tomatoes", "unit_price": 3.49, "unit_cost": 1.50, "weight": 0.6},
            {"name": "Carrots", "unit_price": 2.49, "unit_cost": 1.00, "weight": 0.5},
            {"name": "Spinach", "unit_price": 4.99, "unit_cost": 2.20, "weight": 0.3},
            {"name": "Broccoli", "unit_price": 3.99, "unit_cost": 1.80, "weight": 0.5},
            {"name": "Bell Peppers", "unit_price": 4.49, "unit_cost": 2.00, "weight": 0.4},
        ]
    },
    "Meat": {
        "optimal_temp": (-1, 2),
        "optimal_humidity": (80, 85),
        "base_shelf_life": 5,
        "decay_rate": 1.3,
        "products": [
            {"name": "Chicken Breast", "unit_price": 9.99, "unit_cost": 5.50, "weight": 0.5},
            {"name": "Ground Beef", "unit_price": 8.49, "unit_cost": 4.80, "weight": 0.5},
            {"name": "Pork Chops", "unit_price": 7.99, "unit_cost": 4.20, "weight": 0.6},
            {"name": "Salmon Fillet", "unit_price": 14.99, "unit_cost": 9.00, "weight": 0.4},
            {"name": "Turkey", "unit_price": 8.99, "unit_cost": 5.00, "weight": 0.5},
            {"name": "Lamb Chops", "unit_price": 16.99, "unit_cost": 10.00, "weight": 0.4},
        ]
    }
}

LOCATIONS = [
    "Store 101 - Main Floor",
    "Store 101 - Cold Storage",
    "Store 102 - Downtown",
    "Store 103 - Suburban",
    "Warehouse A - North",
    "Warehouse B - South"
]

SUPPLIERS = [
    ("SUP001", "Fresh Farms Co."),
    ("SUP002", "Valley Dairy"),
    ("SUP003", "Ocean Fresh"),
    ("SUP004", "Green Valley Produce"),
    ("SUP005", "Premium Meats Inc.")
]


def generate_product_id(category: str, index: int) -> str:
    """Generate unique product ID."""
    prefix = {
        "Dairy": "DRY",
        "Fruits": "FRT",
        "Vegetables": "VEG",
        "Meat": "MET"
    }
    return f"{prefix[category]}-{index:04d}"


def generate_batch_id() -> str:
    """Generate unique batch ID."""
    return f"BATCH-{uuid.uuid4().hex[:8].upper()}"


def generate_products_dataset() -> pd.DataFrame:
    """Generate master product data."""
    products = []
    product_index = 1
    
    for category, config in PRODUCT_CONFIGS.items():
        for prod in config["products"]:
            product_id = generate_product_id(category, product_index)
            products.append({
                "product_id": product_id,
                "name": prod["name"],
                "category": category,
                "packaging_type": np.random.choice([
                    "Plastic Container", "Vacuum Sealed", "Modified Atmosphere",
                    "Cardboard Box", "Plastic Wrap", "Glass Container"
                ]),
                "unit_weight_kg": prod["weight"],
                "unit_cost": prod["unit_cost"],
                "unit_price": prod["unit_price"],
                "listed_shelf_life_days": config["base_shelf_life"],
                "optimal_temp_min": config["optimal_temp"][0],
                "optimal_temp_max": config["optimal_temp"][1],
                "optimal_humidity_min": config["optimal_humidity"][0],
                "optimal_humidity_max": config["optimal_humidity"][1]
            })
            product_index += 1
    
    return pd.DataFrame(products)


def generate_inventory_batches(products_df: pd.DataFrame, n_batches: int = 100) -> pd.DataFrame:
    """Generate inventory batch data."""
    batches = []
    
    for _ in range(n_batches):
        product = products_df.sample(1).iloc[0]
        supplier = SUPPLIERS[np.random.randint(0, len(SUPPLIERS))]
        
        # Random manufacture date (1-15 days ago)
        days_ago = np.random.randint(1, 15)
        manufacture_date = datetime.now() - timedelta(days=days_ago)
        
        # Expiry based on shelf life
        shelf_life = product["listed_shelf_life_days"]
        expiry_date = manufacture_date + timedelta(days=shelf_life)
        
        # Quality degradation based on time
        quality_degradation = min(50, days_ago * np.random.uniform(2, 5))
        initial_quality = 100 - np.random.uniform(0, 5)
        
        batches.append({
            "batch_id": generate_batch_id(),
            "product_id": product["product_id"],
            "quantity": np.random.randint(10, 200),
            "manufacture_date": manufacture_date.isoformat(),
            "expiry_date": expiry_date.isoformat(),
            "received_date": (manufacture_date + timedelta(hours=np.random.randint(6, 48))).isoformat(),
            "location": np.random.choice(LOCATIONS),
            "storage_zone": np.random.choice(["Zone A", "Zone B", "Zone C", "Zone D"]),
            "initial_quality_score": round(initial_quality, 2),
            "supplier_id": supplier[0],
            "supplier_name": supplier[1],
            "handling_events": np.random.poisson(1),
            "cold_chain_breaks": np.random.poisson(0.2),
            "status": "active"
        })
    
    return pd.DataFrame(batches)


def generate_sensor_readings(batches_df: pd.DataFrame, products_df: pd.DataFrame, 
                             hours: int = 168) -> pd.DataFrame:
    """Generate sensor readings for batches over time period."""
    readings = []
    
    for _, batch in batches_df.iterrows():
        product = products_df[products_df["product_id"] == batch["product_id"]].iloc[0]
        
        # Get optimal conditions
        opt_temp = (product["optimal_temp_min"] + product["optimal_temp_max"]) / 2
        opt_humidity = (product["optimal_humidity_min"] + product["optimal_humidity_max"]) / 2
        
        # Generate readings every 30 minutes
        n_readings = hours * 2  # Every 30 min
        base_time = datetime.fromisoformat(batch["received_date"])
        
        for i in range(min(n_readings, 100)):  # Limit readings per batch
            timestamp = base_time + timedelta(minutes=i * 30)
            
            # Add realistic variations
            daily_cycle = 0.5 * np.sin(2 * np.pi * i / 48)  # 24-hour cycle
            random_walk = np.cumsum(np.random.normal(0, 0.05, 1))[0]
            
            # Temperature with occasional excursions
            temp = opt_temp + daily_cycle + random_walk + np.random.normal(0, 0.3)
            if np.random.random() < 0.02:  # 2% chance of excursion
                temp += np.random.uniform(3, 8)
            
            # Humidity
            humidity = opt_humidity + np.random.normal(0, 2)
            
            # Anomaly detection
            temp_deviation = abs(temp - opt_temp)
            is_anomaly = temp_deviation > 3
            
            readings.append({
                "batch_id": batch["batch_id"],
                "sensor_id": f"SENSOR-{batch['location'][:3].upper()}-{np.random.randint(1, 10):02d}",
                "temperature": round(temp, 2),
                "humidity": round(np.clip(humidity, 30, 100), 2),
                "ethylene_level": round(np.random.uniform(0, 2), 3) if product["category"] == "Fruits" else None,
                "co2_level": round(np.random.uniform(350, 600), 1),
                "location": batch["location"],
                "is_anomaly": is_anomaly,
                "anomaly_type": "temperature_excursion" if is_anomaly else None,
                "timestamp": timestamp.isoformat()
            })
    
    return pd.DataFrame(readings)


def generate_historical_decay_data(products_df: pd.DataFrame, n_records: int = 500) -> pd.DataFrame:
    """Generate historical decay records for model training."""
    records = []
    
    for _ in range(n_records):
        product = products_df.sample(1).iloc[0]
        category = product["category"]
        config = PRODUCT_CONFIGS[category]
        
        # Days since manufacture
        max_days = config["base_shelf_life"]
        days_elapsed = np.random.randint(1, max_days + 3)
        
        # Environmental factors
        opt_temp = (product["optimal_temp_min"] + product["optimal_temp_max"]) / 2
        avg_temp_deviation = np.random.normal(0, 2)
        avg_humidity_deviation = np.random.normal(0, 5)
        
        handling_events = np.random.poisson(1)
        cold_chain_breaks = np.random.poisson(0.3)
        
        # Calculate decay score based on factors
        base_decay = days_elapsed * config["decay_rate"] * 5
        temp_factor = abs(avg_temp_deviation) * 3
        handling_factor = handling_events * 2
        cold_chain_factor = cold_chain_breaks * 12
        
        decay_score = min(100, base_decay + temp_factor + handling_factor + cold_chain_factor)
        decay_score = max(0, decay_score + np.random.normal(0, 5))
        
        # Spoilage determination
        is_spoiled = decay_score > 75 or days_elapsed > max_days
        actual_shelf_life = days_elapsed if is_spoiled else max_days
        
        records.append({
            "product_id": product["product_id"],
            "category": category,
            "days_since_manufacture": days_elapsed,
            "avg_temperature": round(opt_temp + avg_temp_deviation, 2),
            "avg_humidity": round(85 + avg_humidity_deviation, 2),
            "handling_events": handling_events,
            "cold_chain_breaks": cold_chain_breaks,
            "decay_score": round(decay_score, 2),
            "is_spoiled": is_spoiled,
            "actual_shelf_life_days": actual_shelf_life,
            "listed_shelf_life_days": max_days,
            "waste_kg": round(np.random.uniform(0.5, 5), 2) if is_spoiled else 0
        })
    
    return pd.DataFrame(records)


def create_sample_datasets(output_dir: str = "sample_datasets"):
    """Create all sample datasets and save as CSV files."""
    
    os.makedirs(output_dir, exist_ok=True)
    
    print("🔄 Generating synthetic datasets...")
    
    # Generate products
    products_df = generate_products_dataset()
    products_df.to_csv(f"{output_dir}/products.csv", index=False)
    print(f"✅ Generated {len(products_df)} products")
    
    # Generate inventory batches
    inventory_df = generate_inventory_batches(products_df, n_batches=150)
    inventory_df.to_csv(f"{output_dir}/inventory_batches.csv", index=False)
    print(f"✅ Generated {len(inventory_df)} inventory batches")
    
    # Generate sensor readings
    sensor_df = generate_sensor_readings(inventory_df, products_df, hours=168)
    sensor_df.to_csv(f"{output_dir}/sensor_readings.csv", index=False)
    print(f"✅ Generated {len(sensor_df)} sensor readings")
    
    # Generate historical decay data
    history_df = generate_historical_decay_data(products_df, n_records=1000)
    history_df.to_csv(f"{output_dir}/decay_history.csv", index=False)
    print(f"✅ Generated {len(history_df)} historical decay records")
    
    # Create summary JSON
    summary = {
        "generated_at": datetime.now().isoformat(),
        "datasets": {
            "products": {"records": len(products_df), "file": "products.csv"},
            "inventory_batches": {"records": len(inventory_df), "file": "inventory_batches.csv"},
            "sensor_readings": {"records": len(sensor_df), "file": "sensor_readings.csv"},
            "decay_history": {"records": len(history_df), "file": "decay_history.csv"}
        },
        "categories": list(PRODUCT_CONFIGS.keys()),
        "locations": LOCATIONS,
        "suppliers": [{"id": s[0], "name": s[1]} for s in SUPPLIERS]
    }
    
    with open(f"{output_dir}/dataset_summary.json", "w") as f:
        json.dump(summary, f, indent=2)
    
    print(f"\n📁 All datasets saved to: {output_dir}/")
    print(f"📊 Summary saved to: {output_dir}/dataset_summary.json")
    
    return {
        "products": products_df,
        "inventory": inventory_df,
        "sensors": sensor_df,
        "history": history_df
    }


if __name__ == "__main__":
    # Generate datasets when run directly
    datasets = create_sample_datasets()
    
    # Print sample data
    print("\n" + "="*50)
    print("SAMPLE DATA PREVIEW")
    print("="*50)
    
    print("\n📦 Products (first 5):")
    print(datasets["products"][["product_id", "name", "category", "unit_price"]].head())
    
    print("\n📋 Inventory (first 5):")
    print(datasets["inventory"][["batch_id", "product_id", "quantity", "location"]].head())
    
    print("\n🌡️ Sensor Readings (first 5):")
    print(datasets["sensors"][["batch_id", "temperature", "humidity", "timestamp"]].head())

