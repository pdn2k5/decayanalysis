"""
Dynamic Price Optimization Service.
Balances revenue maximization with waste reduction.
"""

import numpy as np
from typing import Dict, List, Optional, Tuple
from scipy.optimize import minimize_scalar
from dataclasses import dataclass

from config import PRODUCT_CONFIG


@dataclass
class PricingContext:
    """Context for pricing decision."""
    product_id: str
    batch_id: str
    product_name: str
    category: str
    current_price: float
    cost: float
    decay_score: float
    days_remaining: float
    current_inventory: int
    avg_daily_demand: float = 5.0


class PriceOptimizer:
    """
    Dynamic pricing optimizer using expected revenue maximization
    with waste penalty and demand elasticity modeling.
    """
    
    def __init__(
        self,
        min_margin: float = 0.05,
        max_markdown: float = 0.70,
        waste_penalty: float = 1.5
    ):
        """
        Initialize price optimizer.
        
        Args:
            min_margin: Minimum profit margin (default 5%)
            max_markdown: Maximum markdown percentage (default 70%)
            waste_penalty: Penalty multiplier for potential waste
        """
        self.min_margin = min_margin
        self.max_markdown = max_markdown
        self.waste_penalty = waste_penalty
        
        # Price elasticity by category (negative values)
        # More negative = more price sensitive
        self.elasticity = {
            "Dairy": -1.8,
            "Fruits": -2.2,
            "Vegetables": -2.0,
            "Meat": -1.5
        }
        
        # Urgency multipliers
        self.urgency_multipliers = {
            "critical": 1.5,
            "high": 1.2,
            "medium": 1.0,
            "low": 0.8
        }
    
    def optimize(self, context: PricingContext) -> Dict:
        """
        Calculate optimal markdown based on decay prediction and inventory.
        
        Args:
            context: PricingContext with product and inventory details
            
        Returns:
            Dictionary with pricing recommendation
        """
        
        elasticity = self.elasticity.get(context.category, -1.5)
        
        # Calculate spoilage probability
        spoilage_prob = self._calculate_spoilage_probability(
            context.decay_score,
            context.days_remaining
        )
        
        # Determine urgency
        urgency = self._determine_urgency(context.decay_score, context.days_remaining)
        
        # Find optimal markdown
        optimal_markdown = self._optimize_markdown(
            context, elasticity, spoilage_prob, urgency
        )
        
        # Calculate expected outcomes
        optimal_price = context.current_price * (1 - optimal_markdown)
        
        # Demand at new price
        demand_multiplier = (1 - optimal_markdown) ** elasticity
        expected_daily_demand = context.avg_daily_demand * demand_multiplier
        expected_sold = min(
            expected_daily_demand * context.days_remaining,
            context.current_inventory
        )
        
        # Revenue and savings
        expected_revenue = expected_sold * optimal_price
        expected_waste = max(0, context.current_inventory - expected_sold) * spoilage_prob
        waste_prevented = context.current_inventory * spoilage_prob - expected_waste
        waste_prevented_value = waste_prevented * context.cost * self.waste_penalty
        
        # Calculate break-even comparison
        no_markdown_sold = min(
            context.avg_daily_demand * context.days_remaining,
            context.current_inventory
        )
        no_markdown_revenue = no_markdown_sold * context.current_price
        no_markdown_waste = (context.current_inventory - no_markdown_sold) * spoilage_prob * context.cost
        
        revenue_impact = expected_revenue - no_markdown_revenue
        net_benefit = revenue_impact + waste_prevented_value
        
        return {
            "product_id": context.product_id,
            "batch_id": context.batch_id,
            "product_name": context.product_name,
            "category": context.category,
            
            # Pricing recommendation
            "original_price": context.current_price,
            "recommended_markdown_pct": round(optimal_markdown * 100, 1),
            "recommended_price": round(optimal_price, 2),
            "minimum_price": round(context.cost * (1 + self.min_margin), 2),
            
            # Expected outcomes
            "expected_units_sold": round(expected_sold, 1),
            "expected_revenue": round(expected_revenue, 2),
            "expected_waste_units": round(expected_waste, 1),
            "waste_prevented_kg": round(waste_prevented, 2),
            "waste_prevented_value": round(waste_prevented_value, 2),
            
            # Comparison to no action
            "revenue_vs_no_action": round(revenue_impact, 2),
            "net_benefit": round(net_benefit, 2),
            
            # Risk metrics
            "spoilage_probability": round(spoilage_prob * 100, 1),
            "urgency_level": urgency,
            "action_timing": self._get_action_timing(urgency, context.days_remaining),
            
            # Reasoning
            "markdown_reason": self._generate_reason(context, optimal_markdown, urgency),
            
            # Elasticity used
            "price_elasticity": elasticity
        }
    
    def _calculate_spoilage_probability(
        self,
        decay_score: float,
        days_remaining: float
    ) -> float:
        """Calculate probability of spoilage before sale."""
        
        # Logistic function based on decay score
        base_prob = 1 / (1 + np.exp(-(decay_score - 50) / 15))
        
        # Time factor - higher urgency with less time
        time_factor = np.exp(-days_remaining / 3)
        
        # Combined probability
        prob = base_prob * (1 + time_factor) / 2
        
        return min(0.99, max(0.01, prob))
    
    def _determine_urgency(self, decay_score: float, days_remaining: float) -> str:
        """Determine urgency level."""
        
        if decay_score > 80 or days_remaining < 1:
            return "critical"
        elif decay_score > 60 or days_remaining < 2:
            return "high"
        elif decay_score > 40 or days_remaining < 4:
            return "medium"
        else:
            return "low"
    
    def _optimize_markdown(
        self,
        context: PricingContext,
        elasticity: float,
        spoilage_prob: float,
        urgency: str
    ) -> float:
        """Find optimal markdown percentage."""
        
        urgency_mult = self.urgency_multipliers.get(urgency, 1.0)
        
        def negative_expected_value(markdown_pct):
            """Objective function to minimize (negative expected value)."""
            
            if markdown_pct < 0 or markdown_pct > self.max_markdown:
                return float('inf')
            
            new_price = context.current_price * (1 - markdown_pct)
            
            # Check minimum margin
            if new_price < context.cost * (1 + self.min_margin):
                return float('inf')
            
            # Demand change due to price
            demand_mult = (1 - markdown_pct) ** elasticity
            expected_demand = context.avg_daily_demand * demand_mult * context.days_remaining
            
            # Units sold (capped by inventory)
            sold = min(expected_demand, context.current_inventory)
            
            # Revenue
            revenue = sold * new_price
            
            # Expected waste cost
            unsold = max(0, context.current_inventory - sold)
            waste_cost = unsold * spoilage_prob * context.cost * self.waste_penalty
            
            # Net value (apply urgency multiplier to waste)
            net_value = revenue - waste_cost * urgency_mult
            
            return -net_value  # Negative for minimization
        
        # Optimize
        result = minimize_scalar(
            negative_expected_value,
            bounds=(0, self.max_markdown),
            method='bounded'
        )
        
        return result.x if result.success else 0.0
    
    def _get_action_timing(self, urgency: str, days_remaining: float) -> str:
        """Get recommended action timing."""
        
        if urgency == "critical" or days_remaining < 1:
            return "IMMEDIATE"
        elif urgency == "high" or days_remaining < 2:
            return "TODAY"
        elif days_remaining < 3:
            return "WITHIN_24H"
        else:
            return "SCHEDULED"
    
    def _generate_reason(
        self,
        context: PricingContext,
        markdown: float,
        urgency: str
    ) -> str:
        """Generate human-readable markdown reason."""
        
        if urgency == "critical":
            return f"Critical: {context.product_name} has high decay ({context.decay_score:.0f}%) with only {context.days_remaining:.1f} days remaining. Immediate markdown of {markdown*100:.0f}% recommended to prevent total loss."
        
        elif urgency == "high":
            return f"High priority: {context.product_name} approaching spoilage threshold. {markdown*100:.0f}% markdown recommended to accelerate sales."
        
        elif markdown > 0.1:
            return f"Proactive markdown of {markdown*100:.0f}% for {context.product_name} to optimize sell-through rate and minimize waste."
        
        elif markdown > 0:
            return f"Minor adjustment of {markdown*100:.0f}% suggested for {context.product_name} based on current decay trajectory."
        
        else:
            return f"{context.product_name} in good condition. No markdown necessary at this time."
    
    def batch_optimize(self, contexts: List[PricingContext]) -> Dict:
        """
        Optimize prices for multiple products.
        
        Returns summary and individual recommendations.
        """
        
        recommendations = []
        total_revenue = 0
        total_waste_prevented = 0
        total_net_benefit = 0
        
        urgency_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        
        for context in contexts:
            rec = self.optimize(context)
            recommendations.append(rec)
            
            total_revenue += rec["expected_revenue"]
            total_waste_prevented += rec["waste_prevented_value"]
            total_net_benefit += rec["net_benefit"]
            urgency_counts[rec["urgency_level"]] += 1
        
        # Sort by urgency
        recommendations.sort(
            key=lambda x: (
                {"critical": 0, "high": 1, "medium": 2, "low": 3}[x["urgency_level"]],
                -x["decay_score"] if "decay_score" in x else 0
            )
        )
        
        return {
            "summary": {
                "total_products": len(recommendations),
                "total_expected_revenue": round(total_revenue, 2),
                "total_waste_prevented_value": round(total_waste_prevented, 2),
                "total_net_benefit": round(total_net_benefit, 2),
                "urgency_breakdown": urgency_counts,
                "immediate_action_required": urgency_counts["critical"],
                "action_today": urgency_counts["critical"] + urgency_counts["high"]
            },
            "recommendations": recommendations
        }


# Singleton instance
_optimizer_instance = None

def get_price_optimizer() -> PriceOptimizer:
    """Get price optimizer singleton."""
    global _optimizer_instance
    if _optimizer_instance is None:
        _optimizer_instance = PriceOptimizer()
    return _optimizer_instance

