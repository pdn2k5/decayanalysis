"""
Voice Synthesis Service for Decay Optimization Platform.
Provides text-to-speech capabilities for alerts and notifications.
Supports Windows native TTS (pyttsx3) and Google TTS (gTTS).
"""

import os
import tempfile
import base64
from typing import Optional, Dict
from pathlib import Path
import logging
import threading
import queue
from datetime import datetime

from config import get_settings

logger = logging.getLogger(__name__)


class VoiceService:
    """
    Text-to-Speech service with support for:
    - pyttsx3 (offline, Windows native SAPI5)
    - gTTS (online, Google Text-to-Speech)
    
    Features:
    - Generate audio from text
    - Queue-based playback
    - Priority alerts
    - Audio file generation for web playback
    """
    
    def __init__(self):
        self.settings = get_settings()
        self.engine = self.settings.voice_engine
        self.enabled = self.settings.voice_enabled
        
        self.audio_queue = queue.PriorityQueue()
        self.is_speaking = False
        
        # Initialize TTS engine
        self._init_engine()
        
        # Audio output directory
        self.audio_dir = Path("static/audio")
        self.audio_dir.mkdir(parents=True, exist_ok=True)
    
    def _init_engine(self):
        """Initialize the TTS engine."""
        if not self.enabled:
            logger.info("Voice service disabled")
            return
        
        if self.engine == "pyttsx3":
            self._init_pyttsx3()
        else:
            logger.info("Using gTTS for voice synthesis")
    
    def _init_pyttsx3(self):
        """Initialize pyttsx3 engine."""
        try:
            import pyttsx3
            self.tts_engine = pyttsx3.init()
            
            # Configure voice properties
            self.tts_engine.setProperty('rate', 175)  # Speed
            self.tts_engine.setProperty('volume', 0.9)  # Volume
            
            # Try to set a good voice (Windows has multiple)
            voices = self.tts_engine.getProperty('voices')
            for voice in voices:
                if 'david' in voice.name.lower() or 'zira' in voice.name.lower():
                    self.tts_engine.setProperty('voice', voice.id)
                    break
            
            logger.info("pyttsx3 engine initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize pyttsx3: {e}")
            self.enabled = False
    
    def speak(self, text: str, priority: int = 5) -> bool:
        """
        Speak text using configured TTS engine.
        
        Args:
            text: Text to speak
            priority: Priority level (1=highest, 10=lowest)
            
        Returns:
            True if successful
        """
        if not self.enabled:
            return False
        
        try:
            if self.engine == "pyttsx3":
                return self._speak_pyttsx3(text)
            else:
                # For gTTS, generate file and return path
                return self._speak_gtts(text)
        except Exception as e:
            logger.error(f"Speech error: {e}")
            return False
    
    def _speak_pyttsx3(self, text: str) -> bool:
        """Speak using pyttsx3 (blocking)."""
        try:
            self.is_speaking = True
            self.tts_engine.say(text)
            self.tts_engine.runAndWait()
            self.is_speaking = False
            return True
        except Exception as e:
            logger.error(f"pyttsx3 error: {e}")
            self.is_speaking = False
            return False
    
    def _speak_gtts(self, text: str) -> bool:
        """Speak using gTTS (generates file)."""
        try:
            from gtts import gTTS
            import pygame
            
            # Generate audio
            tts = gTTS(text=text, lang='en', slow=False)
            
            # Save to temp file
            with tempfile.NamedTemporaryFile(delete=False, suffix='.mp3') as f:
                tts.save(f.name)
                
                # Play using pygame
                pygame.mixer.init()
                pygame.mixer.music.load(f.name)
                pygame.mixer.music.play()
                
                while pygame.mixer.music.get_busy():
                    pass
                
                pygame.mixer.quit()
                os.unlink(f.name)
            
            return True
        except Exception as e:
            logger.error(f"gTTS error: {e}")
            return False
    
    def generate_audio_file(self, text: str, filename: Optional[str] = None) -> Optional[str]:
        """
        Generate audio file from text for web playback.
        
        Args:
            text: Text to convert to speech
            filename: Optional filename (without extension)
            
        Returns:
            Path to generated audio file or None
        """
        if not filename:
            filename = f"alert_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        output_path = self.audio_dir / f"{filename}.mp3"
        
        try:
            if self.engine == "pyttsx3":
                return self._generate_pyttsx3(text, output_path)
            else:
                return self._generate_gtts(text, output_path)
        except Exception as e:
            logger.error(f"Audio generation error: {e}")
            return None
    
    def _generate_pyttsx3(self, text: str, output_path: Path) -> Optional[str]:
        """Generate audio file using pyttsx3."""
        try:
            self.tts_engine.save_to_file(text, str(output_path))
            self.tts_engine.runAndWait()
            return str(output_path)
        except Exception as e:
            logger.error(f"pyttsx3 file generation error: {e}")
            return None
    
    def _generate_gtts(self, text: str, output_path: Path) -> Optional[str]:
        """Generate audio file using gTTS."""
        try:
            from gtts import gTTS
            tts = gTTS(text=text, lang='en', slow=False)
            tts.save(str(output_path))
            return str(output_path)
        except Exception as e:
            logger.error(f"gTTS file generation error: {e}")
            return None
    
    def generate_audio_base64(self, text: str) -> Optional[str]:
        """
        Generate audio and return as base64 string for web embedding.
        
        Args:
            text: Text to convert
            
        Returns:
            Base64 encoded audio string or None
        """
        try:
            # Generate temp file
            with tempfile.NamedTemporaryFile(delete=False, suffix='.mp3') as f:
                temp_path = f.name
            
            if self.engine == "gtts":
                from gtts import gTTS
                tts = gTTS(text=text, lang='en', slow=False)
                tts.save(temp_path)
            else:
                self.tts_engine.save_to_file(text, temp_path)
                self.tts_engine.runAndWait()
            
            # Read and encode
            with open(temp_path, 'rb') as f:
                audio_data = f.read()
            
            os.unlink(temp_path)
            
            return base64.b64encode(audio_data).decode('utf-8')
            
        except Exception as e:
            logger.error(f"Base64 audio generation error: {e}")
            return None
    
    # ================== ALERT-SPECIFIC METHODS ==================
    
    def speak_alert(self, alert: Dict) -> Optional[str]:
        """
        Generate voice alert from alert data.
        
        Args:
            alert: Alert dictionary with severity, title, message
            
        Returns:
            Path to audio file or None
        """
        severity = alert.get('severity', 'INFO')
        title = alert.get('title', 'Alert')
        message = alert.get('message', '')
        product = alert.get('product_name', 'Unknown product')
        location = alert.get('location', '')
        
        # Construct voice message based on severity
        if severity == 'CRITICAL':
            voice_text = f"Critical Alert! {title}. {product} at {location}. {message}. Immediate action required."
        elif severity == 'HIGH':
            voice_text = f"High Priority Alert. {title}. {product}. {message}"
        else:
            voice_text = f"Attention. {title}. {message}"
        
        # Generate audio file
        filename = f"alert_{alert.get('alert_id', 'unknown')}"
        return self.generate_audio_file(voice_text, filename)
    
    def speak_daily_summary(self, summary: Dict) -> Optional[str]:
        """Generate voice summary of daily metrics."""
        
        critical = summary.get('critical_count', 0)
        at_risk = summary.get('at_risk_count', 0)
        waste_value = summary.get('waste_value', 0)
        
        text = f"Good morning. Here's your daily inventory summary. "
        
        if critical > 0:
            text += f"You have {critical} critical items requiring immediate attention. "
        
        if at_risk > 0:
            text += f"{at_risk} items are at risk and should be reviewed today. "
        
        if waste_value > 0:
            text += f"Estimated waste prevention opportunity: ${waste_value:.0f}. "
        
        text += "Please check the dashboard for details."
        
        return self.generate_audio_file(text, "daily_summary")
    
    def speak_markdown_recommendation(self, recommendation: Dict) -> Optional[str]:
        """Generate voice for markdown recommendation."""
        
        product = recommendation.get('product_name', 'Product')
        markdown = recommendation.get('recommended_markdown_pct', 0)
        urgency = recommendation.get('urgency_level', 'medium')
        revenue = recommendation.get('expected_revenue', 0)
        
        if urgency == 'critical':
            text = f"Urgent markdown recommendation for {product}. "
            text += f"Recommend {markdown:.0f}% discount immediately. "
        elif urgency == 'high':
            text = f"High priority. {product} should be marked down {markdown:.0f}% today. "
        else:
            text = f"Consider {markdown:.0f}% markdown for {product}. "
        
        text += f"Expected revenue: ${revenue:.0f}."
        
        return self.generate_audio_file(text, f"markdown_{recommendation.get('batch_id', 'rec')}")
    
    def get_available_voices(self) -> list:
        """Get list of available voices (pyttsx3 only)."""
        if self.engine != "pyttsx3" or not self.enabled:
            return []
        
        try:
            voices = self.tts_engine.getProperty('voices')
            return [{"id": v.id, "name": v.name} for v in voices]
        except:
            return []
    
    def set_voice(self, voice_id: str):
        """Set voice by ID (pyttsx3 only)."""
        if self.engine == "pyttsx3" and self.enabled:
            try:
                self.tts_engine.setProperty('voice', voice_id)
            except Exception as e:
                logger.error(f"Failed to set voice: {e}")
    
    def set_rate(self, rate: int):
        """Set speech rate (words per minute)."""
        if self.engine == "pyttsx3" and self.enabled:
            try:
                self.tts_engine.setProperty('rate', rate)
            except Exception as e:
                logger.error(f"Failed to set rate: {e}")


# Singleton instance
_voice_instance = None

def get_voice_service() -> VoiceService:
    """Get voice service singleton."""
    global _voice_instance
    if _voice_instance is None:
        _voice_instance = VoiceService()
    return _voice_instance

