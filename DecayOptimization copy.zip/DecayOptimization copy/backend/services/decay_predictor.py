"""
Decay Prediction Service using ML models.
Supports Dairy, Fruits, Vegetables, and Meat categories.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
import joblib
import os
from pathlib import Path

from config import PRODUCT_CONFIG, ALERT_THRESHOLDS


class DecayPredictor:
    """
    ML-based decay prediction for perishable goods.
    Uses ensemble of gradient boosting models per category.
    """
    
    def __init__(self, model_dir: str = "ml_models/saved"):
        self.model_dir = Path(model_dir)
        self.models = {}
        self.scalers = {}
        self.is_trained = False
        
        # Feature weights for rule-based fallback
        self.feature_weights = {
            'time_factor': 5.0,
            'temp_deviation': 3.5,
            'humidity_deviation': 1.5,
            'handling_events': 2.5,
            'cold_chain_breaks': 12.0
        }
        
        # Try to load pre-trained models
        self._load_models()
    
    def _load_models(self):
        """Load pre-trained models if available."""
        try:
            for category in PRODUCT_CONFIG.keys():
                model_path = self.model_dir / f"decay_model_{category.lower()}.joblib"
                if model_path.exists():
                    self.models[category] = joblib.load(model_path)
                    self.is_trained = True
        except Exception as e:
            print(f"Note: Pre-trained models not found, using rule-based prediction: {e}")
    
    def predict(
        self,
        category: str,
        days_since_manufacture: float,
        avg_temperature: float,
        avg_humidity: float,
        handling_events: int = 0,
        cold_chain_breaks: int = 0,
        initial_quality: float = 100.0
    ) -> Dict:
        """
        Predict decay score and quality metrics.
        
        Args:
            category: Product category (Dairy, Fruits, Vegetables, Meat)
            days_since_manufacture: Days since product was manufactured
            avg_temperature: Average storage temperature (°C)
            avg_humidity: Average storage humidity (%)
            handling_events: Number of handling events
            cold_chain_breaks: Number of cold chain interruptions
            initial_quality: Initial quality score (0-100)
            
        Returns:
            Dictionary with decay_score, quality_grade, days_remaining, etc.
        """
        
        config = PRODUCT_CONFIG.get(category, PRODUCT_CONFIG["Dairy"])
        
        # Calculate optimal deviations
        optimal_temp = (config["optimal_temp"][0] + config["optimal_temp"][1]) / 2
        optimal_humidity = (config["optimal_humidity"][0] + config["optimal_humidity"][1]) / 2
        
        temp_deviation = abs(avg_temperature - optimal_temp)
        humidity_deviation = abs(avg_humidity - optimal_humidity)
        
        # Check if within optimal range
        temp_in_range = config["optimal_temp"][0] <= avg_temperature <= config["optimal_temp"][1]
        humidity_in_range = config["optimal_humidity"][0] <= avg_humidity <= config["optimal_humidity"][1]
        
        if self.is_trained and category in self.models:
            # Use ML model
            decay_score = self._ml_predict(
                category, days_since_manufacture, temp_deviation, 
                humidity_deviation, handling_events, cold_chain_breaks
            )
        else:
            # Use rule-based prediction
            decay_score = self._rule_based_predict(
                category, days_since_manufacture, temp_deviation,
                humidity_deviation, handling_events, cold_chain_breaks,
                config["decay_rate"]
            )
        
        # Adjust for initial quality
        quality_factor = initial_quality / 100.0
        decay_score = decay_score / quality_factor
        decay_score = np.clip(decay_score, 0, 100)
        
        # Calculate quality grade
        quality_grade = self._calculate_grade(decay_score)
        
        # Estimate days remaining
        days_remaining = self._estimate_days_remaining(
            decay_score, config["base_shelf_life_days"], days_since_manufacture
        )
        
        # Determine recommended action
        action, urgency = self._get_recommendation(decay_score, days_remaining)
        
        return {
            "decay_score": round(decay_score, 2),
            "quality_grade": quality_grade,
            "days_remaining": round(days_remaining, 1),
            "confidence_lower": round(max(0, days_remaining - 1.2), 1),
            "confidence_upper": round(days_remaining + 1.5, 1),
            "recommended_action": action,
            "action_urgency": urgency,
            "temp_deviation": round(temp_deviation, 2),
            "temp_in_optimal_range": temp_in_range,
            "humidity_deviation": round(humidity_deviation, 2),
            "humidity_in_optimal_range": humidity_in_range,
            "input_features": {
                "category": category,
                "days_since_manufacture": days_since_manufacture,
                "avg_temperature": avg_temperature,
                "avg_humidity": avg_humidity,
                "handling_events": handling_events,
                "cold_chain_breaks": cold_chain_breaks
            }
        }
    
    def _rule_based_predict(
        self,
        category: str,
        days: float,
        temp_dev: float,
        humidity_dev: float,
        handling: int,
        cold_breaks: int,
        decay_rate: float
    ) -> float:
        """Rule-based decay prediction."""
        
        # Base decay from time
        base_decay = days * self.feature_weights['time_factor'] * decay_rate
        
        # Environmental factors
        temp_factor = temp_dev * self.feature_weights['temp_deviation']
        humidity_factor = humidity_dev * self.feature_weights['humidity_deviation'] * 0.1
        
        # Handling factors
        handling_factor = handling * self.feature_weights['handling_events']
        cold_chain_factor = cold_breaks * self.feature_weights['cold_chain_breaks']
        
        # Total decay
        decay_score = base_decay + temp_factor + humidity_factor + handling_factor + cold_chain_factor
        
        # Add some variance
        decay_score += np.random.normal(0, 2)
        
        return decay_score
    
    def _ml_predict(
        self,
        category: str,
        days: float,
        temp_dev: float,
        humidity_dev: float,
        handling: int,
        cold_breaks: int
    ) -> float:
        """ML model-based prediction."""
        
        features = np.array([[days, temp_dev, humidity_dev, handling, cold_breaks]])
        prediction = self.models[category].predict(features)[0]
        return prediction
    
    def _calculate_grade(self, decay_score: float) -> str:
        """Calculate quality grade from decay score."""
        if decay_score < 25:
            return "A"
        elif decay_score < 50:
            return "B"
        elif decay_score < 75:
            return "C"
        else:
            return "D"
    
    def _estimate_days_remaining(
        self,
        decay_score: float,
        base_shelf_life: int,
        days_elapsed: float
    ) -> float:
        """Estimate remaining shelf life."""
        
        # Remaining factor based on decay
        remaining_factor = 1 - (decay_score / 100)
        
        # Theoretical remaining
        theoretical_remaining = base_shelf_life * remaining_factor
        
        # Actual remaining (cannot be more than shelf life - elapsed)
        max_remaining = max(0, base_shelf_life - days_elapsed)
        
        # Use minimum of theoretical and max
        days_remaining = min(theoretical_remaining, max_remaining)
        
        return max(0, days_remaining)
    
    def _get_recommendation(self, decay_score: float, days_remaining: float) -> Tuple[str, str]:
        """Get recommended action and urgency level."""
        
        if decay_score > ALERT_THRESHOLDS["critical_decay_score"] or days_remaining < ALERT_THRESHOLDS["critical_days_remaining"]:
            return "MARKDOWN_IMMEDIATELY", "critical"
        elif decay_score > ALERT_THRESHOLDS["high_decay_score"] or days_remaining < ALERT_THRESHOLDS["warning_days_remaining"]:
            return "SCHEDULE_MARKDOWN", "high"
        elif decay_score > ALERT_THRESHOLDS["medium_decay_score"]:
            return "MONITOR_CLOSELY", "medium"
        else:
            return "NO_ACTION_REQUIRED", "low"
    
    def predict_batch(self, batch_data: List[Dict]) -> List[Dict]:
        """Predict decay for multiple items."""
        results = []
        for item in batch_data:
            prediction = self.predict(**item)
            prediction["batch_id"] = item.get("batch_id")
            prediction["product_id"] = item.get("product_id")
            results.append(prediction)
        return results
    
    def train(self, training_data: pd.DataFrame):
        """Train models on historical data."""
        from sklearn.ensemble import GradientBoostingRegressor
        from sklearn.model_selection import train_test_split
        from sklearn.preprocessing import StandardScaler
        
        os.makedirs(self.model_dir, exist_ok=True)
        
        for category in PRODUCT_CONFIG.keys():
            cat_data = training_data[training_data["category"] == category]
            
            if len(cat_data) < 50:
                print(f"Insufficient data for {category}, skipping training")
                continue
            
            # Prepare features
            features = ["days_since_manufacture", "avg_temperature", "avg_humidity", 
                       "handling_events", "cold_chain_breaks"]
            
            # Calculate deviations
            config = PRODUCT_CONFIG[category]
            opt_temp = (config["optimal_temp"][0] + config["optimal_temp"][1]) / 2
            opt_humidity = (config["optimal_humidity"][0] + config["optimal_humidity"][1]) / 2
            
            X = cat_data[features].copy()
            X["temp_deviation"] = abs(X["avg_temperature"] - opt_temp)
            X["humidity_deviation"] = abs(X["avg_humidity"] - opt_humidity)
            X = X.drop(columns=["avg_temperature", "avg_humidity"])
            
            y = cat_data["decay_score"]
            
            # Train model
            model = GradientBoostingRegressor(
                n_estimators=100,
                max_depth=5,
                learning_rate=0.1,
                random_state=42
            )
            model.fit(X, y)
            
            # Save model
            model_path = self.model_dir / f"decay_model_{category.lower()}.joblib"
            joblib.dump(model, model_path)
            self.models[category] = model
            
            print(f"✅ Trained model for {category}")
        
        self.is_trained = True
        print("✅ All models trained successfully")


# Singleton instance
_predictor_instance = None

def get_decay_predictor() -> DecayPredictor:
    """Get decay predictor singleton."""
    global _predictor_instance
    if _predictor_instance is None:
        _predictor_instance = DecayPredictor()
    return _predictor_instance

