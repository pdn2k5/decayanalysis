"""
LLM Service for Decay Optimization Platform.
Supports both local Ollama and external API endpoints.
"""

import httpx
import json
from typing import Dict, Optional, Any
from functools import lru_cache
import logging

from config import get_settings

logger = logging.getLogger(__name__)


class LLMService:
    """
    Unified LLM service supporting multiple providers:
    - Ollama (local deployment)
    - External API (OpenAI-compatible endpoints like Azure, TCS GenAI Lab)
    """
    
    def __init__(self):
        self.settings = get_settings()
        self.provider = self.settings.llm_provider
        
        # HTTP client configuration
        self.http_client = httpx.Client(
            verify=self.settings.ssl_verify,
            timeout=60.0
        )
        
        # Initialize based on provider
        if self.provider == "ollama":
            self._init_ollama()
        else:
            self._init_api()
    
    def _init_ollama(self):
        """Initialize Ollama connection."""
        self.base_url = self.settings.ollama_base_url
        self.model = self.settings.ollama_model
        logger.info(f"LLM Service initialized with Ollama: {self.model}")
    
    def _init_api(self):
        """Initialize external API connection."""
        try:
            from langchain_openai import ChatOpenAI
            
            self.llm = ChatOpenAI(
                base_url=self.settings.llm_api_base_url,
                model=self.settings.llm_api_model,
                api_key=self.settings.llm_api_key,
                http_client=self.http_client
            )
            logger.info(f"LLM Service initialized with API: {self.settings.llm_api_model}")
        except Exception as e:
            logger.error(f"Failed to initialize API LLM: {e}")
            raise
    
    def generate(self, prompt: str, max_tokens: int = 500, temperature: float = 0.7) -> str:
        """
        Generate text using the configured LLM provider.
        
        Args:
            prompt: The input prompt
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            
        Returns:
            Generated text response
        """
        try:
            if self.provider == "ollama":
                return self._generate_ollama(prompt, max_tokens, temperature)
            else:
                return self._generate_api(prompt, max_tokens, temperature)
        except Exception as e:
            logger.error(f"LLM generation error: {e}")
            return f"Error generating response: {str(e)}"
    
    def _generate_ollama(self, prompt: str, max_tokens: int, temperature: float) -> str:
        """Generate using Ollama."""
        try:
            response = self.http_client.post(
                f"{self.base_url}/api/generate",
                json={
                    "model": self.model,
                    "prompt": prompt,
                    "stream": False,
                    "options": {
                        "temperature": temperature,
                        "num_predict": max_tokens
                    }
                }
            )
            response.raise_for_status()
            return response.json().get("response", "")
        except httpx.ConnectError:
            logger.warning("Ollama not available, returning fallback response")
            return self._fallback_response(prompt)
        except Exception as e:
            logger.error(f"Ollama error: {e}")
            return self._fallback_response(prompt)
    
    def _generate_api(self, prompt: str, max_tokens: int, temperature: float) -> str:
        """Generate using external API (LangChain)."""
        try:
            response = self.llm.invoke(prompt)
            return response.content
        except Exception as e:
            logger.error(f"API LLM error: {e}")
            return self._fallback_response(prompt)
    
    def _fallback_response(self, prompt: str) -> str:
        """Provide rule-based fallback when LLM is unavailable."""
        if "explanation" in prompt.lower() or "explain" in prompt.lower():
            return "Analysis based on current sensor data and decay metrics. Please review the numerical predictions for detailed insights."
        elif "alert" in prompt.lower():
            return "Alert generated based on threshold breach. Immediate attention recommended."
        elif "report" in prompt.lower():
            return "Daily summary report. Please review the dashboard for detailed metrics and trends."
        else:
            return "LLM service temporarily unavailable. Using rule-based response."
    
    async def generate_async(self, prompt: str, max_tokens: int = 500, temperature: float = 0.7) -> str:
        """Async version of generate."""
        # For simplicity, wrapping sync call
        # In production, use async httpx client
        return self.generate(prompt, max_tokens, temperature)
    
    # ================== SPECIALIZED METHODS ==================
    
    def generate_decay_explanation(self, prediction_data: Dict) -> str:
        """Generate human-readable explanation for decay prediction."""
        
        prompt = f"""You are a food safety expert assistant. Based on the following decay prediction data, 
provide a clear, actionable explanation for a store manager.

PREDICTION DATA:
- Product: {prediction_data.get('product_name', 'Unknown')}
- Category: {prediction_data.get('category', 'Unknown')}
- Decay Score: {prediction_data.get('decay_score', 0):.1f}%
- Quality Grade: {prediction_data.get('quality_grade', 'N/A')}
- Days Remaining: {prediction_data.get('days_remaining', 0):.1f}
- Average Temperature: {prediction_data.get('avg_temperature', 'N/A')}°C
- Recommended Action: {prediction_data.get('recommended_action', 'N/A')}

Provide a concise explanation (3-4 sentences) covering:
1. Current product condition
2. Main contributing factors
3. Specific recommended action with urgency"""

        return self.generate(prompt, max_tokens=300)
    
    def generate_smart_alert(self, alert_data: Dict, context: Dict = None) -> str:
        """Generate intelligent, context-aware alert message."""
        
        context_str = json.dumps(context, indent=2, default=str) if context else "No additional context"
        
        prompt = f"""Generate a smart, actionable alert message for a retail inventory manager.

ALERT DATA:
- Type: {alert_data.get('alert_type', 'Unknown')}
- Severity: {alert_data.get('severity', 'Unknown')}
- Product: {alert_data.get('product_name', 'Unknown')}
- Location: {alert_data.get('location', 'Unknown')}
- Current Value: {alert_data.get('current_value', 'N/A')}
- Threshold: {alert_data.get('threshold', 'N/A')}

CONTEXT:
{context_str}

Create a brief alert message (2-3 sentences) that:
1. States the issue clearly
2. Quantifies potential impact if possible
3. Recommends immediate action"""

        return self.generate(prompt, max_tokens=200)
    
    def generate_daily_report(self, summary_data: Dict) -> str:
        """Generate executive daily summary report."""
        
        prompt = f"""Generate a professional daily summary report for the Decay Optimization Platform.

TODAY'S METRICS:
{json.dumps(summary_data, indent=2, default=str)}

Generate a brief executive summary (5-6 sentences) including:
1. Overall inventory health status
2. Key highlights (positive and concerning)
3. Financial impact summary
4. Top priority actions for tomorrow

Keep the tone professional and actionable."""

        return self.generate(prompt, max_tokens=400)
    
    def answer_query(self, query: str, context: Dict) -> str:
        """Answer natural language queries about inventory."""
        
        prompt = f"""You are an AI assistant for a perishable goods inventory management system.
Answer the user's question based on the provided inventory context.

USER QUESTION: {query}

INVENTORY CONTEXT:
{json.dumps(context, indent=2, default=str)}

Provide a helpful, accurate, and concise response. If the data doesn't contain 
the answer, say so clearly. Reference specific product IDs or batch numbers when relevant."""

        return self.generate(prompt, max_tokens=400)
    
    def generate_root_cause_analysis(self, incident_data: Dict, history: list = None) -> str:
        """Perform root cause analysis for spoilage incidents."""
        
        history_str = json.dumps(history[:5], indent=2, default=str) if history else "No historical data"
        
        prompt = f"""Analyze the following food spoilage incident and identify root causes.

CURRENT INCIDENT:
{json.dumps(incident_data, indent=2, default=str)}

RECENT SIMILAR INCIDENTS:
{history_str}

Provide a root cause analysis (4-5 sentences) including:
1. Primary cause identification
2. Contributing factors
3. Whether this is a recurring pattern
4. Preventive recommendation"""

        return self.generate(prompt, max_tokens=350)
    
    def is_available(self) -> bool:
        """Check if LLM service is available."""
        try:
            if self.provider == "ollama":
                response = self.http_client.get(f"{self.base_url}/api/tags")
                return response.status_code == 200
            else:
                # Try a simple API call
                self.llm.invoke("test")
                return True
        except:
            return False


@lru_cache()
def get_llm_service() -> LLMService:
    """Get cached LLM service instance."""
    return LLMService()

