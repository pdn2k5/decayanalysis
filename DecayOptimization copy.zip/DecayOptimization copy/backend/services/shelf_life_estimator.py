"""
Shelf Life Estimation Service using Survival Analysis.
Supports Dairy, Fruits, Vegetables, and Meat categories.
"""

import numpy as np
from typing import Dict, Optional
from scipy import stats
from datetime import datetime, timedelta

from config import PRODUCT_CONFIG


class ShelfLifeEstimator:
    """
    Survival analysis-based shelf life estimator using Weibull distribution.
    Provides probabilistic estimates with confidence intervals.
    """
    
    def __init__(self):
        # Weibull parameters by category (shape, scale)
        # These would be fitted from historical data in production
        self.weibull_params = {
            "Dairy": {"shape": 2.5, "scale": 12.0, "loc": 0},
            "Fruits": {"shape": 2.0, "scale": 8.0, "loc": 0},
            "Vegetables": {"shape": 1.8, "scale": 6.0, "loc": 0},
            "Meat": {"shape": 3.0, "scale": 4.5, "loc": 0}
        }
        
        # Adjustment factors
        self.temp_sensitivity = {
            "Dairy": 0.08,
            "Fruits": 0.06,
            "Vegetables": 0.07,
            "Meat": 0.10
        }
    
    def estimate(
        self,
        category: str,
        days_elapsed: float,
        current_decay_score: float,
        temperature_deviation: float = 0,
        handling_stress: int = 0,
        cold_chain_breaks: int = 0
    ) -> Dict:
        """
        Estimate remaining shelf life based on current conditions.
        
        Args:
            category: Product category
            days_elapsed: Days since manufacture
            current_decay_score: Current decay score (0-100)
            temperature_deviation: Deviation from optimal temperature
            handling_stress: Number of handling events
            cold_chain_breaks: Number of cold chain interruptions
            
        Returns:
            Dictionary with estimated days remaining, confidence intervals, etc.
        """
        
        params = self.weibull_params.get(category, self.weibull_params["Dairy"])
        config = PRODUCT_CONFIG.get(category, PRODUCT_CONFIG["Dairy"])
        
        # Base survival probability from decay score
        survival_prob = 1 - (current_decay_score / 100)
        survival_prob = max(0.01, min(0.99, survival_prob))
        
        # Calculate adjustment factors
        temp_factor = 1 - (abs(temperature_deviation) * self.temp_sensitivity.get(category, 0.07))
        handling_factor = 1 - (handling_stress * 0.03)
        cold_chain_factor = 1 - (cold_chain_breaks * 0.15)
        
        # Combined adjustment
        adjustment = max(0.1, temp_factor * handling_factor * cold_chain_factor)
        
        # Estimate remaining days using Weibull survival function
        if survival_prob > 0.01:
            # Inverse survival function to get time
            base_remaining = params["scale"] * ((-np.log(survival_prob)) ** (1 / params["shape"]))
            adjusted_remaining = max(0, (base_remaining - days_elapsed) * adjustment)
        else:
            adjusted_remaining = 0
        
        # Cap at maximum possible shelf life
        max_remaining = max(0, config["base_shelf_life_days"] - days_elapsed)
        estimated_remaining = min(adjusted_remaining, max_remaining)
        
        # Calculate confidence interval
        variance = (params["scale"] ** 2) * self._weibull_variance_factor(params["shape"])
        std_dev = np.sqrt(variance) * adjustment * 0.3  # Scale variance
        
        confidence_lower = max(0, estimated_remaining - 1.96 * std_dev)
        confidence_upper = estimated_remaining + 1.96 * std_dev
        
        # Calculate hazard rate (instantaneous risk of spoilage)
        hazard_rate = self._weibull_hazard(days_elapsed, params["shape"], params["scale"])
        
        # Probability of lasting specific durations
        prob_1_day = self._survival_probability(days_elapsed + 1, params) * adjustment
        prob_3_days = self._survival_probability(days_elapsed + 3, params) * adjustment
        prob_7_days = self._survival_probability(days_elapsed + 7, params) * adjustment
        
        return {
            "estimated_days_remaining": round(estimated_remaining, 1),
            "confidence_lower": round(confidence_lower, 1),
            "confidence_upper": round(confidence_upper, 1),
            "confidence_level": 0.95,
            "survival_probability": round(survival_prob * 100, 2),
            "adjustment_factor": round(adjustment, 3),
            "hazard_rate": round(hazard_rate, 4),
            "probability_lasting": {
                "1_day": round(prob_1_day * 100, 1),
                "3_days": round(prob_3_days * 100, 1),
                "7_days": round(prob_7_days * 100, 1)
            },
            "factors_applied": {
                "temperature_factor": round(temp_factor, 3),
                "handling_factor": round(handling_factor, 3),
                "cold_chain_factor": round(cold_chain_factor, 3)
            },
            "recommendation": self._get_recommendation(estimated_remaining, survival_prob)
        }
    
    def _weibull_variance_factor(self, shape: float) -> float:
        """Calculate Weibull variance factor."""
        gamma1 = np.exp(np.log(2) / shape) if shape > 0 else 1
        gamma2 = np.exp(2 * np.log(2) / shape) if shape > 0 else 1
        return gamma2 - gamma1 ** 2
    
    def _weibull_hazard(self, t: float, shape: float, scale: float) -> float:
        """Calculate Weibull hazard rate at time t."""
        if t <= 0 or scale <= 0:
            return 0
        return (shape / scale) * ((t / scale) ** (shape - 1))
    
    def _survival_probability(self, t: float, params: Dict) -> float:
        """Calculate survival probability at time t."""
        if t <= 0:
            return 1.0
        return np.exp(-((t / params["scale"]) ** params["shape"]))
    
    def _get_recommendation(self, days_remaining: float, survival_prob: float) -> str:
        """Get recommendation based on shelf life estimate."""
        
        if days_remaining < 1 or survival_prob < 0.2:
            return "CRITICAL: Immediate markdown or disposal recommended"
        elif days_remaining < 2 or survival_prob < 0.4:
            return "HIGH PRIORITY: Schedule markdown within 24 hours"
        elif days_remaining < 4 or survival_prob < 0.6:
            return "MONITOR: Consider promotional pricing"
        else:
            return "STABLE: No immediate action required"
    
    def fit_from_history(self, historical_data: list):
        """
        Fit Weibull parameters from historical shelf life data.
        
        Args:
            historical_data: List of dicts with 'category' and 'actual_shelf_life_days'
        """
        import pandas as pd
        
        df = pd.DataFrame(historical_data)
        
        for category in self.weibull_params.keys():
            cat_data = df[df["category"] == category]["actual_shelf_life_days"].dropna()
            
            if len(cat_data) < 30:
                print(f"Insufficient data for {category}, using default parameters")
                continue
            
            try:
                # Fit Weibull distribution
                shape, loc, scale = stats.weibull_min.fit(cat_data, floc=0)
                
                self.weibull_params[category] = {
                    "shape": shape,
                    "scale": scale,
                    "loc": loc
                }
                print(f"✅ Fitted Weibull for {category}: shape={shape:.2f}, scale={scale:.2f}")
            except Exception as e:
                print(f"Failed to fit {category}: {e}")
    
    def get_optimal_sell_by_date(
        self,
        category: str,
        manufacture_date: datetime,
        target_quality: str = "B"
    ) -> datetime:
        """
        Calculate optimal sell-by date to maintain target quality.
        
        Args:
            category: Product category
            manufacture_date: Date of manufacture
            target_quality: Target minimum quality grade (A, B, C, D)
            
        Returns:
            Recommended sell-by datetime
        """
        
        # Quality thresholds (max decay score for grade)
        quality_thresholds = {"A": 25, "B": 50, "C": 75, "D": 100}
        max_decay = quality_thresholds.get(target_quality, 50)
        
        config = PRODUCT_CONFIG.get(category, PRODUCT_CONFIG["Dairy"])
        params = self.weibull_params.get(category, self.weibull_params["Dairy"])
        
        # Estimate days to reach target decay
        # Using inverse relationship: decay_score ≈ 100 * (1 - survival_prob)
        target_survival = 1 - (max_decay / 100)
        
        if target_survival > 0:
            days_to_target = params["scale"] * ((-np.log(target_survival)) ** (1 / params["shape"]))
        else:
            days_to_target = config["base_shelf_life_days"]
        
        # Add safety margin
        days_to_target = days_to_target * 0.85  # 15% safety margin
        
        sell_by_date = manufacture_date + timedelta(days=days_to_target)
        
        return sell_by_date


# Singleton instance
_estimator_instance = None

def get_shelf_life_estimator() -> ShelfLifeEstimator:
    """Get shelf life estimator singleton."""
    global _estimator_instance
    if _estimator_instance is None:
        _estimator_instance = ShelfLifeEstimator()
    return _estimator_instance

