"""
Alert Engine for Decay Optimization Platform.
Generates and manages intelligent alerts with LLM enhancement.
"""

import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum
import logging

from config import ALERT_THRESHOLDS

logger = logging.getLogger(__name__)


class AlertSeverity(Enum):
    CRITICAL = 4
    HIGH = 3
    MEDIUM = 2
    LOW = 1
    INFO = 0


class AlertType(Enum):
    DECAY_THRESHOLD = "decay_threshold"
    SHELF_LIFE_CRITICAL = "shelf_life_critical"
    TEMPERATURE_EXCURSION = "temperature_excursion"
    COLD_CHAIN_BREAK = "cold_chain_break"
    INVENTORY_RISK = "inventory_risk"
    MARKDOWN_OPPORTUNITY = "markdown_opportunity"
    BATCH_EXPIRING = "batch_expiring"


@dataclass
class Alert:
    """Alert data structure."""
    alert_id: str
    alert_type: AlertType
    severity: AlertSeverity
    title: str
    message: str
    batch_id: Optional[str] = None
    product_id: Optional[str] = None
    product_name: Optional[str] = None
    location: Optional[str] = None
    category: Optional[str] = None
    data: Dict = field(default_factory=dict)
    smart_message: Optional[str] = None
    estimated_loss: Optional[float] = None
    timestamp: datetime = field(default_factory=datetime.now)
    is_acknowledged: bool = False
    acknowledged_by: Optional[str] = None
    acknowledged_at: Optional[datetime] = None
    voice_played: bool = False


class AlertRule:
    """Base class for alert rules."""
    
    def __init__(
        self,
        name: str,
        alert_type: AlertType,
        severity: AlertSeverity,
        cooldown_minutes: int = 30
    ):
        self.name = name
        self.alert_type = alert_type
        self.severity = severity
        self.cooldown_minutes = cooldown_minutes
        self.last_triggered: Dict[str, datetime] = {}
    
    def _get_cooldown_key(self, data: Dict) -> str:
        """Generate unique key for cooldown tracking."""
        return f"{data.get('batch_id', 'global')}_{data.get('location', 'unknown')}"
    
    def _check_cooldown(self, key: str) -> bool:
        """Check if alert is in cooldown period."""
        if key not in self.last_triggered:
            return False
        
        elapsed = (datetime.now() - self.last_triggered[key]).total_seconds() / 60
        return elapsed < self.cooldown_minutes
    
    def evaluate(self, data: Dict) -> Optional[Alert]:
        """Evaluate if alert should be triggered. Override in subclass."""
        raise NotImplementedError


class DecayThresholdRule(AlertRule):
    """Alert when decay score exceeds threshold."""
    
    def __init__(self, threshold: float, severity: AlertSeverity):
        super().__init__(
            name=f"decay_threshold_{threshold}",
            alert_type=AlertType.DECAY_THRESHOLD,
            severity=severity,
            cooldown_minutes=60
        )
        self.threshold = threshold
    
    def evaluate(self, data: Dict) -> Optional[Alert]:
        decay_score = data.get('decay_score', 0)
        
        if decay_score < self.threshold:
            return None
        
        key = self._get_cooldown_key(data)
        if self._check_cooldown(key):
            return None
        
        self.last_triggered[key] = datetime.now()
        
        return Alert(
            alert_id=f"DECAY-{uuid.uuid4().hex[:8].upper()}",
            alert_type=self.alert_type,
            severity=self.severity,
            title=f"High Decay Score Alert",
            message=f"{data.get('product_name', 'Product')} has reached decay score of {decay_score:.1f}% (threshold: {self.threshold}%)",
            batch_id=data.get('batch_id'),
            product_id=data.get('product_id'),
            product_name=data.get('product_name'),
            location=data.get('location'),
            category=data.get('category'),
            data={
                'decay_score': decay_score,
                'threshold': self.threshold,
                'days_remaining': data.get('days_remaining'),
                'recommended_action': data.get('recommended_action')
            },
            estimated_loss=data.get('unit_price', 0) * data.get('quantity', 0) * 0.5
        )


class ShelfLifeCriticalRule(AlertRule):
    """Alert when shelf life is critically low."""
    
    def __init__(self, days_threshold: float, severity: AlertSeverity):
        super().__init__(
            name=f"shelf_life_{days_threshold}",
            alert_type=AlertType.SHELF_LIFE_CRITICAL,
            severity=severity,
            cooldown_minutes=120
        )
        self.days_threshold = days_threshold
    
    def evaluate(self, data: Dict) -> Optional[Alert]:
        days_remaining = data.get('days_remaining', float('inf'))
        
        if days_remaining > self.days_threshold:
            return None
        
        key = self._get_cooldown_key(data)
        if self._check_cooldown(key):
            return None
        
        self.last_triggered[key] = datetime.now()
        
        return Alert(
            alert_id=f"SHELF-{uuid.uuid4().hex[:8].upper()}",
            alert_type=self.alert_type,
            severity=self.severity,
            title="Shelf Life Critical",
            message=f"{data.get('product_name', 'Product')} has only {days_remaining:.1f} days of shelf life remaining",
            batch_id=data.get('batch_id'),
            product_id=data.get('product_id'),
            product_name=data.get('product_name'),
            location=data.get('location'),
            category=data.get('category'),
            data={
                'days_remaining': days_remaining,
                'threshold': self.days_threshold,
                'expiry_date': data.get('expiry_date')
            },
            estimated_loss=data.get('unit_price', 0) * data.get('quantity', 0)
        )


class TemperatureExcursionRule(AlertRule):
    """Alert for temperature deviations."""
    
    def __init__(
        self,
        deviation_threshold: float,
        duration_minutes: int,
        severity: AlertSeverity
    ):
        super().__init__(
            name=f"temp_excursion_{deviation_threshold}",
            alert_type=AlertType.TEMPERATURE_EXCURSION,
            severity=severity,
            cooldown_minutes=15
        )
        self.deviation_threshold = deviation_threshold
        self.duration_minutes = duration_minutes
    
    def evaluate(self, data: Dict) -> Optional[Alert]:
        temp_deviation = abs(data.get('temperature_deviation', 0))
        duration = data.get('excursion_duration_minutes', 0)
        
        if temp_deviation < self.deviation_threshold or duration < self.duration_minutes:
            return None
        
        key = self._get_cooldown_key(data)
        if self._check_cooldown(key):
            return None
        
        self.last_triggered[key] = datetime.now()
        
        return Alert(
            alert_id=f"TEMP-{uuid.uuid4().hex[:8].upper()}",
            alert_type=self.alert_type,
            severity=self.severity,
            title="Temperature Excursion Detected",
            message=f"Temperature deviation of {temp_deviation:.1f}°C detected at {data.get('location', 'Unknown')} for {duration} minutes",
            batch_id=data.get('batch_id'),
            location=data.get('location'),
            category=data.get('category'),
            data={
                'current_temperature': data.get('current_temperature'),
                'optimal_temperature': data.get('optimal_temperature'),
                'deviation': temp_deviation,
                'duration_minutes': duration,
                'affected_batches': data.get('affected_batches', [])
            }
        )


class AlertEngine:
    """
    Central alert processing engine.
    Evaluates rules and generates alerts with optional LLM enhancement.
    """
    
    def __init__(self):
        self.rules: List[AlertRule] = []
        self.active_alerts: List[Alert] = []
        self.alert_history: List[Alert] = []
        self.llm_service = None
        
        # Register default rules
        self._register_default_rules()
    
    def _register_default_rules(self):
        """Register standard alert rules based on thresholds."""
        
        # Decay threshold rules
        self.rules.append(DecayThresholdRule(
            threshold=ALERT_THRESHOLDS["critical_decay_score"],
            severity=AlertSeverity.CRITICAL
        ))
        self.rules.append(DecayThresholdRule(
            threshold=ALERT_THRESHOLDS["high_decay_score"],
            severity=AlertSeverity.HIGH
        ))
        self.rules.append(DecayThresholdRule(
            threshold=ALERT_THRESHOLDS["medium_decay_score"],
            severity=AlertSeverity.MEDIUM
        ))
        
        # Shelf life rules
        self.rules.append(ShelfLifeCriticalRule(
            days_threshold=ALERT_THRESHOLDS["critical_days_remaining"],
            severity=AlertSeverity.CRITICAL
        ))
        self.rules.append(ShelfLifeCriticalRule(
            days_threshold=ALERT_THRESHOLDS["warning_days_remaining"],
            severity=AlertSeverity.HIGH
        ))
        
        # Temperature rules
        self.rules.append(TemperatureExcursionRule(
            deviation_threshold=ALERT_THRESHOLDS["temp_deviation_critical"],
            duration_minutes=15,
            severity=AlertSeverity.CRITICAL
        ))
        self.rules.append(TemperatureExcursionRule(
            deviation_threshold=ALERT_THRESHOLDS["temp_deviation_warning"],
            duration_minutes=30,
            severity=AlertSeverity.HIGH
        ))
    
    def set_llm_service(self, llm_service):
        """Set LLM service for smart alert generation."""
        self.llm_service = llm_service
    
    def process(self, data: Dict) -> List[Alert]:
        """
        Process data through all rules and generate alerts.
        
        Args:
            data: Dictionary with prediction/sensor data
            
        Returns:
            List of triggered alerts
        """
        triggered_alerts = []
        
        for rule in self.rules:
            try:
                alert = rule.evaluate(data)
                if alert:
                    # Enhance with LLM if available
                    if self.llm_service:
                        try:
                            alert.smart_message = self.llm_service.generate_smart_alert(
                                alert_data={
                                    "alert_type": alert.alert_type.value,
                                    "severity": alert.severity.name,
                                    "product_name": alert.product_name,
                                    "location": alert.location,
                                    "current_value": data.get('decay_score') or data.get('temperature'),
                                    "threshold": alert.data.get('threshold')
                                },
                                context=data
                            )
                        except Exception as e:
                            logger.warning(f"LLM enhancement failed: {e}")
                    
                    triggered_alerts.append(alert)
                    self.active_alerts.append(alert)
                    self.alert_history.append(alert)
                    
            except Exception as e:
                logger.error(f"Rule evaluation error ({rule.name}): {e}")
        
        return triggered_alerts
    
    def get_active_alerts(
        self,
        severity: Optional[AlertSeverity] = None,
        alert_type: Optional[AlertType] = None,
        location: Optional[str] = None,
        acknowledged: Optional[bool] = None,
        limit: int = 100
    ) -> List[Alert]:
        """Get filtered list of active alerts."""
        
        alerts = self.active_alerts.copy()
        
        if severity:
            alerts = [a for a in alerts if a.severity == severity]
        if alert_type:
            alerts = [a for a in alerts if a.alert_type == alert_type]
        if location:
            alerts = [a for a in alerts if a.location == location]
        if acknowledged is not None:
            alerts = [a for a in alerts if a.is_acknowledged == acknowledged]
        
        # Sort by severity (highest first) then timestamp (newest first)
        alerts.sort(key=lambda a: (-a.severity.value, a.timestamp), reverse=True)
        
        return alerts[:limit]
    
    def acknowledge(self, alert_id: str, user: str) -> bool:
        """Acknowledge an alert."""
        
        for alert in self.active_alerts:
            if alert.alert_id == alert_id:
                alert.is_acknowledged = True
                alert.acknowledged_by = user
                alert.acknowledged_at = datetime.now()
                return True
        return False
    
    def dismiss(self, alert_id: str) -> bool:
        """Dismiss/remove an alert from active list."""
        
        for i, alert in enumerate(self.active_alerts):
            if alert.alert_id == alert_id:
                self.active_alerts.pop(i)
                return True
        return False
    
    def get_summary(self) -> Dict:
        """Get alert summary statistics."""
        
        unacknowledged = [a for a in self.active_alerts if not a.is_acknowledged]
        
        severity_counts = {
            "critical": len([a for a in unacknowledged if a.severity == AlertSeverity.CRITICAL]),
            "high": len([a for a in unacknowledged if a.severity == AlertSeverity.HIGH]),
            "medium": len([a for a in unacknowledged if a.severity == AlertSeverity.MEDIUM]),
            "low": len([a for a in unacknowledged if a.severity == AlertSeverity.LOW])
        }
        
        type_counts = {}
        for alert in unacknowledged:
            type_name = alert.alert_type.value
            type_counts[type_name] = type_counts.get(type_name, 0) + 1
        
        total_estimated_loss = sum(
            a.estimated_loss or 0 for a in unacknowledged
        )
        
        return {
            "total_active": len(self.active_alerts),
            "total_unacknowledged": len(unacknowledged),
            "by_severity": severity_counts,
            "by_type": type_counts,
            "total_estimated_loss": round(total_estimated_loss, 2),
            "requires_immediate_action": severity_counts["critical"]
        }
    
    def clear_old_alerts(self, hours: int = 24):
        """Clear alerts older than specified hours."""
        
        cutoff = datetime.now() - timedelta(hours=hours)
        self.active_alerts = [
            a for a in self.active_alerts
            if a.timestamp > cutoff or not a.is_acknowledged
        ]


# Singleton instance
_engine_instance = None

def get_alert_engine() -> AlertEngine:
    """Get alert engine singleton."""
    global _engine_instance
    if _engine_instance is None:
        _engine_instance = AlertEngine()
    return _engine_instance

