"""
Configuration management for Decay Optimization Platform
Supports both environment variables and .env file
"""

from pydantic_settings import BaseSettings
from typing import Optional
from functools import lru_cache
import os


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""
    
    # Database
    database_url: str = "sqlite:///./decay_optimization.db"
    
    # LLM Configuration
    llm_provider: str = "ollama"  # "ollama" or "api"
    
    # Ollama settings
    ollama_base_url: str = "http://localhost:11434"
    ollama_model: str = "qwen2.5:7b"
    
    # External API settings
    llm_api_base_url: Optional[str] = "https://genailab.tcs.in"
    llm_api_model: Optional[str] = "azure/genailab-maas-gpt-4o-mini"
    llm_api_key: Optional[str] = None
    
    # SSL
    ssl_verify: bool = False
    
    # Voice
    voice_enabled: bool = True
    voice_engine: str = "pyttsx3"  # "pyttsx3" or "gtts"
    
    # Application
    app_host: str = "0.0.0.0"
    app_port: int = 8000
    debug: bool = True
    
    # Product Categories
    product_categories: list = ["Dairy", "Fruits", "Vegetables", "Meat"]
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()


# Product-specific configurations
PRODUCT_CONFIG = {
    "Dairy": {
        "optimal_temp": (2, 4),
        "optimal_humidity": (80, 90),
        "base_shelf_life_days": 14,
        "decay_rate": 0.8,
        "examples": ["Milk", "Yogurt", "Cheese", "Butter", "Cream", "Cottage Cheese"]
    },
    "Fruits": {
        "optimal_temp": (4, 8),
        "optimal_humidity": (85, 95),
        "base_shelf_life_days": 10,
        "decay_rate": 1.0,
        "examples": ["Apples", "Bananas", "Oranges", "Strawberries", "Grapes", "Mangoes"]
    },
    "Vegetables": {
        "optimal_temp": (4, 10),
        "optimal_humidity": (90, 98),
        "base_shelf_life_days": 7,
        "decay_rate": 1.1,
        "examples": ["Lettuce", "Tomatoes", "Carrots", "Spinach", "Broccoli", "Peppers"]
    },
    "Meat": {
        "optimal_temp": (-1, 2),
        "optimal_humidity": (80, 85),
        "base_shelf_life_days": 5,
        "decay_rate": 1.3,
        "examples": ["Chicken", "Beef", "Pork", "Lamb", "Turkey", "Fish"]
    }
}

# Alert thresholds
ALERT_THRESHOLDS = {
    "critical_decay_score": 80,
    "high_decay_score": 60,
    "medium_decay_score": 40,
    "critical_days_remaining": 1,
    "warning_days_remaining": 2,
    "temp_deviation_critical": 5,
    "temp_deviation_warning": 3
}

