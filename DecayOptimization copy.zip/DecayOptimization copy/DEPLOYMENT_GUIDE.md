# Decay Optimization Platform - Deployment Guide

## ✅ Completed Issues

1. **Dashboard now displays data** - Rebuilt backend with in-memory data store that works immediately
2. **Analytics view removed** - Removed from navigation and routing
3. **TCS Brand Theme Applied** - Updated colors, fonts, and styling to match TCS brand guidelines:
   - Primary Color: #6247AA (Purple)
   - Accent Color: #00D9C9 (Teal/Cyan)
   - Dark Background: #020128, #0d0d2b
   - Font: Inter (TCS standard)

4. **Solution remains Windows-compatible** - All changes work on both Mac and Windows

## 🚀 Quick Start

### For macOS

```bash
# Start both servers
./start.sh

# Or individually:
./start_backend.sh  # Backend on port 8000
./start_frontend.sh  # Frontend on port 3000
```

### For Windows

```batch
REM Start both servers
start.bat

REM Or individually:
start_backend.bat  REM Backend on port 8000
start_frontend.bat  REM Frontend on port 3000
```

## 📁 Key Changes

### Backend (`backend/main.py`)
- Simplified architecture with in-memory data storage
- Auto-generates 58 sample batches on startup
- Includes all API endpoints with working responses
- No database dependencies - works immediately

### Frontend
- **Theme** (`frontend/src/index.css`): Updated to TCS brand colors
- **Navigation** (`frontend/src/App.jsx`): Removed Analytics view
- All pages styled with TCS color scheme

## 🎨 TCS Brand Colors

```css
--primary: #6247AA        /* Purple */
--primary-dark: #4a3680
--accent: #00D9C9         /* Teal/Cyan */
--accent-dark: #00b3a6
--bg-dark: #020128        /* Deep navy */
--bg-card: #0d0d2b        /* Card background */
```

Reference: [TCS Brand Guidelines](https://www.tcs.com/who-we-are/tcs-brand)

## 📊 Features

- **Dashboard**: Real-time metrics, decay scores, risk breakdown, charts
- **Inventory**: 58 sample batches across Dairy, Fruits, Vegetables, Meat
- **Alerts**: Auto-generated alerts for high-decay items
- **Markdown**: Dynamic pricing recommendations
- **Cold Chain**: Temperature monitoring
- **Data Upload**: Manual data upload capability
- **AI Assistant**: Natural language queries about inventory
- **Voice**: Text-to-speech summaries

## 🔧 API Endpoints

All endpoints work immediately with sample data:

- `GET /health` - Health check
- `GET /api/v1/analytics/dashboard` - Dashboard metrics
- `GET /api/v1/analytics/trends` - Decay trends
- `GET /api/v1/alerts/` - Active alerts
- `GET /api/v1/inventory/batches` - Inventory batches
- `POST /api/v1/upload/sample-data` - Reload sample data

## 🧪 Testing

1. **Backend**: http://localhost:8000/api/docs
2. **Frontend**: http://localhost:3000
3. **Health Check**: http://localhost:8000/health

```bash
# Test backend API
curl http://localhost:8000/health
curl http://localhost:8000/api/v1/analytics/dashboard
```

## 📦 Dependencies

### Backend
- FastAPI
- Uvicorn
- Pydantic
- No database required!

### Frontend
- React 18
- Vite
- TailwindCSS
- Framer Motion
- Recharts
- Lucide Icons

## 🎯 Product Categories

- Dairy: Milk, Cheese, Yogurt, Butter, Cream
- Fruits: Apples, Bananas, Oranges, Strawberries, Grapes
- Vegetables: Lettuce, Tomatoes, Carrots, Broccoli, Spinach
- Meat: Chicken, Beef, Pork, Fish, Turkey

## 💡 Sample Data

The backend auto-generates:
- 58 batches (2-4 per product)
- 20 alerts (for high-decay items)
- Realistic decay scores (10-85%)
- Shelf life estimates (1-14 days)
- Temperature and humidity readings

## 🔄 Refresh Data

Click "Load Sample Data" button in any view to regenerate fresh sample data.

## 📝 Notes

- No database setup required
- Data resets on server restart
- All APIs return immediate responses
- Windows & macOS compatible
- TCS brand theme applied throughout
- Analytics view removed as requested

