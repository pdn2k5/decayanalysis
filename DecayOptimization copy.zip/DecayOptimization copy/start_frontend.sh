#!/bin/bash

echo "========================================"
echo " DECAY OPTIMIZATION PLATFORM - FRONTEND"
echo "========================================"
echo ""

# Get the directory where the script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR/frontend"

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "ERROR: Node.js is not installed"
    echo "Please install Node.js 18+ using: brew install node"
    exit 1
fi

echo "Node version: $(node --version)"

# Install dependencies if node_modules doesn't exist
if [ ! -d "node_modules" ]; then
    echo "Installing dependencies..."
    npm install
fi

echo ""
echo "Starting React frontend server..."
echo "Frontend URL: http://localhost:3000"
echo ""

npm run dev

