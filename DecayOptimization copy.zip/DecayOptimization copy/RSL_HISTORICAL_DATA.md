# 📊 RSL Calculation & Historical Data Usage

This document explains where and how **historical data** is utilized in the **Remaining Shelf Life (RSL)** calculation algorithm within the Decay Optimization Platform.

---

## 🧮 RSL Calculation Overview

The RSL (Remaining Shelf Life) is calculated using a **multi-factor weighted algorithm** that combines real-time data with historical patterns:

```
RSL = Base_Shelf_Life × Combined_Factor

Combined_Factor = (
    Temperature_Factor × 0.25 +     // 25% weight
    Humidity_Factor × 0.15 +        // 15% weight
    Logistics_Factor × 0.15 +       // 15% weight
    Age_Factor × 0.25 +             // 25% weight
    Supplier_History_Factor × 0.10 +// 10% weight ← HISTORICAL DATA
    Visual_Analysis_Factor × 0.10   // 10% weight
)
```

---

## 📚 Historical Data Components

### 1. **Supplier Historical Performance** (10% Weight)

**Location in Code:** `backend/main.py` - `SUPPLIER_HISTORY` dictionary

```python
SUPPLIER_HISTORY = {
    "Supplier_A": {"avg_decay_rate": 0.95, "reliability_score": 0.98},
    "Supplier_B": {"avg_decay_rate": 1.05, "reliability_score": 0.92},
    "Supplier_C": {"avg_decay_rate": 1.02, "reliability_score": 0.95},
    "Supplier_D": {"avg_decay_rate": 0.98, "reliability_score": 0.97},
    "Default": {"avg_decay_rate": 1.0, "reliability_score": 0.90}
}
```

**How It Works:**
- Each supplier is assigned an **average decay rate** based on historical product quality data
- `avg_decay_rate < 1.0` = Products from this supplier historically decay **slower** (better quality)
- `avg_decay_rate > 1.0` = Products from this supplier historically decay **faster** (lower quality)
- `reliability_score` = Overall supplier reliability (currently used for analytics)

**Impact on RSL:**
- A supplier with `avg_decay_rate = 0.95` increases RSL by 5%
- A supplier with `avg_decay_rate = 1.05` decreases RSL by 5%

**Example:**
```
Product: Amul Milk
Supplier: Supplier_A (avg_decay_rate: 0.95)
Base RSL: 7 days

Supplier contribution to Combined_Factor: 0.95 × 0.10 = 0.095
(Product from reliable supplier gets slight RSL boost)
```

---

### 2. **Base Shelf Life by Product Category** (Historical Reference)

**Location in Code:** `backend/main.py` - `BASE_SHELF_LIFE` dictionary

```python
BASE_SHELF_LIFE = {
    "Dairy": {"Milk": 7, "Cheese": 30, "Yogurt": 14, "Butter": 45, "Cream": 10},
    "Fruits": {"Apples": 21, "Bananas": 5, "Oranges": 14, "Strawberries": 3, "Grapes": 10},
    "Vegetables": {"Lettuce": 7, "Tomatoes": 10, "Carrots": 21, "Broccoli": 7, "Spinach": 5},
    "Meat": {"Chicken": 3, "Beef": 5, "Pork": 5, "Fish": 2, "Turkey": 4}
}
```

**How It Works:**
- These values represent **industry-standard shelf life** under optimal conditions
- Derived from **historical food safety data** and regulatory guidelines
- Serves as the **baseline** for all RSL calculations

---

### 3. **Optimal Storage Conditions** (Historical Standards)

**Location in Code:** `backend/main.py` - `OPTIMAL_CONDITIONS` dictionary

```python
OPTIMAL_CONDITIONS = {
    "Dairy": {"temp_min": 2, "temp_max": 4, "humidity_min": 60, "humidity_max": 70},
    "Fruits": {"temp_min": 0, "temp_max": 10, "humidity_min": 85, "humidity_max": 95},
    "Vegetables": {"temp_min": 0, "temp_max": 7, "humidity_min": 85, "humidity_max": 95},
    "Meat": {"temp_min": -2, "temp_max": 2, "humidity_min": 80, "humidity_max": 90}
}
```

**How It Works:**
- Based on **historical research and food science** data
- Deviations from optimal conditions trigger RSL adjustments
- Used by `calculate_temperature_impact()` and `calculate_humidity_impact()` functions

---

### 4. **Cold Chain Break History** (Per-Batch Historical Events)

**Location in Code:** `backend/main.py` - `calculate_logistics_impact()` function

```python
def calculate_logistics_impact(handling_events: int, cold_chain_breaks: int, transport_days: float) -> float:
    base_factor = 1.0
    
    # Each handling event reduces RSL by 2%
    handling_impact = max(0.8, 1.0 - (handling_events * 0.02))
    
    # Each cold chain break reduces RSL by 10%
    cold_chain_impact = max(0.5, 1.0 - (cold_chain_breaks * 0.10))
    
    # Extended transport (>2 days) reduces RSL
    transport_impact = max(0.7, 1.0 - max(0, transport_days - 2) * 0.05)
    
    return handling_impact * cold_chain_impact * transport_impact
```

**How It Works:**
- **Cold chain breaks** are logged from **historical transport/storage events**
- Each cold chain break (temperature excursion) recorded in the batch's history reduces RSL by **10%**
- Maximum penalty capped at **50% reduction** (factor = 0.5)

**Example:**
```
Batch: BATCH-1003
Cold Chain Breaks: 2 (recorded during transport)

Impact: 1.0 - (2 × 0.10) = 0.80 (20% RSL reduction)
```

---

### 5. **Handling Events History** (Per-Batch)

**How It Works:**
- Records number of times a batch was physically handled (loading/unloading, transfers)
- Based on **historical inventory movement data**
- Each event reduces RSL by **2%** (simulating physical stress on products)

---

## 🔄 Data Flow for Historical Calculations

```
┌─────────────────────────────────────────────────────────────┐
│                    DATA SOURCES                              │
├─────────────────────────────────────────────────────────────┤
│  1. Supplier Master Data (SUPPLIER_HISTORY)                  │
│     → Pre-loaded historical supplier performance             │
│                                                              │
│  2. Product Master Data (BASE_SHELF_LIFE)                    │
│     → Industry-standard shelf life values                    │
│                                                              │
│  3. Inventory Upload (CSV)                                   │
│     → cold_chain_breaks, handling_events, transport_days     │
│     → Historical events recorded per batch                   │
│                                                              │
│  4. Sensor Data (Real-time + Historical)                     │
│     → Temperature/humidity readings over time                │
└─────────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                   RSL CALCULATION                            │
│                                                              │
│  calculate_rsl(                                              │
│      product_name,                                           │
│      category,                                               │
│      manufacture_date,                                       │
│      temperature,       ← Real-time sensor                   │
│      humidity,          ← Real-time sensor                   │
│      handling_events,   ← Historical batch data              │
│      cold_chain_breaks, ← Historical batch data              │
│      transport_days,    ← Historical logistics data          │
│      supplier,          ← Historical supplier factor         │
│      image_analysis     ← Visual analysis (if available)     │
│  )                                                           │
└─────────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                      OUTPUT                                  │
│                                                              │
│  {                                                           │
│    "rsl_days": 4.2,                                          │
│    "rsl_hours": 100.8,                                       │
│    "decay_score": 58.3,                                      │
│    "quality_grade": "C",                                     │
│    "factors": {                                              │
│      "supplier": {"factor": 0.95, "name": "Supplier_A"},    │
│      "logistics": {"cold_chain_breaks": 1},                  │
│      ...                                                     │
│    }                                                         │
│  }                                                           │
└─────────────────────────────────────────────────────────────┘
```

---

## 📈 How Historical Data Improves Predictions

| Historical Factor | Weight | Source | Improvement |
|-------------------|--------|--------|-------------|
| Supplier Performance | 10% | SUPPLIER_HISTORY | Better supplier quality = longer RSL |
| Base Shelf Life | Baseline | BASE_SHELF_LIFE | Industry-standard reference |
| Cold Chain Breaks | 15% (part of logistics) | Batch history | Each break = -10% RSL |
| Handling Events | 15% (part of logistics) | Batch history | Each event = -2% RSL |
| Storage Conditions | 25% | OPTIMAL_CONDITIONS | Deviation triggers adjustment |

---

## 🔮 Future Enhancements for Historical Data

1. **Dynamic Supplier Scoring**: Automatically update supplier reliability based on actual decay rates of received batches

2. **Seasonal Adjustment**: Apply historical seasonal factors (e.g., summer = faster decay for dairy)

3. **Location-specific History**: Track decay patterns by warehouse/store location

4. **Product Batch Lineage**: Track products from same production batches for correlation

5. **Machine Learning Integration**: Train models on historical decay data for more accurate predictions

---

## 📁 Relevant Code Files

| File | Description |
|------|-------------|
| `backend/main.py` | Main RSL calculation logic |
| `backend/main.py:48-75` | Historical data constants |
| `backend/main.py:255-360` | `calculate_rsl()` function |
| `backend/main.py:77-130` | Impact calculation functions |

---

*Document Version: 1.0 | Last Updated: December 2025*

