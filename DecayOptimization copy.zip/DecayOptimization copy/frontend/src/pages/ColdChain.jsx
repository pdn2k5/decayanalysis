import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Thermometer, Droplets, AlertTriangle, RefreshCw, MapPin, Activity } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine, AreaChart, Area } from 'recharts';
import { getTemperatureMonitoring, getLocations } from '../services/api';

function ColdChain() {
  const [data, setData] = useState(null);
  const [locations, setLocations] = useState([]);
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [hours, setHours] = useState(24);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchLocations();
  }, []);

  useEffect(() => {
    fetchData();
  }, [selectedLocation, hours]);

  const fetchLocations = async () => {
    try {
      const result = await getLocations();
      setLocations(result.locations || result || []);
    } catch (error) {
      console.error('Failed to fetch locations:', error);
    }
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      const result = await getTemperatureMonitoring(hours, selectedLocation);
      setData(result);
    } catch (error) {
      console.error('Failed to fetch temperature data:', error);
    }
    setLoading(false);
  };

  // Get temperature status color
  const getTempStatus = (temp) => {
    if (temp < 0) return { color: 'text-blue-600', bg: 'bg-blue-50', status: 'Too Cold' };
    if (temp <= 4) return { color: 'text-green-600', bg: 'bg-green-50', status: 'Optimal' };
    if (temp <= 8) return { color: 'text-yellow-600', bg: 'bg-yellow-50', status: 'Warning' };
    return { color: 'text-red-600', bg: 'bg-red-50', status: 'Critical' };
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gradient">Cold Chain Monitoring</h1>
          <p className="text-gray-600 mt-1">Real-time temperature and environmental tracking</p>
        </div>
        <div className="flex items-center gap-3">
          <select
            value={hours}
            onChange={(e) => setHours(Number(e.target.value))}
            className="px-4 py-2 bg-white border border-gray-200 rounded-xl text-gray-700 focus:outline-none focus:border-primary-500"
          >
            <option value={6}>Last 6 hours</option>
            <option value={12}>Last 12 hours</option>
            <option value={24}>Last 24 hours</option>
            <option value={48}>Last 48 hours</option>
          </select>
          <button
            onClick={fetchData}
            className="p-2 bg-primary-100 hover:bg-primary-200 text-primary-700 rounded-xl transition-colors"
          >
            <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-xl p-5 border border-gray-200 shadow-sm"
        >
          <div className="flex items-center gap-3 mb-2">
            <Activity className="w-5 h-5 text-accent-600" />
            <span className="text-sm text-gray-500">Total Readings</span>
          </div>
          <p className="text-3xl font-bold text-gray-900">{data?.total_readings || data?.data?.length || 0}</p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className={`rounded-xl p-5 border shadow-sm ${
            (data?.total_anomalies || 0) > 0
              ? 'bg-red-50 border-red-200'
              : 'bg-green-50 border-green-200'
          }`}
        >
          <div className="flex items-center gap-3 mb-2">
            <AlertTriangle className={`w-5 h-5 ${
              (data?.total_anomalies || 0) > 0 ? 'text-red-600' : 'text-green-600'
            }`} />
            <span className="text-sm text-gray-500">Temp. Anomalies</span>
          </div>
          <p className={`text-3xl font-bold ${
            (data?.total_anomalies || 0) > 0 ? 'text-red-600' : 'text-green-600'
          }`}>
            {data?.total_anomalies || 0}
          </p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-xl p-5 border border-gray-200 shadow-sm"
        >
          <div className="flex items-center gap-3 mb-2">
            <Thermometer className="w-5 h-5 text-orange-600" />
            <span className="text-sm text-gray-500">Anomaly Rate</span>
          </div>
          <p className="text-3xl font-bold text-gray-900">{data?.anomaly_rate?.toFixed(1) || 0}%</p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-white rounded-xl p-5 border border-gray-200 shadow-sm"
        >
          <div className="flex items-center gap-3 mb-2">
            <MapPin className="w-5 h-5 text-primary-600" />
            <span className="text-sm text-gray-500">Locations</span>
          </div>
          <p className="text-3xl font-bold text-gray-900">{locations.length || 0}</p>
        </motion.div>
      </div>

      {/* Location Filter */}
      <div className="flex items-center gap-2 flex-wrap">
        <button
          onClick={() => setSelectedLocation(null)}
          className={`px-4 py-2 rounded-xl transition-colors ${
            !selectedLocation
              ? 'bg-primary-100 text-primary-700 border border-primary-300'
              : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
          }`}
        >
          All Locations
        </button>
        {Array.isArray(locations) && locations.map((loc) => (
          <button
            key={loc.location || loc}
            onClick={() => setSelectedLocation(loc.location || loc)}
            className={`px-4 py-2 rounded-xl transition-colors ${
              selectedLocation === (loc.location || loc)
                ? 'bg-primary-100 text-primary-700 border border-primary-300'
                : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
            }`}
          >
            {loc.location || loc} {loc.active_batches ? `(${loc.active_batches})` : ''}
          </button>
        ))}
      </div>

      {/* Temperature Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm"
      >
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-900">
          <Thermometer className="w-5 h-5 text-accent-600" />
          Temperature Timeline
        </h3>
        <div className="h-80">
          {loading ? (
            <div className="flex items-center justify-center h-full">
              <RefreshCw className="w-8 h-8 text-primary-600 animate-spin" />
            </div>
          ) : (data?.timeline?.length || data?.data?.length) ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data?.timeline || data?.data || []}>
                <defs>
                  <linearGradient id="tempGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00D9C9" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#00D9C9" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis 
                  dataKey="timestamp" 
                  stroke="#9ca3af"
                  tick={{ fill: '#6b7280', fontSize: 11 }}
                  tickFormatter={(v) => {
                    const date = new Date(v);
                    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
                  }}
                />
                <YAxis 
                  stroke="#9ca3af" 
                  tick={{ fill: '#6b7280', fontSize: 11 }} 
                  domain={[-2, 15]}
                  label={{ value: '°C', angle: -90, position: 'insideLeft', fill: '#6b7280' }}
                />
                <Tooltip
                  contentStyle={{ 
                    backgroundColor: '#ffffff', 
                    border: '1px solid #e5e7eb', 
                    borderRadius: '8px',
                    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                  }}
                  formatter={(value, name) => [`${value}°C`, name.replace('_', ' ').replace('temperature', 'Temp')]}
                />
                <ReferenceLine y={2} stroke="#22c55e" strokeDasharray="5 5" />
                <ReferenceLine y={4} stroke="#22c55e" strokeDasharray="5 5" />
                <ReferenceLine y={8} stroke="#f59e0b" strokeDasharray="5 5" />
                <Area
                  type="monotone"
                  dataKey={data?.timeline ? "avg_temperature" : "temperature"}
                  stroke="#00D9C9"
                  strokeWidth={2}
                  fill="url(#tempGradient)"
                  name="Avg Temp"
                />
                {data?.timeline && (
                  <>
                    <Line
                      type="monotone"
                      dataKey="max_temperature"
                      stroke="#ef4444"
                      strokeWidth={1}
                      strokeDasharray="3 3"
                      dot={false}
                      name="Max Temp"
                    />
                    <Line
                      type="monotone"
                      dataKey="min_temperature"
                      stroke="#22c55e"
                      strokeWidth={1}
                      strokeDasharray="3 3"
                      dot={false}
                      name="Min Temp"
                    />
                  </>
                )}
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-full text-gray-500">
              <div className="text-center">
                <Thermometer className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>No temperature data available</p>
                <p className="text-sm mt-1">Upload sensor data to see the temperature timeline</p>
              </div>
            </div>
          )}
        </div>
      </motion.div>

      {/* Recent Readings Table */}
      {data?.data?.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm"
        >
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-900">
            <Activity className="w-5 h-5 text-primary-600" />
            Recent Sensor Readings
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200 bg-gray-50">
                  <th className="text-left px-4 py-3 text-sm font-medium text-gray-600">Time</th>
                  <th className="text-left px-4 py-3 text-sm font-medium text-gray-600">Location</th>
                  <th className="text-center px-4 py-3 text-sm font-medium text-gray-600">Temperature</th>
                  <th className="text-center px-4 py-3 text-sm font-medium text-gray-600">Humidity</th>
                  <th className="text-center px-4 py-3 text-sm font-medium text-gray-600">Status</th>
                </tr>
              </thead>
              <tbody>
                {data.data.slice(-10).reverse().map((reading, idx) => {
                  const status = getTempStatus(reading.temperature);
                  return (
                    <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="px-4 py-3 text-sm text-gray-600">
                        {new Date(reading.timestamp).toLocaleString('en-IN', {
                          hour: '2-digit',
                          minute: '2-digit',
                          day: 'numeric',
                          month: 'short'
                        })}
                      </td>
                      <td className="px-4 py-3 text-sm text-gray-900 font-medium">{reading.location}</td>
                      <td className={`px-4 py-3 text-sm text-center font-mono font-bold ${status.color}`}>
                        {reading.temperature}°C
                      </td>
                      <td className="px-4 py-3 text-sm text-center text-gray-600">
                        {reading.humidity}%
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${status.bg} ${status.color}`}>
                          {status.status}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </motion.div>
      )}

      {/* Legend */}
      <div className="bg-white rounded-xl p-4 border border-gray-200 shadow-sm">
        <h4 className="text-sm font-medium mb-3 text-gray-900">Temperature Guidelines by Category</h4>
        <div className="grid grid-cols-4 gap-4 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-green-500 rounded" />
            <span className="text-gray-600">Dairy: 2-4°C</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-yellow-500 rounded" />
            <span className="text-gray-600">Fruits: 4-8°C</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-primary-500 rounded" />
            <span className="text-gray-600">Vegetables: 1-7°C</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-blue-500 rounded" />
            <span className="text-gray-600">Meat: -2 to 2°C</span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ColdChain;
