import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageSquare, Send, Volume2, Mic, Lightbulb, RefreshCw, Bot, User } from 'lucide-react';
import { queryAssistant, getInsights, getAssistantStatus, textToSpeech } from '../services/api';

function Assistant() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [insights, setInsights] = useState(null);
  const [status, setStatus] = useState(null);
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    checkStatus();
    fetchInsights();
    // Add welcome message
    setMessages([{
      role: 'assistant',
      content: "Hello! I'm your **Decay Optimization Assistant**. I specialize in perishable inventory management.\n\nI can help you with:\n• 📊 Inventory status and batch information\n• 🧪 Decay analysis and quality grades\n• ⚠️ Alert monitoring and critical items\n• 💰 Markdown and pricing recommendations\n• 🌡️ Cold chain monitoring\n\nAsk me about your inventory, alerts, or expiring products!"
    }]);
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const checkStatus = async () => {
    try {
      const result = await getAssistantStatus();
      setStatus(result);
    } catch (error) {
      setStatus({ available: true, provider: 'Built-in AI' });
    }
  };

  const fetchInsights = async () => {
    try {
      const result = await getInsights();
      setInsights(result);
    } catch (error) {
      console.error('Failed to fetch insights:', error);
    }
  };

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setLoading(true);

    try {
      const result = await queryAssistant(userMessage, false);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: result.response,
        context: result.context_summary
      }]);
    } catch (error) {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: 'Sorry, I encountered an error processing your request. Please try again.',
        error: true
      }]);
    }

    setLoading(false);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSpeak = async (text) => {
    try {
      const result = await textToSpeech(text.substring(0, 500));
      if (result.audio_base64 && window.playVoiceAlert) {
        window.playVoiceAlert(result.audio_base64);
      }
    } catch (error) {
      console.error('Failed to speak:', error);
    }
  };

  const suggestedQuestions = [
    "What are my current alerts?",
    "Show me dairy inventory status",
    "Which products are expiring soon?",
    "Give me markdown recommendations",
    "Analyze decay trends"
  ];

  return (
    <div className="flex gap-6 h-[calc(100vh-180px)]">
      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-gray-200 flex items-center justify-between bg-gray-50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary-500 to-accent-500 flex items-center justify-center">
              <Bot className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="font-semibold text-gray-900">Decay AI Assistant</h2>
              <p className="text-xs text-gray-500">
                <span className="text-green-600">● Online</span>
                {' '}• Inventory & Decay Specialist
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              setMessages([messages[0]]);
              inputRef.current?.focus();
            }}
            className="p-2 hover:bg-gray-200 rounded-lg transition-colors text-gray-600"
            title="Clear chat"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
          <AnimatePresence>
            {messages.map((msg, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
              >
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                  msg.role === 'user'
                    ? 'bg-accent-100'
                    : 'bg-primary-100'
                }`}>
                  {msg.role === 'user' ? (
                    <User className="w-4 h-4 text-accent-600" />
                  ) : (
                    <Bot className="w-4 h-4 text-primary-600" />
                  )}
                </div>
                <div className={`max-w-[80%] ${msg.role === 'user' ? 'text-right' : ''}`}>
                  <div className={`p-4 rounded-2xl ${
                    msg.role === 'user' 
                      ? 'bg-primary-500 text-white rounded-tr-sm' 
                      : 'bg-white border border-gray-200 text-gray-800 rounded-tl-sm shadow-sm'
                  } ${msg.error ? 'border border-red-300 bg-red-50' : ''}`}>
                    <p className="text-sm whitespace-pre-line">{msg.content}</p>
                  </div>
                  {msg.role === 'assistant' && !msg.error && (
                    <button
                      onClick={() => handleSpeak(msg.content)}
                      className="mt-2 p-1.5 text-gray-400 hover:text-primary-600 transition-colors"
                      title="Listen to response"
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
          
          {loading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex gap-3"
            >
              <div className="w-8 h-8 rounded-lg bg-primary-100 flex items-center justify-center">
                <Bot className="w-4 h-4 text-primary-600" />
              </div>
              <div className="p-4 rounded-2xl bg-white border border-gray-200 rounded-tl-sm shadow-sm">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-primary-500 rounded-full animate-bounce" />
                  <div className="w-2 h-2 bg-primary-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                  <div className="w-2 h-2 bg-primary-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                </div>
              </div>
            </motion.div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Suggested Questions */}
        {messages.length <= 2 && (
          <div className="p-4 border-t border-gray-200 bg-white">
            <p className="text-xs text-gray-500 mb-2">Suggested questions:</p>
            <div className="flex flex-wrap gap-2">
              {suggestedQuestions.map((q, i) => (
                <button
                  key={i}
                  onClick={() => {
                    setInput(q);
                    inputRef.current?.focus();
                  }}
                  className="px-3 py-1.5 text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input */}
        <div className="p-4 border-t border-gray-200 bg-white">
          <div className="flex items-center gap-3">
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask about inventory, decay, alerts, markdown..."
              className="flex-1 px-4 py-3 bg-gray-100 border border-gray-200 rounded-xl focus:outline-none focus:border-primary-500 focus:bg-white transition-colors text-gray-900"
              disabled={loading}
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || loading}
              className="p-3 bg-primary-500 hover:bg-primary-600 text-white rounded-xl transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Sidebar - Insights */}
      <div className="w-80 space-y-4">
        {/* AI Insights */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-white rounded-2xl p-5 border border-gray-200 shadow-sm"
        >
          <h3 className="font-semibold mb-3 flex items-center gap-2 text-gray-900">
            <Lightbulb className="w-5 h-5 text-yellow-500" />
            Quick Insights
          </h3>
          {insights ? (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="bg-gray-50 rounded-lg p-3">
                  <p className="text-gray-500 text-xs">Total Batches</p>
                  <p className="font-bold text-lg text-gray-900">{insights.metrics?.total_batches || 0}</p>
                </div>
                <div className="bg-red-50 rounded-lg p-3">
                  <p className="text-gray-500 text-xs">Critical</p>
                  <p className="font-bold text-lg text-red-600">{insights.metrics?.critical || 0}</p>
                </div>
                <div className="bg-orange-50 rounded-lg p-3">
                  <p className="text-gray-500 text-xs">High Risk</p>
                  <p className="font-bold text-lg text-orange-600">{insights.metrics?.high_risk || 0}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-3">
                  <p className="text-gray-500 text-xs">Avg Decay</p>
                  <p className="font-bold text-lg text-gray-900">{insights.metrics?.average_decay || 0}%</p>
                </div>
              </div>
              {insights.insights && (
                <div className="bg-gray-50 rounded-lg p-3">
                  <p className="text-gray-500 text-xs mb-2">Key Insights</p>
                  <p className="text-sm text-gray-700 whitespace-pre-line line-clamp-6">
                    {insights.insights}
                  </p>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-4">
              <RefreshCw className="w-6 h-6 mx-auto text-gray-400 animate-spin" />
            </div>
          )}
          <button
            onClick={fetchInsights}
            className="w-full mt-3 py-2 text-sm bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors"
          >
            Refresh Insights
          </button>
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-2xl p-5 border border-gray-200 shadow-sm"
        >
          <h3 className="font-semibold mb-3 text-gray-900">Quick Actions</h3>
          <div className="space-y-2">
            <button
              onClick={() => {
                setInput("Give me a daily inventory report");
                inputRef.current?.focus();
              }}
              className="w-full p-3 text-left text-sm bg-gray-50 hover:bg-gray-100 text-gray-700 rounded-lg transition-colors"
            >
              📊 Generate Daily Report
            </button>
            <button
              onClick={() => {
                setInput("What products need markdown today?");
                inputRef.current?.focus();
              }}
              className="w-full p-3 text-left text-sm bg-gray-50 hover:bg-gray-100 text-gray-700 rounded-lg transition-colors"
            >
              💰 Get Markdown Suggestions
            </button>
            <button
              onClick={() => {
                setInput("Analyze why products are decaying");
                inputRef.current?.focus();
              }}
              className="w-full p-3 text-left text-sm bg-gray-50 hover:bg-gray-100 text-gray-700 rounded-lg transition-colors"
            >
              🔍 Root Cause Analysis
            </button>
            <button
              onClick={() => {
                setInput("Show me temperature alerts");
                inputRef.current?.focus();
              }}
              className="w-full p-3 text-left text-sm bg-gray-50 hover:bg-gray-100 text-gray-700 rounded-lg transition-colors"
            >
              🌡️ Cold Chain Status
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

export default Assistant;
