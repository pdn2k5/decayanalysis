import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, RefreshCw, Calendar, BarChart3 } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, PieChart, Pie, Cell } from 'recharts';
import { getDecayTrends, getWasteAnalysis, getDailyReport } from '../services/api';

const COLORS = ['#00e6a0', '#00a0e6', '#f59e0b', '#ef4444'];

function Analytics() {
  const [trends, setTrends] = useState(null);
  const [waste, setWaste] = useState(null);
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);
  const [days, setDays] = useState(30);

  useEffect(() => {
    fetchData();
  }, [days]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [trendsData, wasteData, reportData] = await Promise.all([
        getDecayTrends(days),
        getWasteAnalysis(days),
        getDailyReport()
      ]);
      setTrends(trendsData);
      setWaste(wasteData);
      setReport(reportData);
    } catch (error) {
      console.error('Failed to fetch analytics:', error);
    }
    setLoading(false);
  };

  const wasteByCategory = waste?.by_category
    ? Object.entries(waste.by_category).map(([name, data]) => ({
        name,
        value: data.value || 0
      }))
    : [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gradient">Analytics</h1>
          <p className="text-gray-400 mt-1">Insights and trends analysis</p>
        </div>
        <div className="flex items-center gap-3">
          <select
            value={days}
            onChange={(e) => setDays(Number(e.target.value))}
            className="px-4 py-2 bg-dark-800 border border-white/10 rounded-xl"
          >
            <option value={7}>Last 7 days</option>
            <option value={14}>Last 14 days</option>
            <option value={30}>Last 30 days</option>
            <option value={60}>Last 60 days</option>
          </select>
          <button
            onClick={fetchData}
            className="p-2 bg-primary-500/20 hover:bg-primary-500/30 rounded-xl transition-colors"
          >
            <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Daily Report Summary */}
      {report && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-primary-500/10 to-accent-500/10 rounded-2xl p-6 border border-primary-500/20"
        >
          <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
            <Calendar className="w-5 h-5 text-primary-400" />
            Daily Executive Summary
          </h3>
          <p className="text-gray-300 leading-relaxed whitespace-pre-line">
            {report.executive_summary}
          </p>
        </motion.div>
      )}

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Decay Trend */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-dark-800/50 rounded-2xl p-6 border border-white/10"
        >
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-primary-400" />
            Average Decay Score Trend
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trends?.data || []}>
                <defs>
                  <linearGradient id="colorDecay" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00e6a0" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#00e6a0" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis 
                  dataKey="date" 
                  stroke="#666"
                  tick={{ fill: '#888', fontSize: 11 }}
                  tickFormatter={(v) => new Date(v).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                />
                <YAxis stroke="#666" tick={{ fill: '#888', fontSize: 11 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1e1e2e', border: '1px solid #333', borderRadius: '8px' }}
                />
                <Area
                  type="monotone"
                  dataKey="avg_decay_score"
                  stroke="#00e6a0"
                  fillOpacity={1}
                  fill="url(#colorDecay)"
                  name="Avg Decay %"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Waste by Category */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-dark-800/50 rounded-2xl p-6 border border-white/10"
        >
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-accent-400" />
            Waste Value by Category
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={wasteByCategory}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {wasteByCategory.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#1e1e2e', border: '1px solid #333', borderRadius: '8px' }}
                  formatter={(value) => `₹${value.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-4 mt-2">
            {wasteByCategory.map((item, index) => (
              <div key={item.name} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                <span className="text-xs text-gray-400">{item.name}</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Waste Summary */}
      {waste && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-dark-800/50 rounded-2xl p-6 border border-white/10"
        >
          <h3 className="text-lg font-semibold mb-4">Waste Analysis Summary</h3>
          <div className="grid grid-cols-4 gap-6">
            <div>
              <p className="text-sm text-gray-400">Total Waste</p>
              <p className="text-2xl font-bold text-danger-400">
                {waste.total_waste?.quantity || 0} units
              </p>
              <p className="text-sm text-gray-500">₹{waste.total_waste?.value?.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || 0}</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Batches Disposed</p>
              <p className="text-2xl font-bold">{waste.total_waste?.batches || 0}</p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Prevention Opportunity</p>
              <p className="text-2xl font-bold text-success-400">
                ₹{waste.prevention_opportunity?.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || 0}
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-400">Period</p>
              <p className="text-2xl font-bold">{days} days</p>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}

export default Analytics;

