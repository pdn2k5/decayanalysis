import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Package, Search, Filter, RefreshCw, AlertTriangle, Clock, MapPin, ChevronDown } from 'lucide-react';
import { getBatches, predictDecay, getExplanation } from '../services/api';

const CATEGORIES = ['All', 'Dairy', 'Fruits', 'Vegetables', 'Meat'];
const STATUS_OPTIONS = ['active', 'markdown', 'disposed', 'sold'];

function GradeBadge({ grade }) {
  const colors = {
    A: 'bg-green-100 text-green-700',
    B: 'bg-lime-100 text-lime-700',
    C: 'bg-yellow-100 text-yellow-700',
    D: 'bg-red-100 text-red-700',
    F: 'bg-gray-100 text-gray-700'
  };
  return (
    <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${colors[grade] || 'bg-gray-100 text-gray-700'}`}>
      {grade}
    </span>
  );
}

function UrgencyBadge({ urgency }) {
  const styles = {
    critical: 'bg-red-100 text-red-700 border-red-200',
    high: 'bg-orange-100 text-orange-700 border-orange-200',
    medium: 'bg-yellow-100 text-yellow-700 border-yellow-200',
    low: 'bg-green-100 text-green-700 border-green-200'
  };
  return (
    <span className={`px-2 py-0.5 rounded-full text-xs font-medium border ${styles[urgency] || styles.low}`}>
      {urgency?.toUpperCase()}
    </span>
  );
}

function Inventory() {
  const [batches, setBatches] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBatch, setSelectedBatch] = useState(null);
  const [explanation, setExplanation] = useState(null);
  const [predicting, setPredicting] = useState(null);

  useEffect(() => {
    fetchBatches();
  }, [selectedCategory]);

  const fetchBatches = async () => {
    setLoading(true);
    try {
      const filters = {};
      if (selectedCategory !== 'All') {
        filters.category = selectedCategory;
      }
      const data = await getBatches(filters);
      setBatches(data.batches || []);
    } catch (error) {
      console.error('Failed to fetch batches:', error);
    }
    setLoading(false);
  };

  const handlePredict = async (batchId) => {
    setPredicting(batchId);
    try {
      await predictDecay(batchId);
      await fetchBatches();
    } catch (error) {
      console.error('Prediction failed:', error);
    }
    setPredicting(null);
  };

  const handleExplain = async (batch) => {
    setSelectedBatch(batch);
    try {
      const result = await getExplanation(batch.batch_id);
      setExplanation(result);
    } catch (error) {
      console.error('Failed to get explanation:', error);
      setExplanation({ explanation: 'Unable to generate explanation at this time.' });
    }
  };

  const filteredBatches = batches.filter(batch =>
    batch.product_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    batch.batch_id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gradient">Inventory</h1>
          <p className="text-gray-600 mt-1">Manage and monitor perishable inventory</p>
        </div>
        <button
          onClick={fetchBatches}
          className="flex items-center gap-2 px-4 py-2 bg-primary-100 hover:bg-primary-200 text-primary-700 rounded-xl transition-colors"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          <span className="text-sm">Refresh</span>
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-4">
        <div className="relative flex-1 min-w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search products or batch IDs..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 bg-white border border-gray-200 rounded-xl focus:outline-none focus:border-primary-500 focus:ring-1 focus:ring-primary-500 transition-colors text-gray-900"
          />
        </div>
        <div className="flex items-center gap-2">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl transition-colors ${
                selectedCategory === cat
                  ? 'bg-primary-100 text-primary-700 border border-primary-300'
                  : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-4 border border-gray-200 shadow-sm">
          <p className="text-sm text-gray-500">Total Batches</p>
          <p className="text-2xl font-bold text-gray-900">{filteredBatches.length}</p>
        </div>
        <div className="bg-white rounded-xl p-4 border border-gray-200 shadow-sm">
          <p className="text-sm text-gray-500">Critical</p>
          <p className="text-2xl font-bold text-red-600">
            {filteredBatches.filter(b => b.action_urgency === 'critical').length}
          </p>
        </div>
        <div className="bg-white rounded-xl p-4 border border-gray-200 shadow-sm">
          <p className="text-sm text-gray-500">At Risk</p>
          <p className="text-2xl font-bold text-orange-600">
            {filteredBatches.filter(b => b.action_urgency === 'high').length}
          </p>
        </div>
        <div className="bg-white rounded-xl p-4 border border-gray-200 shadow-sm">
          <p className="text-sm text-gray-500">Healthy</p>
          <p className="text-2xl font-bold text-green-600">
            {filteredBatches.filter(b => !b.action_urgency || b.action_urgency === 'low').length}
          </p>
        </div>
      </div>

      {/* Table */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden"
      >
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200 bg-gray-50">
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-600">Product</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-600">Batch ID</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-600">Category</th>
                <th className="text-left px-6 py-4 text-sm font-medium text-gray-600">Location</th>
                <th className="text-center px-6 py-4 text-sm font-medium text-gray-600">Qty</th>
                <th className="text-center px-6 py-4 text-sm font-medium text-gray-600">Decay</th>
                <th className="text-center px-6 py-4 text-sm font-medium text-gray-600">Grade</th>
                <th className="text-center px-6 py-4 text-sm font-medium text-gray-600">Days Left</th>
                <th className="text-center px-6 py-4 text-sm font-medium text-gray-600">Status</th>
                <th className="text-center px-6 py-4 text-sm font-medium text-gray-600">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="10" className="px-6 py-12 text-center">
                    <RefreshCw className="w-8 h-8 mx-auto text-primary-600 animate-spin" />
                  </td>
                </tr>
              ) : filteredBatches.length === 0 ? (
                <tr>
                  <td colSpan="10" className="px-6 py-12 text-center text-gray-500">
                    No inventory batches found. Upload data from the Data Upload page.
                  </td>
                </tr>
              ) : (
                filteredBatches.map((batch, index) => (
                  <motion.tr
                    key={batch.batch_id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.02 }}
                    className="border-b border-gray-100 hover:bg-gray-50 transition-colors"
                  >
                    <td className="px-6 py-4">
                      <div className="font-medium text-gray-900">{batch.product_name}</div>
                    </td>
                    <td className="px-6 py-4">
                      <code className="text-xs text-gray-600 bg-gray-100 px-2 py-1 rounded">
                        {batch.batch_id}
                      </code>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`category-${batch.category?.toLowerCase()}`}>
                        {batch.category}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-400">
                      <div className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        {batch.location}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-center">{batch.quantity}</td>
                    <td className="px-6 py-4 text-center">
                      {batch.decay_score != null ? (
                        <span className={`font-mono ${
                          batch.decay_score > 70 ? 'text-red-600' :
                          batch.decay_score > 50 ? 'text-orange-600' :
                          'text-green-600'
                        }`}>
                          {batch.decay_score.toFixed(1)}%
                        </span>
                      ) : (
                        <span className="text-gray-500">—</span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-center">
                      {batch.quality_grade ? (
                        <GradeBadge grade={batch.quality_grade} />
                      ) : (
                        <span className="text-gray-500">—</span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-center">
                      {batch.days_remaining != null ? (
                        <div className="flex items-center justify-center gap-1">
                          <Clock className="w-3 h-3 text-gray-400" />
                          <span className={batch.days_remaining < 2 ? 'text-red-600' : 'text-gray-700'}>
                            {batch.days_remaining.toFixed(1)}
                          </span>
                        </div>
                      ) : (
                        <span className="text-gray-500">—</span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-center">
                      {batch.action_urgency && (
                        <UrgencyBadge urgency={batch.action_urgency} />
                      )}
                    </td>
                    <td className="px-6 py-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => handlePredict(batch.batch_id)}
                          disabled={predicting === batch.batch_id}
                          className="px-3 py-1 text-xs bg-primary-100 hover:bg-primary-200 text-primary-700 rounded-lg transition-colors disabled:opacity-50"
                        >
                          {predicting === batch.batch_id ? 'Predicting...' : 'Predict'}
                        </button>
                        <button
                          onClick={() => handleExplain(batch)}
                          className="px-3 py-1 text-xs bg-accent-100 hover:bg-accent-200 text-accent-700 rounded-lg transition-colors"
                        >
                          Explain
                        </button>
                      </div>
                    </td>
                  </motion.tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Explanation Modal */}
      {selectedBatch && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-2xl p-6 max-w-lg w-full border border-gray-200 shadow-xl"
          >
            <h3 className="text-xl font-bold mb-2 text-gray-900">{selectedBatch.product_name}</h3>
            <p className="text-sm text-gray-500 mb-4">Batch: {selectedBatch.batch_id}</p>
            
            <div className="bg-gray-50 rounded-xl p-4 mb-4">
              <h4 className="font-medium mb-2 text-primary-600">AI Analysis</h4>
              <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-line">
                {explanation?.explanation || 'Loading explanation...'}
              </p>
            </div>
            
            <button
              onClick={() => {
                setSelectedBatch(null);
                setExplanation(null);
              }}
              className="w-full py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl transition-colors"
            >
              Close
            </button>
          </motion.div>
        </div>
      )}
    </div>
  );
}

export default Inventory;

