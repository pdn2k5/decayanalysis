import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Bell, Check, Trash2, Volume2, RefreshCw, AlertTriangle, Filter } from 'lucide-react';
import { getAlerts, getAlertsSummary, acknowledgeAlert, dismissAlert, getAlertVoice } from '../services/api';

function Alerts() {
  const [alerts, setAlerts] = useState([]);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    fetchData();
  }, [filter]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const filters = {};
      if (filter !== 'all') {
        filters.severity = filter.toUpperCase();
      }
      const [alertsData, summaryData] = await Promise.all([
        getAlerts(filters),
        getAlertsSummary()
      ]);
      setAlerts(alertsData);
      setSummary(summaryData);
    } catch (error) {
      console.error('Failed to fetch alerts:', error);
    }
    setLoading(false);
  };

  const handleAcknowledge = async (alertId) => {
    try {
      await acknowledgeAlert(alertId, 'current_user');
      await fetchData();
    } catch (error) {
      console.error('Failed to acknowledge:', error);
    }
  };

  const handleDismiss = async (alertId) => {
    try {
      await dismissAlert(alertId);
      await fetchData();
    } catch (error) {
      console.error('Failed to dismiss:', error);
    }
  };

  const handlePlayVoice = async (alertId) => {
    try {
      const result = await getAlertVoice(alertId);
      if (result.audio_base64 && window.playVoiceAlert) {
        window.playVoiceAlert(result.audio_base64);
      }
    } catch (error) {
      console.error('Failed to play voice:', error);
    }
  };

  const severityStyles = {
    CRITICAL: {
      bg: 'bg-red-50',
      border: 'border-red-200',
      text: 'text-red-700',
      icon: 'text-red-500'
    },
    HIGH: {
      bg: 'bg-orange-50',
      border: 'border-orange-200',
      text: 'text-orange-700',
      icon: 'text-orange-500'
    },
    MEDIUM: {
      bg: 'bg-yellow-50',
      border: 'border-yellow-200',
      text: 'text-yellow-700',
      icon: 'text-yellow-500'
    },
    LOW: {
      bg: 'bg-green-50',
      border: 'border-green-200',
      text: 'text-green-700',
      icon: 'text-green-500'
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gradient">Alerts</h1>
          <p className="text-gray-600 mt-1">Monitor and manage system alerts</p>
        </div>
        <button
          onClick={fetchData}
          className="flex items-center gap-2 px-4 py-2 bg-primary-100 hover:bg-primary-200 text-primary-700 rounded-xl transition-colors"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          <span className="text-sm">Refresh</span>
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-4 gap-4">
        <div className="bg-red-50 border border-red-200 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span className="text-sm text-red-600">Critical</span>
          </div>
          <p className="text-3xl font-bold text-red-600">{summary?.by_severity?.critical || 0}</p>
        </div>
        <div className="bg-orange-50 border border-orange-200 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 rounded-full bg-orange-500" />
            <span className="text-sm text-orange-600">High</span>
          </div>
          <p className="text-3xl font-bold text-orange-600">{summary?.by_severity?.high || 0}</p>
        </div>
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 rounded-full bg-yellow-500" />
            <span className="text-sm text-yellow-600">Medium</span>
          </div>
          <p className="text-3xl font-bold text-yellow-600">{summary?.by_severity?.medium || 0}</p>
        </div>
        <div className="bg-green-50 border border-green-200 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 rounded-full bg-green-500" />
            <span className="text-sm text-green-600">Low</span>
          </div>
          <p className="text-3xl font-bold text-green-600">{summary?.by_severity?.low || 0}</p>
        </div>
      </div>

      {/* Filter */}
      <div className="flex items-center gap-2">
        <Filter className="w-4 h-4 text-gray-500" />
        {['all', 'critical', 'high', 'medium', 'low'].map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-3 py-1.5 rounded-lg text-sm transition-colors ${
              filter === f
                ? 'bg-primary-100 text-primary-700'
                : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
            }`}
          >
            {f.charAt(0).toUpperCase() + f.slice(1)}
          </button>
        ))}
      </div>

      {/* Alerts List */}
      <div className="space-y-4">
        {loading ? (
          <div className="text-center py-12">
            <RefreshCw className="w-8 h-8 mx-auto text-primary-600 animate-spin" />
          </div>
        ) : alerts.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <Bell className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No alerts to display</p>
          </div>
        ) : (
          alerts.map((alert, index) => {
            const style = severityStyles[alert.severity] || severityStyles.LOW;
            return (
              <motion.div
                key={alert.alert_id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className={`${style.bg} border ${style.border} rounded-xl p-5`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-4">
                    <AlertTriangle className={`w-6 h-6 ${style.icon} mt-0.5`} />
                    <div>
                      <div className="flex items-center gap-3 mb-1">
                        <span className={`text-xs font-bold px-2 py-0.5 rounded ${style.bg} ${style.text}`}>
                          {alert.severity}
                        </span>
                        <span className="text-xs text-gray-500">{alert.alert_type}</span>
                        {alert.is_acknowledged && (
                          <span className="text-xs text-green-600 flex items-center gap-1">
                            <Check className="w-3 h-3" /> Acknowledged
                          </span>
                        )}
                      </div>
                      <h3 className="font-semibold text-lg text-gray-900">{alert.title}</h3>
                      <p className="text-gray-600 mt-1">{alert.message}</p>
                      {alert.smart_message && (
                        <p className="text-sm text-primary-600 mt-2 italic">
                          AI Insight: {alert.smart_message}
                        </p>
                      )}
                      <div className="flex items-center gap-4 mt-3 text-sm text-gray-500">
                        {alert.product_name && <span>Product: {alert.product_name}</span>}
                        {alert.location && <span>Location: {alert.location}</span>}
                        {alert.estimated_loss && (
                          <span className="text-red-600">Est. Loss: ₹{alert.estimated_loss.toFixed(2)}</span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handlePlayVoice(alert.alert_id)}
                      className="p-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
                      title="Play Voice Alert"
                    >
                      <Volume2 className="w-4 h-4 text-gray-600" />
                    </button>
                    {!alert.is_acknowledged && (
                      <button
                        onClick={() => handleAcknowledge(alert.alert_id)}
                        className="p-2 bg-green-100 hover:bg-green-200 rounded-lg transition-colors"
                        title="Acknowledge"
                      >
                        <Check className="w-4 h-4 text-green-600" />
                      </button>
                    )}
                    <button
                      onClick={() => handleDismiss(alert.alert_id)}
                      className="p-2 bg-red-100 hover:bg-red-200 rounded-lg transition-colors"
                      title="Dismiss"
                    >
                      <Trash2 className="w-4 h-4 text-red-600" />
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })
        )}
      </div>
    </div>
  );
}

export default Alerts;

