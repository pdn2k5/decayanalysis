import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Activity,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  Package,
  Clock,
  Thermometer,
  BarChart3,
  RefreshCw,
  Volume2
} from 'lucide-react';

// Custom Indian Rupee Icon
const IndianRupee = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M6 3h12" />
    <path d="M6 8h12" />
    <path d="M6 13l8.5 8" />
    <path d="M6 13h3c3.5 0 6-2.5 6-5H6" />
  </svg>
);
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar
} from 'recharts';
import { getDashboardMetrics, getDecayTrends, getAlerts, loadSampleData, voiceDailySummary } from '../services/api';

const COLORS = {
  primary: '#6247AA',
  accent: '#00D9C9',
  warning: '#f59e0b',
  danger: '#ef4444',
  success: '#22c55e',
  dairy: '#60a5fa',
  fruits: '#f97316',
  vegetables: '#22c55e',
  meat: '#ef4444'
};

const GRADE_COLORS = {
  A: '#22c55e',
  B: '#84cc16',
  C: '#eab308',
  D: '#ef4444'
};

function MetricCard({ title, value, subtitle, icon: Icon, trend, color = 'primary', delay = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm hover:shadow-md transition-shadow"
    >
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-gray-500 mb-1">{title}</p>
          <h3 className="text-3xl font-bold text-gray-900">{value}</h3>
          {subtitle && (
            <p className="text-sm text-gray-500 mt-1 flex items-center gap-1">
              {trend === 'up' && <TrendingUp className="w-4 h-4 text-green-500" />}
              {trend === 'down' && <TrendingDown className="w-4 h-4 text-red-500" />}
              {subtitle}
            </p>
          )}
        </div>
        <div className={`p-3 rounded-xl`} style={{ backgroundColor: `${COLORS[color]}20` }}>
          <Icon className="w-6 h-6" style={{ color: COLORS[color] }} />
        </div>
      </div>
    </motion.div>
  );
}

function AlertCard({ alert, index }) {
  const severityStyles = {
    CRITICAL: { bg: 'bg-red-50', border: 'border-l-red-500', badge: 'bg-red-100 text-red-700' },
    HIGH: { bg: 'bg-orange-50', border: 'border-l-orange-500', badge: 'bg-orange-100 text-orange-700' },
    MEDIUM: { bg: 'bg-yellow-50', border: 'border-l-yellow-500', badge: 'bg-yellow-100 text-yellow-700' },
    LOW: { bg: 'bg-green-50', border: 'border-l-green-500', badge: 'bg-green-100 text-green-700' }
  };
  const style = severityStyles[alert.severity] || severityStyles.MEDIUM;

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.1 }}
      className={`p-4 rounded-xl border-l-4 ${style.bg} ${style.border}`}
    >
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${style.badge}`}>
              {alert.severity}
            </span>
            <span className="text-xs text-gray-500">{alert.alert_type}</span>
          </div>
          <h4 className="font-medium text-sm text-gray-900">{alert.title}</h4>
          <p className="text-xs text-gray-500 mt-1">{alert.product_name || alert.location}</p>
        </div>
      </div>
    </motion.div>
  );
}

function Dashboard() {
  const [metrics, setMetrics] = useState(null);
  const [trends, setTrends] = useState(null);
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingData, setLoadingData] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [metricsData, trendsData, alertsData] = await Promise.all([
        getDashboardMetrics(),
        getDecayTrends(14),
        getAlerts({ limit: 5 })
      ]);
      setMetrics(metricsData);
      setTrends(trendsData);
      setAlerts(alertsData);
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
    }
    setLoading(false);
  };

  const handleLoadSampleData = async () => {
    setLoadingData(true);
    try {
      await loadSampleData();
      await fetchData();
    } catch (error) {
      console.error('Failed to load sample data:', error);
    }
    setLoadingData(false);
  };

  const handleVoiceSummary = async () => {
    if (!metrics) return;
    
    try {
      const result = await voiceDailySummary({
        critical_count: metrics.risk_breakdown?.critical || 0,
        at_risk_count: metrics.risk_breakdown?.high || 0,
        waste_value: metrics.summary?.value_at_risk || 0,
        avg_decay: metrics.summary?.average_decay_score || 0
      });
      
      if (result.audio_base64 && window.playVoiceAlert) {
        window.playVoiceAlert(result.audio_base64);
      }
    } catch (error) {
      console.error('Voice summary failed:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <RefreshCw className="w-8 h-8 text-primary-400 animate-spin" />
      </div>
    );
  }

  // Prepare chart data
  const gradeData = metrics?.grade_distribution
    ? Object.entries(metrics.grade_distribution).map(([grade, count]) => ({
        name: `Grade ${grade}`,
        value: count,
        color: GRADE_COLORS[grade]
      }))
    : [];

  const categoryData = metrics?.by_category
    ? Object.entries(metrics.by_category).map(([category, data]) => ({
        name: category,
        count: data.count,
        decay: data.avg_decay,
        color: COLORS[category.toLowerCase()]
      }))
    : [];

  const trendData = trends?.data?.slice(-14) || [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gradient">Dashboard</h1>
          <p className="text-gray-600 mt-1">Real-time decay monitoring and analytics</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={handleVoiceSummary}
            className="flex items-center gap-2 px-4 py-2 bg-primary-100 hover:bg-primary-200 text-primary-700 rounded-xl transition-colors"
          >
            <Volume2 className="w-4 h-4" />
            <span className="text-sm font-medium">Voice Summary</span>
          </button>
          <button
            onClick={handleLoadSampleData}
            disabled={loadingData}
            className="flex items-center gap-2 px-4 py-2 bg-accent-100 hover:bg-accent-200 text-accent-700 rounded-xl transition-colors disabled:opacity-50"
          >
            {loadingData ? (
              <RefreshCw className="w-4 h-4 animate-spin" />
            ) : (
              <Package className="w-4 h-4" />
            )}
            <span className="text-sm font-medium">Load Sample Data</span>
          </button>
          <button
            onClick={fetchData}
            className="p-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl transition-colors"
          >
            <RefreshCw className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Active Batches"
          value={metrics?.summary?.total_active_batches || 0}
          subtitle={`${metrics?.summary?.total_predicted || 0} predicted`}
          icon={Package}
          color="primary"
          delay={0}
        />
        <MetricCard
          title="Average Decay"
          value={`${metrics?.summary?.average_decay_score?.toFixed(1) || 0}%`}
          subtitle="Across all products"
          icon={Activity}
          color="accent"
          delay={0.1}
        />
        <MetricCard
          title="At Risk Items"
          value={(metrics?.risk_breakdown?.critical || 0) + (metrics?.risk_breakdown?.high || 0)}
          subtitle={`${metrics?.risk_breakdown?.critical || 0} critical`}
          icon={AlertTriangle}
          color="warning"
          trend="up"
          delay={0.2}
        />
        <MetricCard
          title="Value at Risk"
          value={`₹${(metrics?.summary?.value_at_risk || 0).toLocaleString('en-IN')}`}
          subtitle="Potential loss"
          icon={IndianRupee}
          color="danger"
          delay={0.3}
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Decay Trend Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="lg:col-span-2 bg-white rounded-2xl p-6 border border-gray-200 shadow-sm"
        >
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-900">
            <TrendingUp className="w-5 h-5 text-primary-500" />
            Decay Trend (14 Days)
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis 
                  dataKey="date" 
                  stroke="#9ca3af"
                  tick={{ fill: '#6b7280', fontSize: 12 }}
                  tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                />
                <YAxis stroke="#9ca3af" tick={{ fill: '#6b7280', fontSize: 12 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="avg_decay"
                  stroke={COLORS.primary}
                  strokeWidth={2}
                  dot={{ fill: COLORS.primary, strokeWidth: 2 }}
                  name="Avg Decay %"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Grade Distribution */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm"
        >
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-900">
            <BarChart3 className="w-5 h-5 text-accent-500" />
            Quality Grades
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={gradeData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {gradeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-4 mt-4">
            {gradeData.map((item) => (
              <div key={item.name} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-xs text-gray-600">{item.name}: {item.value}</span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Category Breakdown */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="lg:col-span-2 bg-white rounded-2xl p-6 border border-gray-200 shadow-sm"
        >
          <h3 className="text-lg font-semibold mb-4 text-gray-900">Inventory by Category</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categoryData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis type="number" stroke="#9ca3af" tick={{ fill: '#6b7280', fontSize: 12 }} />
                <YAxis dataKey="name" type="category" stroke="#9ca3af" tick={{ fill: '#6b7280', fontSize: 12 }} width={80} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                  }}
                />
                <Bar dataKey="count" name="Batches" radius={[0, 4, 4, 0]}>
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color || COLORS.primary} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Recent Alerts */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
          className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm"
        >
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-900">
            <AlertTriangle className="w-5 h-5 text-orange-500" />
            Recent Alerts
          </h3>
          <div className="space-y-3 max-h-64 overflow-y-auto">
            {alerts.length > 0 ? (
              alerts.map((alert, index) => (
                <AlertCard key={alert.alert_id} alert={alert} index={index} />
              ))
            ) : (
              <p className="text-gray-500 text-center py-8">No active alerts</p>
            )}
          </div>
        </motion.div>
      </div>

      {/* Risk Summary */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
        className="bg-gradient-to-r from-primary-500/10 to-accent-500/10 rounded-2xl p-6 border border-primary-500/20"
      >
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold mb-2">Risk Summary</h3>
            <div className="flex items-center gap-8">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-danger-500 animate-pulse" />
                <span className="text-sm">{metrics?.risk_breakdown?.critical || 0} Critical</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-warning-500" />
                <span className="text-sm">{metrics?.risk_breakdown?.high || 0} High Risk</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-yellow-500" />
                <span className="text-sm">{metrics?.risk_breakdown?.medium || 0} Medium</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-success-500" />
                <span className="text-sm">{metrics?.risk_breakdown?.healthy || 0} Healthy</span>
              </div>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-400">Action Required</p>
            <p className="text-2xl font-bold text-warning-400">
              {(metrics?.risk_breakdown?.critical || 0) + (metrics?.risk_breakdown?.high || 0)} items
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default Dashboard;

