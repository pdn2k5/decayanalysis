import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Upload, FileText, Check, X, RefreshCw, Database, Package, Thermometer, Camera, Image } from 'lucide-react';
import { uploadProducts, uploadInventory, uploadSensors, uploadProductImage, flushAllData, getDataStats, getUploadHistory } from '../services/api';

function DataUpload() {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const [flushing, setFlushing] = useState(false);
  const [uploadStatus, setUploadStatus] = useState(null);
  const [dataStats, setDataStats] = useState({ total_batches: 0, total_alerts: 0 });
  const fileInputRef = useRef(null);
  const [uploadType, setUploadType] = useState('products');

  useEffect(() => {
    fetchHistory();
    fetchDataStats();
  }, []);

  const fetchDataStats = async () => {
    try {
      const stats = await getDataStats();
      setDataStats(stats);
    } catch (error) {
      console.error('Failed to fetch data stats:', error);
    }
  };

  const handleFlushData = async () => {
    if (!window.confirm('⚠️ WARNING: This will permanently delete ALL data including products, inventory, and alerts. Are you sure?')) {
      return;
    }
    
    setFlushing(true);
    setUploadStatus(null);
    
    try {
      const result = await flushAllData();
      setUploadStatus({ success: true, message: 'All data flushed successfully! You can now upload fresh data.' });
      await fetchDataStats();
      await fetchHistory();
    } catch (error) {
      setUploadStatus({ success: false, message: error.message || 'Failed to flush data' });
    }
    
    setFlushing(false);
  };

  const fetchHistory = async () => {
    try {
      const result = await getUploadHistory(20);
      setHistory(result.uploads || []);
    } catch (error) {
      console.error('Failed to fetch history:', error);
    }
  };

  const [imageAnalysis, setImageAnalysis] = useState(null);
  const [selectedBatchId, setSelectedBatchId] = useState('');

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setLoading(true);
    setUploadStatus(null);
    setImageAnalysis(null);

    try {
      let result;
      switch (uploadType) {
        case 'products':
          result = await uploadProducts(file);
          break;
        case 'inventory':
          result = await uploadInventory(file);
          break;
        case 'sensors':
          result = await uploadSensors(file);
          break;
        case 'images':
          if (!selectedBatchId) {
            throw new Error('Please enter a Batch ID for the image');
          }
          result = await uploadProductImage(file, selectedBatchId, 'shelf');
          setImageAnalysis(result.analysis);
          break;
        default:
          throw new Error('Invalid upload type');
      }
      setUploadStatus({ success: true, ...result });
      await fetchHistory();
      await fetchDataStats();
    } catch (error) {
      setUploadStatus({ success: false, message: error.message || 'Upload failed' });
    }

    setLoading(false);
    event.target.value = '';
  };

  const uploadTypes = [
    { id: 'products', label: 'Products', icon: Package, description: 'Product catalog and metadata' },
    { id: 'inventory', label: 'Inventory', icon: Database, description: 'Inventory batches and quantities' },
    { id: 'sensors', label: 'Sensors', icon: Thermometer, description: 'IoT sensor readings' },
    { id: 'images', label: 'Product Images', icon: Camera, description: 'Images for visual decay analysis' }
  ];

  return (
    <div className="space-y-6 relative">
      {/* Flush Data - Small Red Dot (Top Right Corner) */}
      <button
        onClick={handleFlushData}
        disabled={flushing}
        className="absolute top-0 right-0 w-4 h-4 bg-red-500 hover:bg-red-600 rounded-full transition-all hover:scale-125 disabled:opacity-50 shadow-sm"
        title="Flush All Data"
      >
        {flushing && (
          <RefreshCw className="w-2 h-2 text-white animate-spin absolute top-1 left-1" />
        )}
      </button>

      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gradient">Data Upload</h1>
        <p className="text-gray-600 mt-1">Import data from CSV files</p>
      </div>

      {/* Data Stats Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm"
      >
        <h3 className="text-lg font-semibold mb-4 text-gray-900">Current Data Status</h3>
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-gray-50 rounded-xl p-4">
            <p className="text-3xl font-bold text-primary-600">{dataStats.total_products || 0}</p>
            <p className="text-sm text-gray-600">Products</p>
          </div>
          <div className="bg-gray-50 rounded-xl p-4">
            <p className="text-3xl font-bold text-accent-600">{dataStats.total_batches}</p>
            <p className="text-sm text-gray-600">Batches</p>
          </div>
          <div className="bg-gray-50 rounded-xl p-4">
            <p className="text-3xl font-bold text-orange-600">{dataStats.total_alerts}</p>
            <p className="text-sm text-gray-600">Alerts</p>
          </div>
        </div>
      </motion.div>

      {/* Upload Type Selection */}
      <div className="grid grid-cols-3 gap-4">
        {uploadTypes.map((type) => (
          <motion.button
            key={type.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            onClick={() => setUploadType(type.id)}
            className={`p-5 rounded-xl border transition-all text-left ${
              uploadType === type.id
                ? 'bg-primary-50 border-primary-300 shadow-sm'
                : 'bg-white border-gray-200 hover:border-primary-200 hover:bg-gray-50'
            }`}
          >
            <type.icon className={`w-8 h-8 mb-3 ${
              uploadType === type.id ? 'text-primary-600' : 'text-gray-400'
            }`} />
            <h4 className="font-medium text-gray-900">{type.label}</h4>
            <p className="text-sm text-gray-500 mt-1">{type.description}</p>
          </motion.button>
        ))}
      </div>

      {/* Batch ID Input for Image Upload */}
      {uploadType === 'images' && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm"
        >
          <h3 className="text-lg font-semibold mb-4 text-gray-900">Image Details</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Batch ID <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={selectedBatchId}
                onChange={(e) => setSelectedBatchId(e.target.value)}
                placeholder="e.g., BATCH-1001"
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 text-gray-900"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Image Type
              </label>
              <select className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary-500 text-gray-900">
                <option value="shelf">On Shelf (Retail Display)</option>
                <option value="backroom">Backroom Storage</option>
              </select>
            </div>
          </div>
          <p className="text-sm text-gray-500 mt-4">
            📸 Upload product images for AI-powered visual spoilage analysis. The analysis results will be used to adjust shelf life predictions.
          </p>
        </motion.div>
      )}

      {/* File Upload Area */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-2xl p-8 border-2 border-dashed border-gray-300 text-center shadow-sm"
      >
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileUpload}
          accept={uploadType === 'images' ? '.jpg,.jpeg,.png,.webp' : '.csv'}
          className="hidden"
        />
        
        {uploadType === 'images' ? (
          <Camera className="w-12 h-12 mx-auto text-gray-400 mb-4" />
        ) : (
          <Upload className="w-12 h-12 mx-auto text-gray-400 mb-4" />
        )}
        <h3 className="text-lg font-medium mb-2 text-gray-900">
          Upload {uploadTypes.find(t => t.id === uploadType)?.label} {uploadType === 'images' ? '' : 'CSV'}
        </h3>
        <p className="text-sm text-gray-500 mb-4">
          {uploadType === 'images' 
            ? 'Upload JPG, PNG, or WEBP images for visual decay analysis'
            : 'Drag and drop your CSV file here, or click to browse'
          }
        </p>
        <button
          onClick={() => fileInputRef.current?.click()}
          disabled={loading || (uploadType === 'images' && !selectedBatchId)}
          className="px-6 py-3 bg-primary-500 hover:bg-primary-600 text-white rounded-xl transition-colors disabled:opacity-50"
        >
          {loading ? (
            <span className="flex items-center gap-2">
              <RefreshCw className="w-4 h-4 animate-spin" />
              {uploadType === 'images' ? 'Analyzing...' : 'Uploading...'}
            </span>
          ) : (
            'Select File'
          )}
        </button>
      </motion.div>

      {/* Image Analysis Results */}
      {imageAnalysis && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-gradient-to-r from-primary-50 to-accent-50 rounded-2xl p-6 border border-primary-200 shadow-sm"
        >
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-900">
            <Image className="w-5 h-5 text-primary-600" />
            Visual Decay Analysis Results
          </h3>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="bg-white rounded-xl p-4">
              <p className="text-sm text-gray-500">Visual Quality Score</p>
              <p className="text-2xl font-bold text-primary-600">{imageAnalysis.quality_score?.toFixed(1)}%</p>
            </div>
            <div className="bg-white rounded-xl p-4">
              <p className="text-sm text-gray-500">RSL Adjustment</p>
              <p className="text-2xl font-bold text-accent-600">{imageAnalysis.rsl_adjustment_factor?.toFixed(2)}x</p>
            </div>
          </div>
          <div className="bg-white rounded-xl p-4">
            <p className="text-sm font-medium text-gray-700 mb-2">Detected Spoilage Indicators:</p>
            <div className="flex flex-wrap gap-2">
              {imageAnalysis.spoilage_indicators?.map((indicator, idx) => (
                <span key={idx} className="px-3 py-1 bg-orange-100 text-orange-700 rounded-full text-sm">
                  {indicator}
                </span>
              )) || <span className="text-gray-500">None detected</span>}
            </div>
          </div>
          <p className="text-xs text-gray-500 mt-4">
            ⚠️ This analysis adjusts the calculated Remaining Shelf Life (RSL) based on visual inspection.
          </p>
        </motion.div>
      )}

      {/* Upload Status */}
      {uploadStatus && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className={`p-4 rounded-xl ${
            uploadStatus.success
              ? 'bg-green-50 border border-green-200'
              : 'bg-red-50 border border-red-200'
          }`}
        >
          <div className="flex items-center gap-3">
            {uploadStatus.success ? (
              <Check className="w-5 h-5 text-green-600" />
            ) : (
              <X className="w-5 h-5 text-red-600" />
            )}
            <div>
              <p className={`font-medium ${uploadStatus.success ? 'text-green-700' : 'text-red-700'}`}>
                {uploadStatus.message || (uploadStatus.success ? 'Upload successful!' : 'Upload failed')}
              </p>
              {uploadStatus.processed !== undefined && (
                <p className="text-sm text-gray-600 mt-1">
                  Processed: {uploadStatus.processed} | Failed: {uploadStatus.failed || 0}
                </p>
              )}
            </div>
          </div>
        </motion.div>
      )}

      {/* Expected CSV Format */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm"
      >
        <h3 className="text-lg font-semibold mb-4 text-gray-900">Expected CSV Format</h3>
        <div className="bg-gray-100 rounded-xl p-4 font-mono text-sm overflow-x-auto text-gray-700">
          {uploadType === 'products' && (
            <pre>product_id,name,category,unit_price,unit_cost,packaging_type,base_shelf_life_days,optimal_temp_min,optimal_temp_max,optimal_humidity_min,optimal_humidity_max,supplier{'\n'}PRD-DRY-001,Amul Taza Milk,Dairy,60,35,Tetra Pack,7,2,4,60,70,Supplier_A</pre>
          )}
          {uploadType === 'inventory' && (
            <pre>batch_id,product_id,quantity,manufacture_date,received_date,location,supplier,handling_events,cold_chain_breaks,transport_days,temperature,humidity{'\n'}BATCH-1001,PRD-DRY-001,150,2024-12-01,2024-12-02,Warehouse Delhi,Supplier_A,2,0,1.0,3.5,65</pre>
          )}
          {uploadType === 'sensors' && (
            <pre>sensor_id,batch_id,product_id,temperature,humidity,timestamp,location,alert_triggered{'\n'}SENSOR-WH-DEL-01,BATCH-1001,PRD-DRY-001,3.5,65.0,2024-12-05T08:00:00,Warehouse Delhi,false</pre>
          )}
        </div>
      </motion.div>

      {/* Upload History */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm"
      >
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-900">
          <FileText className="w-5 h-5 text-accent-500" />
          Upload History
        </h3>
        <div className="space-y-3 max-h-64 overflow-y-auto">
          {history.length === 0 ? (
            <p className="text-gray-500 text-center py-4">No upload history</p>
          ) : (
            history.map((upload) => (
              <div
                key={upload.id}
                className="flex items-center justify-between p-3 bg-gray-50 rounded-xl"
              >
                <div className="flex items-center gap-3">
                  <FileText className="w-4 h-4 text-gray-400" />
                  <div>
                    <p className="font-medium text-sm text-gray-900">{upload.filename}</p>
                    <p className="text-xs text-gray-500">
                      {upload.upload_type} • {upload.records_processed} records
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <span className={`text-xs px-2 py-1 rounded ${
                    upload.status === 'success'
                      ? 'bg-green-100 text-green-700'
                      : upload.status === 'partial'
                      ? 'bg-yellow-100 text-yellow-700'
                      : 'bg-red-100 text-red-700'
                  }`}>
                    {upload.status}
                  </span>
                  <p className="text-xs text-gray-500 mt-1">
                    {new Date(upload.uploaded_at).toLocaleString()}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>
      </motion.div>
    </div>
  );
}

export default DataUpload;
