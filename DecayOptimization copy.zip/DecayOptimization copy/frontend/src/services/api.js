import axios from 'axios';

// Use environment variable or default to localhost:8000 for the backend
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api/v1';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// ============ PREDICTIONS ============

export const predictDecay = async (batchId, includeExplanation = true) => {
  const response = await api.post('/predictions/decay', {
    batch_id: batchId,
    include_explanation: includeExplanation,
  });
  return response.data;
};

export const predictDecayManual = async (data) => {
  const response = await api.post('/predictions/decay/manual', data);
  return response.data;
};

export const getShelfLife = async (batchId) => {
  const response = await api.get(`/predictions/shelf-life/${batchId}`);
  return response.data;
};

export const getPredictionsSummary = async () => {
  const response = await api.get('/predictions/summary');
  return response.data;
};

// ============ INVENTORY ============

export const getProducts = async (category = null) => {
  const params = category ? { category } : {};
  const response = await api.get('/inventory/products', { params });
  return response.data;
};

export const getBatches = async (filters = {}) => {
  const response = await api.get('/inventory/batches', { params: filters });
  return response.data;
};

export const getBatchDetails = async (batchId) => {
  const response = await api.get(`/inventory/batches/${batchId}`);
  return response.data;
};

export const updateBatchStatus = async (batchId, status) => {
  const response = await api.patch(`/inventory/batches/${batchId}/status`, null, {
    params: { status },
  });
  return response.data;
};

export const getInventorySummary = async () => {
  const response = await api.get('/inventory/summary');
  return response.data;
};

export const getLocations = async () => {
  const response = await api.get('/inventory/locations');
  return response.data;
};

// ============ ALERTS ============

export const getAlerts = async (filters = {}) => {
  const response = await api.get('/alerts/', { params: filters });
  return response.data;
};

export const getAlertsSummary = async () => {
  const response = await api.get('/alerts/summary');
  return response.data;
};

export const acknowledgeAlert = async (alertId, user) => {
  const response = await api.post(`/alerts/${alertId}/acknowledge`, { user });
  return response.data;
};

export const dismissAlert = async (alertId) => {
  const response = await api.delete(`/alerts/${alertId}`);
  return response.data;
};

export const getAlertVoice = async (alertId) => {
  const response = await api.get(`/alerts/${alertId}/voice/base64`);
  return response.data;
};

export const createTestAlert = async (severity = 'HIGH', message = 'Test alert') => {
  const response = await api.post('/alerts/test', null, {
    params: { severity, message },
  });
  return response.data;
};

// ============ ANALYTICS ============

export const getDashboardMetrics = async () => {
  const response = await api.get('/analytics/dashboard');
  return response.data;
};

export const getDecayTrends = async (days = 30, category = null) => {
  const params = { days };
  if (category) params.category = category;
  const response = await api.get('/analytics/trends', { params });
  return response.data;
};

export const getWasteAnalysis = async (days = 30) => {
  const response = await api.get('/analytics/waste-analysis', { params: { days } });
  return response.data;
};

export const getMarkdownRecommendations = async (limit = 20) => {
  const response = await api.get('/analytics/markdown-recommendations', { params: { limit } });
  return response.data;
};

export const getTemperatureMonitoring = async (hours = 24, location = null) => {
  const params = { hours };
  if (location) params.location = location;
  const response = await api.get('/analytics/temperature-monitoring', { params });
  return response.data;
};

export const getDailyReport = async (date = null) => {
  const params = date ? { date } : {};
  const response = await api.get('/analytics/report/daily', { params });
  return response.data;
};

// ============ UPLOAD ============

export const uploadProducts = async (file) => {
  const formData = new FormData();
  formData.append('file', file);
  const response = await api.post('/upload/products', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return response.data;
};

export const uploadInventory = async (file) => {
  const formData = new FormData();
  formData.append('file', file);
  const response = await api.post('/upload/inventory', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return response.data;
};

export const uploadSensors = async (file) => {
  const formData = new FormData();
  formData.append('file', file);
  const response = await api.post('/upload/sensors', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return response.data;
};

export const uploadProductImage = async (file, batchId, imageType = 'shelf') => {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('batch_id', batchId);
  const response = await api.post(`/images/upload/${imageType}`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return response.data;
};

export const loadSampleData = async () => {
  const response = await api.post('/upload/sample-data');
  return response.data;
};

export const flushAllData = async () => {
  const response = await api.post('/upload/flush-data');
  return response.data;
};

export const getDataStats = async () => {
  const response = await api.get('/upload/data-stats');
  return response.data;
};

export const getUploadHistory = async (limit = 20) => {
  const response = await api.get('/upload/history', { params: { limit } });
  return response.data;
};

// ============ VOICE ============

export const getVoiceStatus = async () => {
  const response = await api.get('/voice/status');
  return response.data;
};

export const textToSpeech = async (text, filename = null) => {
  const response = await api.post('/voice/speak/base64', { text, filename });
  return response.data;
};

export const voiceDailySummary = async (data) => {
  const response = await api.post('/voice/daily-summary/base64', data);
  return response.data;
};

export const testVoice = async () => {
  const response = await api.get('/voice/test');
  return response.data;
};

// ============ ASSISTANT ============

export const queryAssistant = async (query, includeVoice = false) => {
  const response = await api.post('/assistant/query', {
    query,
    include_voice: includeVoice,
  });
  return response.data;
};

export const getExplanation = async (batchId) => {
  const response = await api.post('/assistant/explain', { batch_id: batchId });
  return response.data;
};

export const getRootCauseAnalysis = async (batchId) => {
  const response = await api.post('/assistant/root-cause', { batch_id: batchId });
  return response.data;
};

export const getAssistantStatus = async () => {
  const response = await api.get('/assistant/status');
  return response.data;
};

export const getInsights = async () => {
  const response = await api.get('/assistant/insights');
  return response.data;
};

export const chat = async (message, sessionId = null) => {
  const response = await api.post('/assistant/chat', null, {
    params: { message, session_id: sessionId },
  });
  return response.data;
};

// ============ HEALTH ============

export const checkHealth = async () => {
  const healthUrl = import.meta.env.VITE_API_URL 
    ? import.meta.env.VITE_API_URL.replace('/api/v1', '/health')
    : 'http://localhost:8000/health';
  const response = await axios.get(healthUrl);
  return response.data;
};

export default api;

