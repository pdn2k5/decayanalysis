import React, { useState, useRef, useEffect } from 'react';
import { Volume2, VolumeX, Mic, Square } from 'lucide-react';
import { testVoice, textToSpeech } from '../services/api';

function VoicePlayer() {
  const [isEnabled, setIsEnabled] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const [voiceStatus, setVoiceStatus] = useState(null);
  const audioRef = useRef(null);

  useEffect(() => {
    checkVoiceStatus();
  }, []);

  const checkVoiceStatus = async () => {
    try {
      const status = await testVoice();
      setVoiceStatus(status);
      setIsEnabled(status.enabled && status.test_successful);
    } catch (error) {
      setVoiceStatus({ enabled: false });
      setIsEnabled(false);
    }
  };

  const playAudio = async (base64Audio) => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
    }

    const audioBlob = base64ToBlob(base64Audio, 'audio/mp3');
    const audioUrl = URL.createObjectURL(audioBlob);
    
    audioRef.current.src = audioUrl;
    audioRef.current.onended = () => setIsPlaying(false);
    audioRef.current.onerror = () => setIsPlaying(false);
    
    setIsPlaying(true);
    await audioRef.current.play();
  };

  const stopAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    setIsPlaying(false);
  };

  const base64ToBlob = (base64, mimeType) => {
    const byteCharacters = atob(base64);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    return new Blob([byteArray], { type: mimeType });
  };

  const testVoicePlayback = async () => {
    try {
      const result = await testVoice();
      if (result.test_successful && result.audio_base64) {
        await playAudio(result.audio_base64);
      }
    } catch (error) {
      console.error('Voice test failed:', error);
    }
  };

  // Expose playAudio globally for other components
  useEffect(() => {
    window.playVoiceAlert = playAudio;
    window.stopVoiceAlert = stopAudio;
    return () => {
      delete window.playVoiceAlert;
      delete window.stopVoiceAlert;
    };
  }, []);

  return (
    <div className="bg-dark-700/50 rounded-xl p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          {isEnabled ? (
            <Volume2 className="w-4 h-4 text-primary-400" />
          ) : (
            <VolumeX className="w-4 h-4 text-gray-500" />
          )}
          <span className="text-sm font-medium">Voice Alerts</span>
        </div>
        <button
          onClick={() => setIsEnabled(!isEnabled)}
          className={`w-10 h-5 rounded-full transition-colors ${
            isEnabled ? 'bg-primary-500' : 'bg-gray-600'
          }`}
        >
          <div
            className={`w-4 h-4 rounded-full bg-white shadow-md transform transition-transform ${
              isEnabled ? 'translate-x-5' : 'translate-x-0.5'
            }`}
          />
        </button>
      </div>

      {isPlaying && (
        <div className="flex items-center justify-between bg-primary-500/20 rounded-lg p-2 mb-3">
          <div className="voice-wave">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
          </div>
          <button
            onClick={stopAudio}
            className="p-1.5 bg-danger-500/20 rounded-lg hover:bg-danger-500/30 transition-colors"
          >
            <Square className="w-3 h-3 text-danger-400" />
          </button>
        </div>
      )}

      <button
        onClick={testVoicePlayback}
        disabled={!isEnabled || isPlaying}
        className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-white/5 hover:bg-white/10 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
      >
        <Mic className="w-4 h-4" />
        <span className="text-sm">Test Voice</span>
      </button>
    </div>
  );
}

export default VoicePlayer;

