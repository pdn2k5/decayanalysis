import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard,
  Package,
  Bell,
  TrendingUp,
  Upload,
  Thermometer,
  MessageSquare,
  Volume2,
  Menu,
  X,
  Activity,
  Leaf,
  Tag
} from 'lucide-react';

// Custom Indian Rupee Icon for Markdown/Pricing
const PriceTag = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M6 3h12" />
    <path d="M6 8h12" />
    <path d="M6 13l8.5 8" />
    <path d="M6 13h3c3.5 0 6-2.5 6-5H6" />
  </svg>
);

// Pages
import Dashboard from './pages/Dashboard';
import Inventory from './pages/Inventory';
import Alerts from './pages/Alerts';
import Markdown from './pages/Markdown';
import ColdChain from './pages/ColdChain';
import DataUpload from './pages/DataUpload';
import Assistant from './pages/Assistant';

// Components
import VoicePlayer from './components/VoicePlayer';

const navItems = [
  { path: '/', icon: LayoutDashboard, label: 'Dashboard' },
  { path: '/inventory', icon: Package, label: 'Inventory' },
  { path: '/alerts', icon: Bell, label: 'Alerts' },
  { path: '/markdown', icon: PriceTag, label: 'Markdown' },
  { path: '/cold-chain', icon: Thermometer, label: 'Cold Chain' },
  { path: '/upload', icon: Upload, label: 'Data Upload' },
  { path: '/assistant', icon: MessageSquare, label: 'AI Assistant' },
];

function Sidebar({ isOpen, setIsOpen }) {
  const location = useLocation();

  return (
    <>
      {/* Mobile overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={() => setIsOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <motion.aside
        className={`fixed top-0 left-0 h-full w-64 bg-white border-r border-gray-200 z-50 transform transition-transform duration-300 lg:translate-x-0 shadow-lg ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Logo */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary-500 to-accent-500 flex items-center justify-center">
              <Leaf className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-lg text-gradient">Decay AI</h1>
              <p className="text-xs text-gray-500">Optimization Platform</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="p-4 space-y-2">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setIsOpen(false)}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                  isActive
                    ? 'bg-gradient-to-r from-primary-100 to-accent-100 text-primary-600 border border-primary-200'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                }`}
              >
                <item.icon className={`w-5 h-5 ${isActive ? 'text-primary-600' : ''}`} />
                <span className="font-medium">{item.label}</span>
                {item.path === '/alerts' && (
                  <span className="ml-auto w-2 h-2 rounded-full bg-danger-500 animate-pulse" />
                )}
              </Link>
            );
          })}
        </nav>

        {/* Voice Control */}
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-200">
          <VoicePlayer />
        </div>
      </motion.aside>
    </>
  );
}

function Header({ setIsOpen }) {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-gray-200 shadow-sm">
      <div className="flex items-center justify-between px-6 py-4">
        <div className="flex items-center gap-4">
          <button
            onClick={() => setIsOpen(true)}
            className="lg:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <Menu className="w-6 h-6 text-gray-700" />
          </button>
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-accent-500" />
            <span className="text-sm text-gray-600 font-medium">System Online</span>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="text-right">
            <p className="text-sm font-medium text-gray-900">
              {time.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
            </p>
            <p className="text-xs text-gray-500">{time.toLocaleTimeString()}</p>
          </div>
        </div>
      </div>
    </header>
  );
}

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <Sidebar isOpen={sidebarOpen} setIsOpen={setSidebarOpen} />

      <div className="lg:ml-64">
        <Header setIsOpen={setSidebarOpen} />

        <main className="p-6">
          <AnimatePresence mode="wait">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/inventory" element={<Inventory />} />
              <Route path="/alerts" element={<Alerts />} />
              <Route path="/markdown" element={<Markdown />} />
              <Route path="/cold-chain" element={<ColdChain />} />
              <Route path="/upload" element={<DataUpload />} />
              <Route path="/assistant" element={<Assistant />} />
            </Routes>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}

export default App;

