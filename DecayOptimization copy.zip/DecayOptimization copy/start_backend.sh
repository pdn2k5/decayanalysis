#!/bin/bash

echo "========================================"
echo " DECAY OPTIMIZATION PLATFORM - BACKEND"
echo "========================================"
echo ""

# Get the directory where the script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR/backend"

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is not installed"
    echo "Please install Python 3.9+ using: brew install python3"
    exit 1
fi

echo "Python version: $(python3 --version)"

# Create virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
source venv/bin/activate

# Install dependencies
echo "Installing dependencies..."
pip install -r requirements.txt --quiet

# Create .env if not exists
if [ ! -f ".env" ]; then
    echo "Creating .env from template..."
    cp env_template.txt .env
    echo ""
    echo "IMPORTANT: Edit .env file to configure your LLM settings"
    echo ""
fi

# Create necessary directories
mkdir -p static/audio
mkdir -p data/sample_datasets
mkdir -p ml_models/saved

echo ""
echo "Starting FastAPI backend server..."
echo "API Documentation: http://localhost:8000/api/docs"
echo ""

python3 main.py

