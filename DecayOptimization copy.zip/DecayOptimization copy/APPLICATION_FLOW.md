# 🥬 Decay Optimization Platform - Application Flow Guide

## Overview

The Decay Optimization Platform is an AI-powered solution for managing perishable goods inventory in retail environments. It helps prevent food waste and maximize revenue by predicting product decay, recommending optimal pricing, and providing actionable insights.

---

## 📚 Key Terminology

### 1. **Decay Score** (0-100%)
The **Decay Score** represents the current deterioration level of a perishable product.

| Score Range | Meaning | Product State |
|-------------|---------|---------------|
| 0-30% | Fresh | Product in optimal condition |
| 31-50% | Good | Minor quality reduction, still sellable at full price |
| 51-70% | Declining | Noticeable quality loss, consider markdown |
| 71-90% | Critical | Significant deterioration, urgent markdown needed |
| 91-100% | Expired | Product no longer suitable for sale |

**Factors affecting Decay Score:**
- Storage temperature deviation from optimal range
- Humidity levels
- Time since manufacture/receipt
- Cold chain breaks (temperature excursions during transport)
- Number of handling events

### 2. **Shelf Life / RSL (Remaining Shelf Life)**
The estimated number of days/hours until a product reaches the end of its usable life.

- **Base Shelf Life**: Maximum days a product category can last under optimal conditions
  - Dairy: 14 days
  - Fruits: 10 days
  - Vegetables: 7 days
  - Meat: 5 days

- **RSL Calculation**: Adjusted based on actual storage conditions
  - Temperature above optimal = faster decay
  - High humidity = variable effects by category
  - Cold chain breaks = significant shelf life reduction

### 3. **Quality Grade** (A, B, C, D, F)
A letter grade summarizing overall product quality:

| Grade | Decay Score | Meaning |
|-------|------------|---------|
| **A** | 0-20% | Excellent - Premium quality |
| **B** | 21-40% | Good - Standard quality |
| **C** | 41-60% | Fair - Acceptable, consider markdown |
| **D** | 61-80% | Poor - Urgent markdown required |
| **F** | 81-100% | Failed - Disposal/Donation |

### 4. **Markdown**
A price reduction applied to products to accelerate sales before they expire.

**Markdown Logic:**
- Grade C products: 10-20% discount
- Grade D products: 30-50% discount
- Critical items (<24h RSL): 50-70% discount

**Apply Markdown**: Confirms the markdown price and updates the product status in inventory.

### 5. **Cold Chain**
The temperature-controlled supply chain for perishable goods.

- **Cold Chain Monitoring**: Tracking temperature throughout storage/transport
- **Cold Chain Break**: When temperature exceeds safe limits (damages product quality)
- **Anomaly**: A temperature reading outside acceptable range

---

## 🔄 Application Flow

### Step 1: Data Upload
```
User → Data Upload Page → Upload CSVs (Products, Inventory, Sensors)
```

**Process:**
1. User uploads CSV files containing:
   - **Products**: Product catalog (name, category, base shelf life)
   - **Inventory**: Current batches (quantities, manufacture dates, locations)
   - **Sensors**: Temperature/humidity readings

2. System processes data and calculates:
   - RSL for each batch
   - Decay scores
   - Quality grades
   - Alerts for at-risk items

### Step 2: Dashboard Overview
```
Dashboard → Real-time metrics and alerts
```

**Displays:**
- Active batches count
- Average decay score
- At-risk items
- Value at risk (₹)
- Quality grade distribution
- Category breakdown

### Step 3: Inventory Management
```
Inventory → View/Filter → Predict → Explain
```

**Features:**
- Filter by category (Dairy, Fruits, Vegetables, Meat)
- Search by product name or batch ID
- **Predict**: Get AI-powered decay prediction
- **Explain**: Get detailed analysis of why product is decaying

### Step 4: Markdown Recommendations
```
Markdown Page → Review Recommendations → Apply Markdown
```

**Process:**
1. System identifies products needing markdown based on:
   - High decay score (>30%)
   - Low remaining shelf life (<5 days)
   - Urgency level (critical/high/medium/low)

2. AI calculates optimal discount percentage
3. User clicks **Apply** to confirm markdown
4. Inventory updated with new pricing

### Step 5: Cold Chain Monitoring
```
Cold Chain → View Temperature Data → Identify Anomalies
```

**Monitors:**
- Temperature readings over time
- Humidity levels
- Location-specific data
- Alert for temperature excursions

### Step 6: AI Assistant
```
AI Assistant → Ask Questions → Get Contextual Answers
```

**Capabilities:**
- Query inventory status
- Get markdown recommendations
- Analyze decay causes
- Generate reports

---

## 🤖 AI/ML/LLM Usage by Feature

### 1. **AI Assistant (LLM)**
**Technology:** Ollama (local) or External API (TCS GenAI Lab/OpenAI-compatible)

**Where Used:**
- Natural language query processing
- Contextual response generation
- Report generation
- Root cause analysis

**Example:**
```
User: "What products are expiring soon?"
LLM: Analyzes inventory data and provides detailed response with 
     specific products, quantities, and recommendations.
```

### 2. **Decay Prediction (LLM + Rules)**
**Technology:** LLM for analysis, rule-based algorithms for calculations

**Where Used:**
- Inventory page "Predict" button
- Real-time decay score calculation
- 24/48 hour prediction

**Process:**
1. Gather batch data (temperature, humidity, age, category)
2. Send to LLM for contextual analysis
3. Combine with rule-based decay formula
4. Return prediction with confidence score

### 3. **Explanation Generation (LLM)**
**Technology:** LLM with product context

**Where Used:**
- Inventory page "Explain" button
- Understanding why a product is decaying

**Process:**
1. Collect all batch parameters
2. Generate prompt with product context
3. LLM produces human-readable explanation
4. Include actionable recommendations

### 4. **Markdown Optimization (Algorithm)**
**Technology:** Multi-factor pricing algorithm

**Where Used:**
- Dynamic Pricing page
- Automatic markdown percentage calculation

**Formula considers:**
- Current decay score
- Remaining shelf life
- Inventory level (overstock = higher discount)
- Historical sales data

### 5. **RSL Calculation (Algorithm)**
**Technology:** Mathematical model with environmental factors

**Where Used:**
- All inventory data processing
- Expiry predictions

**Formula:**
```
RSL = Base_Shelf_Life × Temperature_Factor × Humidity_Factor × 
      Age_Factor × Cold_Chain_Factor × Logistics_Factor
```

### 6. **Alert Generation (Rules Engine)**
**Technology:** Rule-based system with configurable thresholds

**Where Used:**
- Dashboard alerts
- Email/notification triggers

**Rules:**
- Critical: Decay >80% OR RSL <1 day
- High: Decay >60% OR RSL <2 days
- Medium: Decay >40% OR RSL <4 days
- Low: Decay >20%

### 7. **Voice Summaries (TTS)**
**Technology:** pyttsx3 (offline) or gTTS (online)

**Where Used:**
- Dashboard "Voice Summary" button
- Audio alerts for critical items

---

## 📦 Example Walkthrough

### Scenario: Managing Dairy Products

**Day 1 - Data Upload:**
```
Upload: products.csv, inventory.csv, sensors.csv
System calculates RSL for 21 batches across 4 categories
```

**Day 2 - Dashboard Check:**
```
Dashboard shows:
- 6 Dairy batches
- Average decay: 45%
- 2 critical items (Amul Cheese, Britannia Butter)
- Value at Risk: ₹8,500
```

**Day 2 - Investigate Critical Item:**
```
Inventory → Filter: Dairy → Find: Amul Cheese Slice (BATCH-1003)
Decay: 85% | Grade: D | RSL: 0.5 days

Click "Explain" →
LLM Response: "This cheese slice batch has reached critical decay 
due to: (1) Storage temperature averaged 6.5°C (optimal: 2-4°C), 
(2) 2 cold chain breaks during transport, (3) Product age is 13 days 
of 14-day shelf life. Recommend: 65% markdown for immediate sale or 
donate to food bank within 24 hours."
```

**Day 2 - Apply Markdown:**
```
Markdown Page → Find BATCH-1003
Original Price: ₹100 | Recommended: 65% OFF | New Price: ₹35
Click "Apply" → Status updated to "markdown"
```

**Day 2 - Ask AI Assistant:**
```
Query: "How much revenue can we recover from dairy markdowns?"
Response: "Based on current markdown recommendations, you can 
recover approximately ₹15,400 from 3 dairy batches by applying 
suggested discounts. Without markdown, estimated waste value 
would be ₹24,000."
```

---

## 🔧 Technologies Summary

| Component | Technology | Purpose |
|-----------|------------|---------|
| Frontend | React + Vite | User interface |
| Backend | FastAPI (Python) | REST API |
| Database | SQLite + In-memory | Data storage |
| LLM | Ollama / LangChain | AI analysis |
| TTS | pyttsx3 | Voice features |
| Charts | Recharts | Data visualization |
| Styling | TailwindCSS | UI design |

---

## 🚀 Quick Start Checklist

1. ✅ Start backend: `python main.py`
2. ✅ Start frontend: `npm run dev`
3. ✅ Upload test data from Data Upload page
4. ✅ View Dashboard for overview
5. ✅ Check Inventory for details
6. ✅ Apply Markdowns for at-risk items
7. ✅ Use AI Assistant for insights
8. ✅ Monitor Cold Chain for temperature issues

---

*Document Version: 1.0 | Last Updated: December 2025*

