#!/bin/bash

echo "================================================================"
echo "       DECAY OPTIMIZATION PLATFORM - FULL STACK STARTUP"
echo "================================================================"
echo ""
echo "  AI-driven decay analysis and shelf-life prediction"
echo "  for perishable goods (Dairy, Fruits, Vegetables, Meat)"
echo ""
echo "================================================================"
echo ""

# Get the directory where the script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Function to check if a command exists
command_exists() {
    command -v "$1" &> /dev/null
}

# Check prerequisites
echo "Checking prerequisites..."

if ! command_exists python3; then
    echo "❌ Python 3 is not installed. Install with: brew install python3"
    exit 1
else
    echo "✅ Python 3: $(python3 --version)"
fi

if ! command_exists node; then
    echo "❌ Node.js is not installed. Install with: brew install node"
    exit 1
else
    echo "✅ Node.js: $(node --version)"
fi

echo ""

# Start backend in background
echo "Starting Backend Server..."
osascript -e "tell application \"Terminal\" to do script \"cd '$SCRIPT_DIR' && ./start_backend.sh\""

# Wait for backend to start
echo "Waiting for backend to initialize..."
sleep 5

# Start frontend in new terminal
echo "Starting Frontend Server..."
osascript -e "tell application \"Terminal\" to do script \"cd '$SCRIPT_DIR' && ./start_frontend.sh\""

echo ""
echo "================================================================"
echo " SERVERS STARTING..."
echo "================================================================"
echo ""
echo "  Backend API:     http://localhost:8000"
echo "  API Docs:        http://localhost:8000/api/docs"
echo "  Frontend:        http://localhost:3000"
echo ""
echo "================================================================"
echo ""

# Wait a bit more for frontend to start
sleep 5

# Open browser
echo "Opening browser..."
open http://localhost:3000

echo ""
echo "Press Ctrl+C to exit this script (servers will continue running)"

