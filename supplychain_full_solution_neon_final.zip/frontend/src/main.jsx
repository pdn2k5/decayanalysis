
import React from 'react'
import { createRoot } from 'react-dom/client'
import VisualPipeline from './components/VisualPipeline'
import './components/neon.css'

function App(){
  return <div style={{height:'100vh', padding:20, background:'#071025'}}><VisualPipeline/></div>
}

createRoot(document.getElementById('root')).render(<App />)
