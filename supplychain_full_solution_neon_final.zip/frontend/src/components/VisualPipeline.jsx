
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import './neon.css';

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000';

const NODES = [
  { id: 'collection', label: 'Collection (Edge)' },
  { id: 'transport', label: 'Transport (Truck)' },
  { id: 'fulfillment', label: 'Fulfillment (Grading)' },
  { id: 'distribution', label: 'Distribution (DC)' },
  { id: 'store_backroom', label: 'Store Backroom' },
  { id: 'store_shelf', label: 'Store Shelf' },
  { id: 'markdown', label: 'Markdown' },
  { id: 'hq', label: 'HQ / Reporting' }
];

export default function VisualPipeline(){
  const [batches, setBatches] = useState([]);
  const [selected, setSelected] = useState(null);
  const [createInputs, setCreateInputs] = useState({batch_id:'BATCH-'+Math.floor(Math.random()*9000+1000), commodity:'tomato', supplier_id:'FARM-112', temp:20, humidity:70});
  const [statusMsg, setStatusMsg] = useState('');

  useEffect(()=> { fetchBatches() }, []);

  async function fetchBatches(){
    try{
      const res = await axios.get(API_BASE + '/api/batches');
      setBatches(res.data);
    }catch(e){ console.error(e); setBatches([]); }
  }
  async function viewBatch(id){
    try{
      const res = await axios.get(API_BASE + '/api/batches/' + id);
      setSelected(res.data);
    }catch(e){ console.error(e); setSelected(null); }
  }

  function renderNode(nodeObj, idx){
    const isActive = selected && selected.batch && selected.batch.current_stage === nodeObj.id;
    return (
      <g key={nodeObj.id} transform={`translate(${idx*240},0)`} style={{cursor:'pointer'}} onClick={()=>{ }}>
        <rect x={10} y={10} rx={12} ry={12} width={220} height={80} className={isActive ? 'neon-node active' : 'neon-node'} />
        <text x={120} y={55} textAnchor="middle" alignmentBaseline="middle" className={isActive ? 'neon-text active' : 'neon-text'}>
          {nodeObj.label}
        </text>
      </g>
    );
  }

  async function actionCreate(){
    setStatusMsg('Creating batch on edge...');
    try{
      const form = new FormData();
      form.append('batch_id', createInputs.batch_id);
      form.append('commodity', createInputs.commodity);
      form.append('supplier_id', createInputs.supplier_id);
      form.append('temp', String(createInputs.temp));
      form.append('humidity', String(createInputs.humidity));
      await axios.post(API_BASE + '/api/edge/create', form);
      await fetchBatches();
      viewBatch(createInputs.batch_id);
      setStatusMsg('Batch created.');
    }catch(e){ console.error(e); setStatusMsg('Create failed.'); }
  }

  async function actionTransportSim(){
    if(!selected) return setStatusMsg('Select a batch first');
    const form = new FormData();
    form.append('batch_id', selected.batch.batch_id);
    form.append('event_type','temp_breach');
    form.append('temp', String(18));
    form.append('duration_min', String(20));
    setStatusMsg('Simulating transport breach...');
    await axios.post(API_BASE + '/api/transport/simulate', form);
    await fetchBatches(); viewBatch(selected.batch.batch_id);
    setStatusMsg('Transport simulated.');
  }

  async function actionGrade(){
    if(!selected) return setStatusMsg('Select a batch first');
    const form = new FormData(); form.append('batch_id', selected.batch.batch_id);
    setStatusMsg('Triggering fulfillment grading...');
    await axios.post(API_BASE + '/api/fulfillment/grade', form);
    await fetchBatches(); viewBatch(selected.batch.batch_id);
    setStatusMsg('Grading complete.');
  }

  async function actionRoute(){
    if(!selected) return setStatusMsg('Select a batch first');
    const form = new FormData(); form.append('batch_id', selected.batch.batch_id);
    setStatusMsg('Routing to DC...');
    await axios.post(API_BASE + '/api/dc/route', form);
    await fetchBatches(); viewBatch(selected.batch.batch_id);
    setStatusMsg('Routed to DC.');
  }

  async function actionMoveToStore(){
    if(!selected) return setStatusMsg('Select a batch first');
    const form = new FormData(); form.append('batch_id', selected.batch.batch_id);
    setStatusMsg('Moving to store backroom...');
    await axios.post(API_BASE + '/api/store/move', form);
    await fetchBatches(); viewBatch(selected.batch.batch_id);
    setStatusMsg('Moved to store.');
  }

  async function actionMoveToShelf(){
    if(!selected) return setStatusMsg('Select a batch first');
    const form = new FormData(); form.append('batch_id', selected.batch.batch_id);
    setStatusMsg('Moving to shelf...');
    await axios.post(API_BASE + '/api/store/move_shelf', form);
    await fetchBatches(); viewBatch(selected.batch.batch_id);
    setStatusMsg('Moved to shelf.');
  }

  async function actionSpoilage(){
    if(!selected) return setStatusMsg('Select a batch first');
    const form = new FormData(); form.append('batch_id', selected.batch.batch_id);
    setStatusMsg('Running spoilage detection...');
    await axios.post(API_BASE + '/api/store/spoilage_detect', form);
    await fetchBatches(); viewBatch(selected.batch.batch_id);
    setStatusMsg('Spoilage check done.');
  }

  async function actionMarkdown(){
    if(!selected) return setStatusMsg('Select a batch first');
    const form = new FormData(); form.append('batch_id', selected.batch.batch_id);
    setStatusMsg('Applying markdown...');
    const res = await axios.post(API_BASE + '/api/store/markdown', form);
    await fetchBatches(); viewBatch(selected.batch.batch_id);
    setStatusMsg('Markdown applied: ' + (res.data.markdown_percent || res.data.markdown || 'NA') + '%');
  }

  async function actionHQ(){
    if(!selected) return setStatusMsg('Generating HQ report...');
    const form = new FormData(); form.append('batch_id', selected.batch.batch_id);
    const res = await axios.post(API_BASE + '/api/hq/report', form);
    setStatusMsg('HQ Report: ' + JSON.stringify(res.data));
  }

  return (
    <Box display='flex' gap={2}>
      <Paper style={{width:380,padding:16, background:'#fff'}} elevation={3}>
        <Typography variant='h6'>Batches</Typography>
        <List dense>
          {batches.map(b => (
            <ListItem key={b.batch_id} button onClick={()=>viewBatch(b.batch_id)}>
              <ListItemText primary={b.batch_id} secondary={`${b.commodity} — RSL ${b.current_rsl_hours}h`} />
            </ListItem>
          ))}
        </List>
        <Button variant='outlined' onClick={fetchBatches} style={{marginBottom:8}}>Refresh</Button>
        <Box mt={2}>
          <Typography variant='subtitle2'>Create New Batch (Edge)</Typography>
          <Stack spacing={1} mt={1}>
            <TextField size='small' label='Batch ID' value={createInputs.batch_id} onChange={(e)=>setCreateInputs({...createInputs, batch_id:e.target.value})} />
            <TextField size='small' label='Commodity' value={createInputs.commodity} onChange={(e)=>setCreateInputs({...createInputs, commodity:e.target.value})} />
            <TextField size='small' label='Supplier' value={createInputs.supplier_id} onChange={(e)=>setCreateInputs({...createInputs, supplier_id:e.target.value})} />
            <TextField size='small' label='Temp (°C)' value={createInputs.temp} onChange={(e)=>setCreateInputs({...createInputs, temp: Number(e.target.value)})} />
            <TextField size='small' label='Humidity (%)' value={createInputs.humidity} onChange={(e)=>setCreateInputs({...createInputs, humidity: Number(e.target.value)})} />
            <Button variant='contained' onClick={actionCreate}>Create Batch on Edge</Button>
          </Stack>
        </Box>
      </Paper>

      <Paper style={{flex:1,padding:16, background:'#0b0f19', color:'#e6f3ff'}} elevation={0}>
        <Typography variant='h6' style={{color:'#bfefff'}}>Neon Cyber-Grid Pipeline</Typography>
        <Box mt={2} style={{overflowX:'auto', padding:12, background:'#051022', borderRadius:12}}>
          <svg width={NODES.length * 260} height={140}>
            {NODES.map((n, idx) => renderNode(n, idx))}
            {NODES.slice(0,-1).map((_,i) => (
              <g key={'arrow-'+i} transform={`translate(${i*240 + 240},60)`}>
                <line x1={0} y1={0} x2={60} y2={0} stroke="#3de0ff" strokeWidth={2} strokeOpacity={0.35}/>
                <polygon points="60,-6 70,0 60,6" fill="#3de0ff" opacity={0.6} />
              </g>
            ))}
          </svg>
        </Box>

        <Box mt={3} style={{background:'#fff', color:'#000', padding:12, borderRadius:8}}>
          <Typography variant='subtitle1'>Selected Batch</Typography>
          {selected ? (
            <div>
              <Typography><b style={{color:'#111'}}>{selected.batch.batch_id}</b> — {selected.batch.commodity} — <span style={{color:'#1976d2'}}>RSL {selected.batch.current_rsl_hours}h</span> — Stage: {selected.batch.current_stage}</Typography>
              <Stack direction='row' spacing={1} mt={2} mb={2}>
                <Button variant='contained' color='primary' onClick={actionTransportSim}>Simulate Transport</Button>
                <Button variant='contained' onClick={actionGrade}>Run Grading</Button>
                <Button variant='contained' onClick={actionRoute}>Send to DC</Button>
                <Button variant='contained' onClick={actionMoveToStore}>Move to Backroom</Button>
                <Button variant='contained' onClick={actionMoveToShelf}>Move to Shelf</Button>
                <Button variant='contained' color='warning' onClick={actionSpoilage}>Spoilage Detect</Button>
                <Button variant='contained' onClick={actionMarkdown}>Apply Markdown</Button>
                <Button variant='outlined' onClick={actionHQ}>HQ Report</Button>
              </Stack>

              <Typography variant='subtitle2'>History</Typography>
              <List dense>
                {selected.history.map((h, idx) => (
                    <ListItem key={idx}>
                      <ListItemText primary={`${h.stage} @ ${h.ts}`} secondary={`RSL ${h.rsl_hours} — ${h.notes}`} />
                    </ListItem>
                ))}
              </List>
            </div>
          ) : <Typography>Select a batch to see actions</Typography>}
        </Box>

        <Box mt={2}>
          <Typography variant='body2' style={{color:'#9fbfdc'}}>{statusMsg}</Typography>
        </Box>
      </Paper>
    </Box>
  );
}
