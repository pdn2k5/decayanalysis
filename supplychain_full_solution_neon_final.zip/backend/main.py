
import os
import json
import random
import datetime
from fastapi import FastAPI, HTTPException, Form
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware

from db import SessionLocal
from models import (
    Commodity, Supplier, Batch, SensorLog,
    GradingResult, SpoilageDetection,
    BatchHistory, StoreOps
)
from schemas import (
    BatchDetail, BatchSummary,
    HistoryEntry, GradingEntry, SpoilageEntry
)

app = FastAPI(title='FreshSight Supply Chain – Python 3.12 Backend')

app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],
    allow_methods=['*'],
    allow_headers=['*'],
)

IMAGE_FOLDER = os.getenv('IMAGE_FOLDER','./images')

def safe_value_copy(batch):
    return batch.current_stage, batch.current_rsl_hours

@app.get('/api/batches', response_model=list[BatchSummary])
def list_batches():
    session = SessionLocal()
    rows = session.query(Batch).all()
    out = []
    for b in rows:
        out.append(BatchSummary(
            batch_id=b.batch_id,
            commodity=b.commodity,
            supplier_id=b.supplier_id,
            qty_kg=b.qty_kg or 0.0,
            created_ts=b.created_ts,
            current_stage=b.current_stage,
            current_rsl_hours=b.current_rsl_hours
        ))
    session.close()
    return out

@app.get('/api/batches/{batch_id}', response_model=BatchDetail)
def batch_detail(batch_id: str):
    session = SessionLocal()
    b = session.get(Batch, batch_id)
    if not b:
        session.close()
        raise HTTPException(status_code=404, detail='batch not found')
    history_rows = session.query(BatchHistory).filter(BatchHistory.batch_id==batch_id).order_by(BatchHistory.ts).all()
    grading_rows = session.query(GradingResult).filter(GradingResult.batch_id==batch_id).all()
    spoil_rows = session.query(SpoilageDetection).filter(SpoilageDetection.batch_id==batch_id).all()
    session.close()
    return BatchDetail(
        batch=BatchSummary(batch_id=b.batch_id, commodity=b.commodity, supplier_id=b.supplier_id, qty_kg=b.qty_kg or 0.0, created_ts=b.created_ts, current_stage=b.current_stage, current_rsl_hours=b.current_rsl_hours),
        history=[HistoryEntry(stage=h.stage, ts=h.ts, rsl_hours=h.rsl_hours, notes=h.notes) for h in history_rows],
        grading=[GradingEntry(image_path=g.image_path, grade=g.grade, defects=g.defects_json) for g in grading_rows],
        spoilage=[SpoilageEntry(image_path=s.image_path, spoilage_detected=bool(s.spoilage_detected), spoilage_type=s.spoilage_type, confidence=s.confidence) for s in spoil_rows]
    )

@app.post('/api/edge/create')
def edge_create(batch_id: str = Form(...), commodity: str = Form(...), supplier_id: str = Form(...), temp: float = Form(None), humidity: float = Form(None)):
    session = SessionLocal()
    if session.get(Batch, batch_id):
        session.close()
        raise HTTPException(status_code=400, detail='batch already exists')
    com = session.query(Commodity).filter(Commodity.commodity_id == commodity).first()
    sup = session.query(Supplier).filter(Supplier.supplier_id == supplier_id).first()
    base_rsl = com.avg_shelf_life_hours if com else 72
    if temp is None:
        temp = (com.opt_temp_min + com.opt_temp_max) / 2 if com else 10
    excess = max(0, temp - (com.opt_temp_max if com else temp))
    supplier_penalty = max(0, (1 - (sup.historical_quality_score if sup else 0.8)) * 10)
    rsl = int(max(1, base_rsl - (excess * 2) - supplier_penalty))
    b = Batch(batch_id=batch_id, commodity=commodity, supplier_id=supplier_id, qty_kg=100.0, created_ts=datetime.datetime.utcnow().isoformat(), current_stage='collection', current_rsl_hours=rsl)
    session.add(b)
    session.add(BatchHistory(batch_id=batch_id, stage='collection', ts=datetime.datetime.utcnow().isoformat(), rsl_hours=rsl, notes=f'edge_created temp={temp},hum={humidity}'))
    session.commit()
    session.close()
    return {"batch_id":batch_id,"current_stage":"collection","current_rsl_hours":rsl}

@app.post('/api/transport/simulate')
def simulate_transport(batch_id: str = Form(...), event_type: str = Form(...), temp: float = Form(None), duration_min: int = Form(0)):
    session = SessionLocal()
    b = session.get(Batch, batch_id)
    if not b:
        session.close()
        raise HTTPException(status_code=404, detail='batch not found')
    com = session.query(Commodity).filter(Commodity.commodity_id==b.commodity).first()
    rsl = b.current_rsl_hours or (com.avg_shelf_life_hours if com else 48)
    severity = 0
    note = ''
    if event_type == 'temp_breach' and temp is not None and com:
        max_allowed = com.opt_temp_max or temp
        excess = max(0, temp - max_allowed)
        severity = int(min(5, (excess * duration_min) // 10 + 1))
        reduction = int(min(rsl-1, round(excess * duration_min * (com.sensitivity_score or 0.5) / 10)))
        rsl = max(1, rsl - reduction)
        note = f'temp_breach:temp={temp},dur={duration_min},reduction={reduction}'
    b.current_rsl_hours = int(rsl)
    b.current_stage = 'transport'
    session.add(b)
    session.add(BatchHistory(batch_id=batch_id, stage='transport', ts=datetime.datetime.utcnow().isoformat(), rsl_hours=rsl, notes=note))
    result_stage, result_rsl = safe_value_copy(b)
    session.commit()
    session.close()
    return {"batch_id":batch_id,"event":event_type,"severity":severity,"updated_RSL":result_rsl,"stage":result_stage}

@app.post('/api/fulfillment/grade')
def fulfillment_grade(batch_id: str = Form(...)):
    session = SessionLocal()
    b = session.get(Batch, batch_id)
    if not b:
        session.close()
        raise HTTPException(status_code=404, detail='batch not found')
    grading_file = os.path.join(os.path.dirname(__file__), 'data', 'grading_images.json')
    inserted = 0
    if os.path.exists(grading_file):
        with open(grading_file, 'r', encoding='utf-8') as f:
            imgs = json.load(f)
        for it in imgs:
            if it.get('batch_id') == batch_id:
                session.add(GradingResult(batch_id=batch_id, image_path=it.get('image'), grade=it.get('grade'), defects_json=json.dumps(it.get('defects', [])), ts=datetime.datetime.utcnow().isoformat()))
                inserted += 1
    if b.current_rsl_hours:
        b.current_rsl_hours = max(1, b.current_rsl_hours - 4)
    b.current_stage = 'fulfillment'
    session.add(b)
    session.add(BatchHistory(batch_id=batch_id, stage='fulfillment', ts=datetime.datetime.utcnow().isoformat(), rsl_hours=b.current_rsl_hours, notes=f'grading_imported:{inserted}'))
    result_stage, result_rsl = safe_value_copy(b)
    session.commit()
    session.close()
    return {"batch_id":batch_id,"grading_records_imported":inserted,"current_stage":result_stage,"current_rsl_hours":result_rsl}

@app.post('/api/dc/route')
def dc_route(batch_id: str = Form(...)):
    session = SessionLocal()
    b = session.get(Batch, batch_id)
    if not b:
        session.close()
        raise HTTPException(status_code=404, detail='batch not found')
    stores = ['STORE-11', 'STORE-15', 'STORE-03', 'STORE-22']
    chosen = stores[hash(batch_id) % len(stores)]
    b.current_stage = 'distribution'
    session.add(b)
    session.add(BatchHistory(batch_id=batch_id, stage='distribution', ts=datetime.datetime.utcnow().isoformat(), rsl_hours=b.current_rsl_hours, notes=f'allocated_to_{chosen}'))
    session.add(StoreOps(store_id=chosen, batch_id=batch_id, ts=datetime.datetime.utcnow().isoformat(), sales_rate_per_hour=1.0, current_price=0.0, inventory_kg=b.qty_kg, markdown_applied_percent=0, notes='allocated_from_dc'))
    result_stage, result_rsl = safe_value_copy(b)
    session.commit()
    session.close()
    return {"batch_id":batch_id,"allocated_store":chosen,"current_stage":result_stage,"current_rsl_hours":result_rsl}

@app.post('/api/store/move')
def store_move(batch_id: str = Form(...)):
    session = SessionLocal()
    b = session.get(Batch, batch_id)
    if not b:
        session.close()
        raise HTTPException(status_code=404, detail='batch not found')
    b.current_stage = 'store_backroom'
    session.add(b)
    session.add(BatchHistory(batch_id=batch_id, stage='store_backroom', ts=datetime.datetime.utcnow().isoformat(), rsl_hours=b.current_rsl_hours, notes='moved_to_store_backroom'))
    result_stage, result_rsl = safe_value_copy(b)
    session.commit()
    session.close()
    return {"batch_id":batch_id,"current_stage":result_stage,"current_rsl_hours":result_rsl}

# store move to shelf
@app.post('/api/store/move_shelf')
def store_move_shelf(batch_id: str = Form(...)):
    session = SessionLocal()
    b = session.get(Batch, batch_id)
    if not b:
        session.close()
        raise HTTPException(status_code=404, detail='batch not found')
    if b.current_rsl_hours:
        b.current_rsl_hours = max(1, int(b.current_rsl_hours - 2))
    b.current_stage = 'store_shelf'
    session.add(b)
    session.add(BatchHistory(batch_id=batch_id, stage='store_shelf', ts=datetime.datetime.utcnow().isoformat(), rsl_hours=b.current_rsl_hours, notes='moved_to_shelf'))
    result_stage, result_rsl = safe_value_copy(b)
    session.commit()
    session.close()
    return {"batch_id":batch_id,"current_stage":result_stage,"current_rsl_hours":result_rsl}

# markdown
@app.post('/api/store/markdown')
def store_markdown(batch_id: str = Form(...)):
    session = SessionLocal()
    b = session.get(Batch, batch_id)
    if not b:
        session.close()
        raise HTTPException(status_code=404, detail='batch not found')
    rsl = b.current_rsl_hours or 0
    if rsl < 6:
        markdown = 40
    elif rsl < 12:
        markdown = 20
    else:
        markdown = 5
    storeops = session.query(StoreOps).filter(StoreOps.batch_id == batch_id).first()
    if storeops:
        storeops.markdown_applied_percent = markdown
        storeops.current_price = storeops.current_price * (100 - markdown) / 100 if storeops.current_price else 0.0
        session.add(storeops)
    else:
        so = StoreOps(store_id='STORE-NA', batch_id=batch_id, ts=datetime.datetime.utcnow().isoformat(), sales_rate_per_hour=1.0, current_price=0.0, inventory_kg=b.qty_kg, markdown_applied_percent=markdown, notes='markdown_auto')
        session.add(so)
    session.add(BatchHistory(batch_id=batch_id, stage='markdown', ts=datetime.datetime.utcnow().isoformat(), rsl_hours=b.current_rsl_hours, notes=f'markdown_applied:{markdown}%'))
    result_stage, result_rsl = safe_value_copy(b)
    session.commit()
    session.close()
    return {"batch_id":batch_id,"markdown_percent":markdown,"current_rsl_hours":result_rsl}

# hq report
@app.post('/api/hq/report')
def hq_report(batch_id: str = Form(...)):
    session = SessionLocal()
    b = session.get(Batch, batch_id)
    if not b:
        session.close()
        raise HTTPException(status_code=404, detail='batch not found')
    history_rows = session.query(BatchHistory).filter(BatchHistory.batch_id == batch_id).order_by(BatchHistory.ts).all()
    grading_rows = session.query(GradingResult).filter(GradingResult.batch_id == batch_id).all()
    spoil_rows = session.query(SpoilageDetection).filter(SpoilageDetection.batch_id == batch_id).all()
    timeline = [f'{h.stage}@{h.ts} -> {h.notes}' for h in history_rows]
    damage_causes = [h.notes for h in history_rows if 'temp_breach' in (h.notes or '')]
    md = session.query(StoreOps).filter(StoreOps.batch_id == batch_id).first()
    markdown_applied = md.markdown_applied_percent if md else 0
    final_stage, final_rsl = safe_value_copy(b)
    session.close()
    return {
        'batch_id': batch_id,
        'commodity': b.commodity,
        'final_stage': final_stage,
        'final_rsl': final_rsl,
        'damage_causes': damage_causes,
        'grading_count': len(grading_rows),
        'spoilage_count': len(spoil_rows),
        'markdown_applied_percent': markdown_applied,
        'timeline': timeline
    }

@app.get('/api/images/{path:path}')
def serve_image(path: str):
    file_path = os.path.join(IMAGE_FOLDER, path)
    if os.path.exists(file_path):
        return FileResponse(file_path)
    raise HTTPException(status_code=404, detail='image not found')
