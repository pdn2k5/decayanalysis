
from pydantic import BaseModel
from typing import List, Optional, Any

class BatchSummary(BaseModel):
    batch_id: str
    commodity: str
    supplier_id: str
    qty_kg: float
    created_ts: Optional[str]
    current_stage: Optional[str]
    current_rsl_hours: Optional[int]

class HistoryEntry(BaseModel):
    stage: str
    ts: Optional[str]
    rsl_hours: Optional[int]
    notes: Optional[str]

class GradingEntry(BaseModel):
    image_path: str
    grade: str
    defects: Optional[Any]

class SpoilageEntry(BaseModel):
    image_path: str
    spoilage_detected: bool
    spoilage_type: Optional[str]
    confidence: Optional[float]

class BatchDetail(BaseModel):
    batch: BatchSummary
    history: List[HistoryEntry] = []
    grading: List[GradingEntry] = []
    spoilage: List[SpoilageEntry] = []
