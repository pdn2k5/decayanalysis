
from sqlalchemy import Column, Integer, String, Float, Text
from db import Base

class Commodity(Base):
    __tablename__ = 'commodity_master'
    commodity_id = Column(String, primary_key=True, index=True)
    name = Column(String)
    avg_shelf_life_hours = Column(Integer)
    opt_temp_min = Column(Float)
    opt_temp_max = Column(Float)
    sensitivity_score = Column(Float)
    default_packaging = Column(String)

class Supplier(Base):
    __tablename__ = 'suppliers'
    supplier_id = Column(String, primary_key=True, index=True)
    name = Column(String)
    historical_quality_score = Column(Float)
    defect_rate_percent = Column(Float)
    region = Column(String)

class Batch(Base):
    __tablename__ = 'batches'
    batch_id = Column(String, primary_key=True, index=True)
    commodity = Column(String)
    supplier_id = Column(String)
    qty_kg = Column(Float)
    created_ts = Column(String)
    current_stage = Column(String)
    current_rsl_hours = Column(Integer)

class SensorLog(Base):
    __tablename__ = 'sensor_logs'
    id = Column(Integer, primary_key=True, autoincrement=True)
    batch_id = Column(String, index=True)
    ts = Column(String)
    temp_c = Column(Float)
    humidity_percent = Column(Float)
    gps_lat = Column(Float)
    gps_lon = Column(Float)
    event = Column(String)

class GradingResult(Base):
    __tablename__ = 'grading_results'
    id = Column(Integer, primary_key=True, autoincrement=True)
    batch_id = Column(String, index=True)
    image_path = Column(String)
    grade = Column(String)
    defects_json = Column(Text)
    ts = Column(String)

class SpoilageDetection(Base):
    __tablename__ = 'spoilage_detections'
    id = Column(Integer, primary_key=True, autoincrement=True)
    batch_id = Column(String, index=True)
    image_path = Column(String)
    spoilage_detected = Column(Integer)
    spoilage_type = Column(String)
    confidence = Column(Float)
    ts = Column(String)

class BatchHistory(Base):
    __tablename__ = 'batch_history'
    id = Column(Integer, primary_key=True, autoincrement=True)
    batch_id = Column(String, index=True)
    stage = Column(String)
    ts = Column(String)
    rsl_hours = Column(Integer)
    notes = Column(String)

class StoreOps(Base):
    __tablename__ = 'store_ops'
    id = Column(Integer, primary_key=True, autoincrement=True)
    store_id = Column(String)
    batch_id = Column(String, index=True)
    ts = Column(String)
    sales_rate_per_hour = Column(Float)
    current_price = Column(Float)
    inventory_kg = Column(Float)
    markdown_applied_percent = Column(Float)
    notes = Column(String)
