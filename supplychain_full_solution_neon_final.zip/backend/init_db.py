
import os, csv, json
from db import engine, SessionLocal, Base
from models import Commodity, Supplier, Batch, SensorLog, GradingResult, SpoilageDetection, BatchHistory, StoreOps

DATA_DIR = os.path.join(os.path.dirname(__file__), 'data')

def create_schema():
    Base.metadata.create_all(bind=engine)

def load_csv(file_name, model_cls):
    path = os.path.join(DATA_DIR, file_name)
    if not os.path.exists(path):
        print(f'[init] {file_name} not found, skipping')
        return
    valid_fields = set(model_cls.__table__.columns.keys())
    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        session = SessionLocal()
        for row in reader:
            kwargs = {}
            for col in reader.fieldnames:
                if col in valid_fields:
                    val = row.get(col)
                    if val == '':
                        kwargs[col] = None
                    else:
                        kwargs[col] = val
            obj = model_cls(**kwargs)
            session.merge(obj)
        session.commit()
        session.close()
    print(f'[init] loaded {file_name}')

def load_all():
    create_schema()
    print('[init] schema created. Place CSV/JSON files in backend/data/ and re-run init_db.py to load data.')

if __name__ == '__main__':
    load_all()
