
SupplyChain Full Solution (Neon UI) - D3 (no dataset included)
------------------------------------------------------------

Place your CSV/JSON dataset files in backend/data/ before running init_db.py.

Backend (run on Windows):
1. cd backend
2. python -m venv .venv
3. .venv\Scripts\activate
4. pip install -r requirements.txt
5. python init_db.py
6. uvicorn main:app --reload --port 8000

Frontend (Vite + React):
1. cd frontend
2. npm install
3. npm run dev

API endpoints:
- GET /api/batches
- GET /api/batches/{batch_id}
- POST /api/edge/create
- POST /api/transport/simulate
- POST /api/fulfillment/grade
- POST /api/dc/route
- POST /api/store/move
- POST /api/store/move_shelf
- POST /api/store/markdown
- POST /api/store/spoilage_detect
- POST /api/hq/report
